#include "PaymentAccount.h"
PaymentAccount::PaymentAccount() {
    this->STK = "123456789";
    this->SD = 100000000;
    this->NPH = "18/02/2002";
}
PaymentAccount::PaymentAccount(string number, double money, string day) {
    this->STK = number;
    this->SD = money;
    this->NPH = day;
}
double PaymentAccount::getBalance() {
    return this->SD;
}
bool PaymentAccount::transferTo(double amount) {
    if (this->SD < amount) {
        return false;
    }
    else {
        string msg;
        cout << "Nhap noi dung chuyen khoan: ";
        getline(cin, msg);
        History ls;
        this->SD = this->SD - amount;
        ls.setSTK(this->STK);
        ls.setNgayGD(getToday());
        ls.setSoTienCK(0 - amount);
        ls.setNoiDung(msg);
        LS.push_back(ls);
        return true;
    }
}
void PaymentAccount::showHistory() {
    for (int i = 0; i < LS.size(); ++i) {
        cout << LS[i] << endl;
    }
}
istream& operator>>(istream& is, PaymentAccount& account) {
    cout << "Nhap thong tin Tai khoan thanh toan" << endl;
    cout << "Nhap so tai khoan : ";
    is >> account.STK;
    cout << "Nhap so du hien tai: ";
    is >> account.SD;
    cout << "Nhap ngay phat hanh tai khoan: ";
    is >> account.NPH;
    return is;
}
ostream& operator<<(ostream& os, PaymentAccount account) {
    os << "Thong tin tai khoan thanh toan" << endl;
    os << "So tai khoan la: " << account.STK << endl;
    os << "So du hien tai la: " << setprecision(2) << fixed << account.SD << endl;
    os << "Ngay phat hanh la: " << account.NPH << endl;
    return os;
}
PaymentAccount::~PaymentAccount() {

}
string getToday() {
    const int max = 80;
    char s[max];
    time_t t = time(0);
    strftime(s, max, "%d/%m/%Y", localtime(&t));
    return string(s);
}