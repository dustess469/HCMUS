#ifndef _PAYMENTACCOUNT_
#define _PAYMENTACCOUNT_

#include"History.h"
#include<iostream>
#include<ctime>
#include<vector>
#include<iomanip>
#include<string>
#include<time.h>

using namespace std;

class PaymentAccount {
private:
    string STK;
    double SD;
    string NPH;
    vector<History> LS;
public:
    //Constructor
    PaymentAccount();
    PaymentAccount(string number, double money, string day);

    double getBalance();
    bool transferTo(double amount);
    void showHistory();
    //Input, output
    friend istream& operator>>(istream& is, PaymentAccount& account);
    friend ostream& operator<<(ostream& os, PaymentAccount account);

    //Destructor
    ~PaymentAccount();

};
string getToday();
#endif // !_PAYMENTACCOUNT_