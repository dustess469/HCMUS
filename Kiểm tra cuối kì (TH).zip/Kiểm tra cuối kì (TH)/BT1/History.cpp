#include"History.h"
string History::getSTK() {
    return this->STK;
}
double History::getSoTienCK() {
    return this->SoTienCK;
}
string History::getNoiDung() {
    return this->NoiDung;
}
string History::getNgayGD() {
    return this->NgayGD;
}
void History::setSTK(string number) {
    this->STK = number;
}
void History::setSoTienCK(double money) {
    this->SoTienCK = money;
}
void History::setNoiDung(string content) {
    this->NoiDung = content;
}
void History::setNgayGD(string day) {
    this->NgayGD = day;
}
ostream& operator<<(ostream& os, History& history) {
    os << "\nLich su gia dich" << endl;
    os << "So tai khoan: " << history.STK << endl;
    os << "So tien chuyen khoan: " << history.SoTienCK << endl;
    os << "Ngay giao dich: " << history.NgayGD << endl;
    os << "Noi dung giao dich: " << history.NoiDung << endl;
    return os;
}
History::~History() {};