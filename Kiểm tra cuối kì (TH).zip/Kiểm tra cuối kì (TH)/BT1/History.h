#ifndef _HISTORY_
#define _HISTORY_
#include<iostream>

using namespace std;

class History {
private:
    string STK;
    double SoTienCK;
    string NoiDung;
    string NgayGD;
public:
    //Getter
    string getSTK();
    double getSoTienCK();
    string getNoiDung();
    string getNgayGD();
    //Setter
    void setSTK(string number);
    void setSoTienCK(double money);
    void setNoiDung(string content);
    void setNgayGD(string day);
    //Output
    friend ostream& operator<<(ostream& os, History& history);
    //Destructor
    ~History();
};
#endif // !_HISTORY_