#include"CashbackCardAccount.h"
CashbackCardAccount::CashbackCardAccount() :CreditCardAccount() {
    CreditCardAccount();
    this->currentCashback = 1000000;
    this->cashbackRate = 1;
}
CashbackCardAccount::CashbackCardAccount(double currentCB, double rate, string STK, double soDu, double lai) : CreditCardAccount(STK, soDu, lai) {
    CreditCardAccount(STK, soDu, lai);
    this->currentCashback = currentCB;
    this->cashbackRate = rate;
}
double CashbackCardAccount::getCurrentCashback() {
    return this->currentCashback;
}
bool CashbackCardAccount::charge(double amount) {
    if (CreditCardAccount::charge(amount)) {
        int cashback = (this->cashbackRate / 100) * amount;
        currentCashback = currentCashback + cashback;
        return true;
    }
    else {
        return false;
    }
}
void CashbackCardAccount::redeemCashback() {
    this->balance = this->balance - this->currentCashback;
    this->currentCashback = 0;
}
istream& operator>>(istream& is, CashbackCardAccount& account) {
    cout << "Nhap thong tin Cashback Card Account" << endl;
    cout << "Nhap so tai khoan: ";
    is >> account.STK;
    cout << "Nhap so du hien tai: ";
    is >> account.balance;
    cout << "Nhap lai suat: ";
    is >> account.interestRate;
    cout << "Nhap so tien co the hoan lai: ";
    is >> account.currentCashback;
    cout << "Nhap ti le hoan tien: ";
    is >> account.cashbackRate;
    return is;
}
ostream& operator<<(ostream& os, CashbackCardAccount account) {
    os << "Thong tin Cashback Card Account";
    os << "So tai khoan: " << account.STK << endl;
    os << "So du hien tai: " << setprecision(2) << fixed << account.balance << endl;
    os << "Han muc tin dung: " << setprecision(2) << fixed << account.creditLimit << endl;
    os << "Lai suat: " << setprecision(2) << fixed << account.interestRate << endl;
    account.minPayment = 0.05 * account.balance;
    os << "Thanh toan toi thieu: " << setprecision(2) << fixed << account.minPayment << endl;
    os << "Phi tra cham: " << setprecision(2) << fixed << account.latePenalty << endl;
    os << "So tien co the hoan lai: " << account.currentCashback << endl;
    os << "Ti le hoan tien: " << setprecision(2) << fixed << account.cashbackRate << endl;
    return os;
}