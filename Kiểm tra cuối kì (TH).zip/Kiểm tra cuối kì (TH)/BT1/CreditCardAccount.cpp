#include "CreditCardAccount.h"

CreditCardAccount::CreditCardAccount() {
    this->STK = "123456789";
    this->creditLimit = 30000000;
    this->balance = 5000000;
    this->latePenalty = 2000000;
    this->minPayment = 0.05 * this->balance;
    this->interestRate = 5;
}

CreditCardAccount::CreditCardAccount(string STK, double soDu, double lai) {
    this->STK = STK;
    this->creditLimit = 30000000;
    this->balance = soDu;
    this->interestRate = lai;
    this->latePenalty = 2000000;
    this->minPayment = 0.05 * this->balance;
}

double CreditCardAccount::getBalance() {
    return this->balance;
}

bool CreditCardAccount::charge(double amount) {
    if (amount + this->balance <= this->creditLimit) {
        string msg;
        cout << "\nNhap noi dung chuyen khoan: ";
        getline(cin, msg);
        History ls;
        this->balance = this->balance + amount;
        ls.setSTK(this->STK);
        ls.setNgayGD(getDay());
        ls.setSoTienCK(amount);
        ls.setNoiDung(msg);
        LS.push_back(ls);
        return true;
    }
    else {
        return false;
    }
}

void CreditCardAccount::payment(double amount) {
    string msg;
    cout << "Nhap noi dung chuyen khoan: ";
    getline(cin, msg);
    History ls;
    this->balance = this->balance - amount;
    ls.setSTK(this->STK);
    ls.setNgayGD(getDay());
    ls.setSoTienCK(0 - amount);
    ls.setNoiDung(msg);
    LS.push_back(ls);
}

void CreditCardAccount::showHistory() {
    for (int i = 0; i < LS.size(); ++i) {
        cout << LS[i] << endl;
    }
}

istream& operator>>(istream& is, CreditCardAccount& account) {
    cout << "Nhap thong tin Credit Card Account" << endl;
    cout << "Nhap so tai khoan: ";
    is >> account.STK;
    cout << "Nhap so du hien tai: ";
    is >> account.balance;
    cout << "Nhap lai suat: ";
    is >> account.interestRate;
    return is;
}

ostream& operator<<(ostream& os, CreditCardAccount account) {
    os << "Thong tin Credit Card Account";
    os << "So tai khoan: " << account.STK << endl;
    os << "So du hien tai: " << setprecision(2) << fixed << account.balance << endl;
    os << "Han muc tin dung: " << setprecision(2) << fixed << account.creditLimit << endl;
    os << "Lai suat: " << setprecision(2) << fixed << account.interestRate << endl;
    account.minPayment = 0.05 * account.balance;
    os << "Thanh toan toi thieu: " << setprecision(2) << fixed << account.minPayment << endl;
    os << "Phi tra cham: " << setprecision(2) << fixed << account.latePenalty << endl;
    return os;
}

void CreditCardAccount::inputThe() {
    if (THE.size() == 6) {
        cout << "\nSo the phat hanh da dat gioi han" << endl;
    }
    else {
        CreditCard the;
        string st, nph, tklk;
        cout << "\nNhap thong tin the phat hanh" << endl;
        cout << "Nhap so the: ";
        cin >> st;
        the.setSoThe(st);
        cout << "Nhap ngay phat hanh: ";
        cin >> nph;
        the.setNgayPhatHanh(nph);
        the.setTKLK(this->STK);
        THE.push_back(the);
    }
}
void CreditCardAccount::outputThe() {
    for (int i = 0; i < THE.size(); ++i) {
        cout << "\nThong tin the phat hanh" << endl;
        cout << "So the: " << THE[i].getSoThe() << endl;
        cout << "Ngay phat hanh: " << THE[i].getNgayPhatHanh() << endl;
        cout << "So tai khoan lien ket: " << THE[i].getTKLK() << endl;
    }
}

CreditCardAccount::~CreditCardAccount() {}

string getDay() {
    const int max = 80;
    char s[max];
    time_t t = time(0);
    strftime(s, max, "%Day/%Month/%Year", localtime(&t));
    return string(s);
}