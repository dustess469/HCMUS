#include"PaymentAccount.h"
#include"CreditCardAccount.h"
#include"CashbackCardAccount.h"
#include"RewardCardAccount.h"
int main() {
    PaymentAccount account;
    cout << account;
    cout << "\nSo du hien tai: " << account.getBalance() << endl;
    if (account.transferTo(50000) == false) {
        cout << "So tien khong du de thuc hien giao dich";
    }
    if (account.transferTo(500000) == false) {
        cout << "So tien khong du de thuc hien giao dich";
    }
    account.showHistory();
    cout << "\nSo du hien tai: " << account.getBalance();

    CreditCardAccount cca;
    cout << cca;
    if (!cca.charge(5000000)) {
        cout << "So tien vuot qua han muc cua the" << endl;
    }
    cout << cca.getBalance() << endl;
    cca.payment(3000000);
    cout << cca.getBalance() << endl;
    cca.showHistory();

    RewardCardAccount rca;
    cout << rca;
    if (!rca.charge(5000000)) {
        cout << "So tien vuot qua han muc" << endl;
    }
    cout << "\nSo diem hien tai: ";
    cout << rca.getCurrentPoint() << endl;
    cout << endl;
    rca.showHistory();

    CashbackCardAccount cbca;
    cout << cbca;
    if (!cbca.charge(5000000)) {
        cout << "\nSo tien vuot qua han muc" << endl;
    }
    cout << "\nSo tien co the hoan lai: ";
    cout << cbca.getCurrentCashback() << endl;
    cout << endl;
    cbca.showHistory();

    CreditCardAccount the;
    the.inputThe();
    the.inputThe();
    the.inputThe();
    the.inputThe();
    the.inputThe();
    the.inputThe();
    the.inputThe();
    the.outputThe();
    return 0;
}