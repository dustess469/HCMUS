#include "RewardCardAccount.h"

RewardCardAccount::RewardCardAccount() :CreditCardAccount() {
    CreditCardAccount();
    this->currentPoint = 1000;
    this->rewardRate = 1;
}
RewardCardAccount::RewardCardAccount(int point, double rate, string STK, double soDu, double lai) : CreditCardAccount(STK, soDu, lai) {
    CreditCardAccount(STK, soDu, lai);
    this->currentPoint = point;
    this->rewardRate = rate;
}
int RewardCardAccount::getCurrentPoint() {
    return this->currentPoint;
}
bool RewardCardAccount::charge(double amount) {
    if (CreditCardAccount::charge(amount)) {
        int rewardPoint = (this->rewardRate / 100) * amount;
        currentPoint = currentPoint + rewardPoint;
        return true;
    }
    else {
        return false;
    }
}
void RewardCardAccount::payWithPoint(int pAmount) {
    if (pAmount <= this->currentPoint) {
        this->currentPoint = this->currentPoint - pAmount;
    }
    else return;
}
istream& operator>>(istream& is, RewardCardAccount& account) {
    cout << "Nhap thong tin Reward Card Account" << endl;
    cout << "Nhap so tai khoan: ";
    is >> account.STK;
    cout << "Nhap so du hien tai: ";
    is >> account.balance;
    cout << "Nhap lai suat: ";
    is >> account.interestRate;
    cout << "Nhap so diem hien tai: ";
    is >> account.currentPoint;
    cout << "Nhap ti le hoan diem: ";
    is >> account.rewardRate;
    return is;
}
ostream& operator<<(ostream& os, RewardCardAccount account) {
    os << "Thong tin Reward Card Account";
    os << "So tai khoan: " << account.STK << endl;
    os << "So du hien tai: " << setprecision(2) << fixed << account.balance << endl;
    os << "Han muc tin dung: " << setprecision(2) << fixed << account.creditLimit << endl;
    os << "Lai suat: " << setprecision(2) << fixed << account.interestRate << endl;
    account.minPayment = 0.05 * account.balance;
    os << "Thanh toan toi thieu: " << setprecision(2) << fixed << account.minPayment << endl;
    os << "Phi tra cham: " << setprecision(2) << fixed << account.latePenalty << endl;
    os << "So diem hien tai: " << account.currentPoint << endl;
    os << "Ti le hoan diem: " << setprecision(2) << fixed << account.rewardRate << endl;
    return os;
}

RewardCardAccount::~RewardCardAccount() {}