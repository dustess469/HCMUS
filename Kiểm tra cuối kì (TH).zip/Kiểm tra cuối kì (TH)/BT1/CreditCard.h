#ifndef _CREDITCARD_
#define _CREDITCARD_
#include<iostream>
#include<vector>

using namespace std;

class CreditCard {
private:
    string soThe;
    string ngayPhatHanh;
    string taiKhoanLK;

public:
    //Constructor
    CreditCard();
    CreditCard(string number, string day, string connect);

    //Setter, getter
    string getSoThe();
    string getNgayPhatHanh();
    string getTKLK();
    void setSoThe(string st);
    void setNgayPhatHanh(string nph);
    void setTKLK(string tklk);
    //Destructor
    ~CreditCard() {};
};
#endif // !_CREDITCARD_