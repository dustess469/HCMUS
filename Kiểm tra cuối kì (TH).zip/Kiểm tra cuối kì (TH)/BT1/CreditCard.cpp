#include "CreditCard.h"
CreditCard::CreditCard() {
    this->ngayPhatHanh = "18/02/2002";
    this->soThe = "123456789";
}
CreditCard::CreditCard(string number, string day, string connect) {
    this->ngayPhatHanh = day;
    this->soThe = number;
    this->taiKhoanLK = connect;
}

string CreditCard::getSoThe() {
    return this->soThe;
}
string CreditCard::getNgayPhatHanh() {
    return this->ngayPhatHanh;
}
string CreditCard::getTKLK() {
    return this->taiKhoanLK;
}
void CreditCard::setNgayPhatHanh(string nph) {
    this->ngayPhatHanh = nph;
}
void CreditCard::setSoThe(string st) {
    this->soThe = st;
}
void CreditCard::setTKLK(string tklk) {
    this->taiKhoanLK = tklk;
}