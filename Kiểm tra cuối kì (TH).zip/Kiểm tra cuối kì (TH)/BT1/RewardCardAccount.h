#ifndef _REWARDCARDACCOUNT_
#define _REWARDCARDACCOUNT_

#include "CreditCardAccount.h"
class RewardCardAccount :public CreditCardAccount {
private:
    int currentPoint;
    double rewardRate; //Tinh theo %
public:
    //Constructor
    RewardCardAccount();
    RewardCardAccount(int point, double rate, string STK, double soDu, double lai);

    int getCurrentPoint();
    bool charge(double amount);
    void payWithPoint(int pAmount);

    //Destructor
    ~RewardCardAccount();

    friend istream& operator>>(istream& is, RewardCardAccount& account);
    friend ostream& operator<<(ostream& os, RewardCardAccount account);

};
#endif // !_REWARDCARDACCOUNT_