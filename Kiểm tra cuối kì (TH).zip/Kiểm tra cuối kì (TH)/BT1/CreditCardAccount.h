#ifndef _CREDITCARDACCOUNT_
#define _CREDITCARDACCOUNT_

#include"History.h"
#include"CreditCard.h"
#include<iostream>
#include<vector>
#include<iomanip>
#include<string>
#include<time.h>

using namespace std;

class CreditCardAccount {
protected:
    string STK;
    double balance;
    double creditLimit;
    double interestRate; //calculator by %
    double minPayment;
    double latePenalty;
    vector<History> LS;
    vector<CreditCard> THE;
public:
    //Constructor
    CreditCardAccount();
    CreditCardAccount(string STK, double soDu, double lai);

    virtual double getBalance();
    virtual bool charge(double amount);
    virtual void payment(double amount);
    virtual void showHistory();

    void inputThe();
    void outputThe();


    //Input, output
    friend istream& operator>>(istream& is, CreditCardAccount& account);
    friend ostream& operator<<(ostream& os, CreditCardAccount account);

    //Destructor
    ~CreditCardAccount();
};
string getDay();

#endif // !_CREDITCARDACCOUNT_