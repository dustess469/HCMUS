#ifndef _CASHBACKCARDACCOUNT_
#define _CASHBACKCARDACCOUNT_

#include "CreditCardAccount.h"
class CashbackCardAccount :public CreditCardAccount {
private:
    double currentCashback;
    double cashbackRate;
public:
    //Constructor
    CashbackCardAccount();
    CashbackCardAccount(double currentCB, double rate, string STK, double soDu, double lai);

    double getCurrentCashback();
    bool charge(double amount);
    void redeemCashback();
    //Destructor
    ~CashbackCardAccount() {};
    //Input,output
    friend istream& operator>>(istream& is, CashbackCardAccount& account);
    friend ostream& operator<<(ostream& os, CashbackCardAccount account);
};
#endif // !_CASHBACKCARDACCOUNT_