#include <iostream>
#include <string>

using namespace std;

struct FRACTION
{
	int a, b;
};


template<class T>
bool compare(T a, T b)
{
	if (a > b)
		return true;
	else return false;
}


template<class T>
void Increasing(T a, int n)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (compare(a[i], a[j]))
				swap(a[i], a[j]);
}


template<class T>
void Decreasing(T a, int n)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (!compare(a[i], a[j]))
				swap(a[i], a[j]);
}


template<class T>
void sort(T a, int n, bool t)
{
	if (t == true)
		Increasing(a, n);
	else 
		Decreasing(a, n);
}


template<class T>
void output(T a, int n)
{
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
}


int main()
{
	int a[] = {4,3,6,8};
	//float a[] = { 1.6F, 8.6F, 9.9F, 2.3F };
	//FRACTION a[] = { {1,2}, {2,3}, {3,7} };
	//string a[] = { "hello","chao","bonjour" };
	int n = sizeof(a) / sizeof(a[0]);

	sort(a, n, 1);
	output(a, n);

	return 0;
}