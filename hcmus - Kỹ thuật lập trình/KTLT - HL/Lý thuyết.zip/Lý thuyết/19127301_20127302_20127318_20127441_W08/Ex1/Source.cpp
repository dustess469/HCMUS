#include<iostream>

using namespace std;

struct Fraction {
	int num, deno;
};

typedef struct {
	int m, n, sizeItem;
	void* Data[1];
}aStruct;
static int headSzie = 3 * sizeof(Fraction);

void alloc2D(void*** a, int m, int n, int sz)
{
	//m=2,n=3,sz=4;
	if (m <= 0 || n <= 0 || sz <= 0) return;
	int szRow = n * sz;
	int sz1 = m * (sizeof(void*));
	int sz2 = m * szRow;
	void* buf = calloc(headSzie + sz1 + sz2, 1);
	if (buf == NULL)return;
	aStruct* as = (aStruct*)buf;
	as->m = m; as->n = n; as->sizeItem = sz;
	buf = (char*)buf + headSzie + sz1;
	as->Data[0] = buf;
	for (int i = 1; i < m; i++)
	{
		buf = (char*)buf + szRow;
		as->Data[i] = buf;
	}
	*a = as->Data;
}

void arr2D_Input(Fraction** f)
{
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << "Nhap phan so thu a[" << i << "][" << j << "]: ";
			cin >> f[i][j].num;
			cin >> f[i][j].deno;
			cout << endl;
		}
	}
}

void arr2D_Output(Fraction** f)
{
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << "Phan so thu a[" << i << "][" << j << "]: " << f[i][j].num << "/" << f[i][j].deno << endl;
		}
	}
	cout << endl;
}


//void free2D(void** aData)
//{
//	if (aData != NULL)
//	{
//		void* p = (char*)aData - headSzie;
//		free(p);
//	}
//	
//}

void main() 
{
	Fraction** A;
	alloc2D((void***)&A, 2, 3, sizeof(Fraction));
	arr2D_Input(A);
	arr2D_Output(A);
	//free2D((void**)A);
}