#include<iostream>

using namespace std;

void inputArray(int*& a, int& n)
{
	cout << "Nhap so luong phan tu trong mang: ";
	cin >> n;

	a = new int[n];

	cout << "\nNhap cac phan tu trong mang\n";

	for (int i = 0; i < n; i++)
	{
		cout << "Nhap phan tu thu " << i + 1 << ": ";
		cin >> a[i];
	}
}

void freeArray(int*& a)
{
	delete[]a;
}

void outputArray(int* a, int n)
{
	cout << "\nCac phan tu trong mang:\n";
	for (int i = 0; i < n; i++)
	{
		cout << a[i] << " ";
	}

	cout << endl;
}
void main()
{
	int* a = NULL;
	int n = NULL;


	inputArray(a, n);

	outputArray(a, n);

	freeArray(a);
}