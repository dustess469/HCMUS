#include <iostream>
#include <iomanip>

using namespace std;

void create(int*& a, int& n)
{
    cout << "Nhap n de tao ma tran nxn: ";
    cin >> n;

    a = new int[n * n];

    cout << "\nNhap ma tran:\n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << "a[" << i << "][" << j << "]:";
            cin >> a[i * n + j];
        }
    }
}

void print(int*& a, int n)
{
    cout << "\nMa tran vuong:\n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << a[i * n + j] << " ";
        }

        cout << endl;
    }
}

void freeMatrix(int* a)
{
    delete[] a;
}


int main()
{
    int* a = NULL;
    int n = NULL;
    
    create(a, n);

    print(a, n);

    freeMatrix(a);
    
    return 0;
}