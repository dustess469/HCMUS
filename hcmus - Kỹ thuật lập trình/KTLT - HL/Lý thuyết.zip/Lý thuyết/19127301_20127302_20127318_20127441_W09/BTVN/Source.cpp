﻿#include<iostream>

using namespace std;

struct Node {
    int data;
    Node* next;
};


Node* getNode(int k) {
    Node* p = new Node;
    if (p == NULL) {
        return NULL;
    }
    p->data = k;
    p->next = NULL;
    return p;
}


void addFirst(Node*& head, Node*& tail, int k) {
    Node* p = getNode(k);
    if (head == NULL) {
        head = tail = NULL;
    }
    else {
        p->next = head;
        head = p;
    }
}

void printList(Node* Head) 
{
    //Node* t = Head->next;
    while (Head != NULL) 
    {
        cout << Head->data << " ";
        Head = Head->next;
    }
    cout << endl;
}

void destroyList(Node*& head) {
    Node* p;
    if (head == NULL) {
        return;
    }
    while (head) {
        p = head;
        head = head->next;
        delete p;
    }
}

int increase(int a, int b) {
    return a - b;
}

int decrease(int a, int b) {
    return b - a;
}

void makeOrderList(Node* h, int k, int (compare)(int a, int b)) {
    Node* p1 = h;
    Node* p2 = p1->next;

    while (p2 && (compare(p2->data, k)) < 0) {
        p1 = p2;
        p2 = p1->next;
    }
    
    Node* p = getNode(k);
    p1->next = p;
    p->next = p2;
}
Node* createNode(int value) {
    Node* temp = new Node;
    temp->data = value;
    temp->next = NULL;

    return temp;
}
bool checkEmpty(Node* head) {
    if (head == NULL)
        return true;
    return false;
}
void addTail(Node*& head, Node* p) {
    if (checkEmpty(head)) {
        head = p;
    }
}

void input(Node*& head) {
    int x;
    while (1)
    {
        cout << "Stop -> number = 0\n";
        cout << "Enter number: ";
        cin >> x;
        if (x == 0)
        {
            cout << "Decrease list: ";
            printList(head->next);
            cout << endl << endl;
            break;
        }
        else
        {
            Node* temp = createNode(x);
            addTail(head, temp);
            makeOrderList(head, x, decrease);
            cout << "Decrease list: ";
            printList(head->next);
            cout << endl;
        }
    }

}


int main() {
    Node* head = NULL;
    input(head);
}