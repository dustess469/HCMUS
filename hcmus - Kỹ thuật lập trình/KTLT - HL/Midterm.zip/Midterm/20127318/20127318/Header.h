#ifndef _HEADER_
#define _HEADER_

#include<iostream>
#include<string.h>

using namespace std;

struct HocSinh
{
	char* hoTen;
	char* maSo;
	double diemTB;
};

istream& operator>>(istream& ci, HocSinh& h);
ostream& operator<<(ostream& co, HocSinh& h);
void input(HocSinh* h);
void StandardizeCapitalLetter(char* name);
char* HocSinhToString(const HocSinh* pHS);
#endif // !_HEADER_
