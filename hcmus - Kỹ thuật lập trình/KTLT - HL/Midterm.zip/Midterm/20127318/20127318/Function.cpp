#include"Header.h"

istream& operator>>(istream& ci, HocSinh& h)
{
	h.maSo = new char[100];
	cout << "Nhap ma so: ";
	ci >> h.maSo;
	h.hoTen = new char[100];
	cout << "Nhap ho ten: ";
	ci.ignore();
	ci.getline(h.hoTen, 100);
	cout << "Nhap diem: ";
	ci >> h.diemTB;

	return ci;
}

ostream& operator<<(ostream& co, HocSinh& h)
{
	co << "MSSV: " << h.maSo << endl;
	co << "Ten: " << h.hoTen << endl;
	co << "Diem trung binh: " << h.diemTB << endl;

	return co;
}

void input(HocSinh* h)
{
	cout << "Nhap hoc sinh" << endl;
	cin >> *h;
	cout << endl;
}


double GenerateRandom(const int& min, const int& max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}

void StandardizeCapitalLetter(char* name)
{
	cout << "Chuyen doi chu thuong thanh chu HOA\n";
	name[0] = toupper(name[0]);
	while (strstr(name, " ") != NULL)
	{
		name = strstr(name, " ") + 1;
		name[0] = toupper(name[0]);
	}
}

