﻿/*
Ho va ten : Phan Tri Tai
MSSV : 20127318
*/


//Main
#include"Header.h"

void main()
{
	/*
	srand(1038);
	const char* path = "data.txt";
	HocSinh** data = NULL;
	int nCol = 0, nRow = 0;
	Load(path, data, nCol, nRow);
	PrintData(data, nCol, nRow);
	cout << endl << endl;
	/// xuất ra màn hình Học sinh có điểm trung bình lớn nhất
	/// cần thông tin vị trí của Học sinh
	PrintTheBestHocSinh(data, nCol, nRow);
	FreeData(data, nCol, nRow);
	system("pause");
	*/

	HocSinh* h = new HocSinh[100];
	input(h);
	StandardizeCapitalLetter(h->hoTen);
	cout << h->hoTen << endl;

}