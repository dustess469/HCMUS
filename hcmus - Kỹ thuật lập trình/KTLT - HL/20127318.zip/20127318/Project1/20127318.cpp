/*
Ho va ten : Phan Tri Tai
MSSV : 20127318
*/#include<iostream>using namespace std;//cau 1struct SinglyLinkedList {
    int data;
    struct SinglyLinkedList* next;
};typedef struct SinglyLinkedList* node;

node CreateNode(int value) {
    node temp; // declare a node
    temp = (node)malloc(sizeof(struct SinglyLinkedList));
    temp->next = NULL;
    temp->data = value; 
    return temp;
}node addHead(node head, int value){
    node temp = CreateNode(value); 
    if (head == NULL )
    {
        head = temp; 
    }
    else {
        temp->next = head;
        head = temp;
    }
    return head;
}node addTail(node head, int value) {
    node temp, p;
    temp = CreateNode(value);
    if (head == NULL) {
        head = temp;     
    }
    else {
        p = head;
        while (p->next != NULL) {
            p = p->next;
        }
        p->next = temp;
    }
    return head;
}node removeHead(node head) {
    if (head == NULL) {
        printf("\nList empty");
    }
    else {
        head = head->next;
    }
    return head;
}node removeTail(node head) {
    if (head == NULL || head->next == NULL) {
        return  removeHead(head);
    }
    node p = head;
    while (p->next->next != NULL) {
        p = p->next;
    }
    p->next = p->next->next; 
    return head;
}//cau 2struct Node {
    char* data;
    Node* pNext;
};
struct Stack {
    Node* pHead;
};

void Create(Stack& s) {
    s.pHead = nullptr;
}


void Push(Stack& s, char* c) {
    Node* temp = new Node;
    temp->data = c;
    temp->pNext = nullptr;
    if (s.pHead == nullptr)
        s.pHead = temp;
    else {
        Node* p = s.pHead;
        while (p->pNext != nullptr)
            p = p->pNext;
        p->pNext = nullptr;
    }
}

char* Pop(Stack& s) {
    Node* p = s.pHead;
    if (p == nullptr) {
        cout << "Stack is empty" << endl;
        return 0;
    }
    if (p->pNext == nullptr) {
        char* value = p->data;
        p = nullptr;
        return value;
    }
    while (p->pNext->pNext != nullptr)
        p = p->pNext;
    char* value = p->pNext->data;
    p->pNext = nullptr;
    return value;
}

bool isEmpty(Stack s) {
    if (s.pHead == nullptr)
        return true;
    return false;
}//cau 3struct Node {
    char* data;
    Node* pNext;
};

struct Queue
{
    Node* head;
};

void Create(Queue& q) {
    q.head = nullptr;
}

struct Stack {
    Node* pHead;
};

void Create(Stack& s) {
    s.pHead = nullptr;
}

void Push(Queue& q, char* c) {
    Node* temp = new Node;
    temp->data = c;
    temp->pNext = nullptr;
    if (q.head == nullptr) {
        q.head = temp;
        return;
    }
    Node* p = q.head;
    while (p->pNext != nullptr) {
        p = p->pNext;
    }
    p->pNext = temp;
}

string s = "Error";
char* Pop(Queue& q) {
    if (q.head == nullptr) {
        cout << "Queue is empty" << endl;
        char* c = new char;
        c = &s[0];
        return c;
    }
    char* c = q.head->data;
    q.head = q.head->pNext;
    return c;
}

bool isEmpty(Queue q) {
    if (q.head == nullptr)
        return true;
    return false;
}