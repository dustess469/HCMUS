#include<iostream>

using namespace std;

struct stack
{
	int* data;
	int top;
	int capacity;

};


struct stack* init(int capacity)
{
	struct stack* pt = (struct stack*)malloc(sizeof(struct stack));

	pt->capacity = capacity;
	pt->top = -1;
	pt->data = (int*)malloc(sizeof(int) * capacity);

	return pt;
}

int isFull(struct stack* pt) {
	return pt->top == pt->capacity - 1;
}

void push(struct stack* pt, int x)
{
	if (isFull(pt))
	{
		cout << "Overflow\n";
		exit(EXIT_FAILURE);
	}

	cout << "Them vao: " << x;
	cout << endl;


	pt->data[++pt->top] = x;
}


int isEmpty(struct stack* pt) {
	return pt->top == -1;
}

int peek(struct stack* pt)
{

	if (!isEmpty(pt)) {
		return pt->data[pt->top];
	}
	else {
		exit(EXIT_FAILURE);
	}
}

int pop(struct stack* pt)
{

	if (isEmpty(pt))
	{
		printf("Underflow\n");
		exit(EXIT_FAILURE);
	}

	cout << "Xoa: " << peek(pt) << endl;


	return pt->data[pt->top--];
}

int size(struct stack* pt) {
	return pt->top + 1;
}


int main()
{
	struct stack* pt = init(5);

	push(pt, 1);
	push(pt, 2);
	push(pt, 3);

	cout << "Phan tu o dau: " << peek(pt) << endl;
	cout << "Kich thuoc Stack: " << size(pt) << endl;

	pop(pt);
	pop(pt);
	pop(pt);

	if (isEmpty(pt)) {
		cout << "Kich thuoc cua Stack rong\n";
	}
	else {
		cout << "Kich thuoc cua Stack khong rong\n";
	}

	return 0;
}