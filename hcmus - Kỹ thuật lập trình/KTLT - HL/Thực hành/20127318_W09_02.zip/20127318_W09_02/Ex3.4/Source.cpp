#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <string> 
#include <fstream>


using namespace std;


struct Node {
    int data;
    Node* next;
};

Node* createNode(int value) {
    Node* temp = new Node;
    temp->data = value;
    temp->next = NULL;

    return temp;
}



struct Queue {
    Node* head;
    Node* tail;
    int capacity;
};

void init(Queue& q, int c) {
    q.head = nullptr;
    q.tail = nullptr;
    q.capacity = c;
}

void Enqueue(Queue& q, int x) {
    Node* temp = createNode(x);
    if (q.head == nullptr) {
        q.head = temp;
        q.tail = temp;
        return;
    }
    Node* p = q.head;
    while (p->next != nullptr) {
        p = p->next;
    }
    p->next = temp;
    q.tail = temp;
}

int Dequeue(Queue& q) {
    int val;
    if (q.head == nullptr) {
        cout << "Queue is empty" << endl;
        return 0;
    }
    if (q.head->next == nullptr) {
        val = q.head->data;
        q.head = nullptr;
        q.tail = nullptr;
        return 0;
    }
    val = q.head->data;
    q.head = q.head->next;
    return val;
}

bool isEmpty(Queue q) {
    if (q.head == nullptr)
        return true;
    else
        return false;
}

void Empty(Queue& q) {
    q.head = nullptr;
    q.tail = nullptr;
    q.capacity = 0;
}

int Size(Queue q) {
    int ans = 0;
    Node* p = q.head;
    while (p != nullptr) {
        ++ans;
        p = p->next;
    }
    return ans;
}

void printQ(Queue q) {
    Node* p = q.head;
    if (p == nullptr) {
        cout << "Queue is empty" << endl;
        return;
    }
    while (p != nullptr) {
        cout << p->data << " ";
        p = p->next;
    }
    cout << endl;
}


int main() {
    Queue q;
    init(q, 100);
    cout << "isEmpty: " << isEmpty(q) << endl;
    cout << "Enqueue 3 2 1 into Queue" << endl;
    Enqueue(q, 3);
    Enqueue(q, 2);
    Enqueue(q, 1);
    printQ(q);
    cout << "Dequeue 1 time" << endl;
    Dequeue(q);
    printQ(q);
    cout << "Size: " << Size(q) << endl;
    cout << "Empty Queue" << endl;
    Empty(q);
    printQ(q);
    return 0;
}