#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <string> 
#include <fstream>


using namespace std;


struct Node {
    int data;
    Node* next;
};
struct Stack {
    Node* head;
    int capacity;
};

Node* createNode(int value) {
    Node* temp = new Node;
    temp->data = value;
    temp->next = NULL;

    return temp;
}

void init(Stack& s, int c) {
    s.head = nullptr;
    s.capacity = c;
}


void Push(Stack& s, int x) {
    Node* p = createNode(x);
    Node* p1 = s.head;
    if (p1 == nullptr) {
        s.head = p;
    }
    else {
        while (p1->next != nullptr) {
            p1 = p1->next;
        }
        p1->next = p;
    }
}

int Pop(Stack& s) {
    int value;
    Node* p = s.head;
    if (p == nullptr) {
        cout << "Stack is empty" << endl;
        return 0;
    }
    if (p->next == nullptr) {
        value = p->data;
        p = nullptr;
        return value;
    }
    while (p->next->next != nullptr)
        p = p->next;
    value = p->next->data;
    p->next = nullptr;
    return value;
}

bool isEmpty(Stack& s) {
    if (s.head == nullptr)
        return true;
    return false;
}

void Empty(Stack& s) {
    s.head = nullptr;
}

int Size(Stack& s) {
    int ans = 0;
    Node* p = s.head;
    while (p != nullptr) {
        ++ans;
        p = p->next;
    }
    return ans;
}

void printS(Stack s) {
    Node* p = s.head;
    if (p == nullptr) {
        cout << "Stack is empty" << endl;
        return;
    }
    while (p != nullptr) {
        cout << p->data << " ";
        p = p->next;
    }
    cout << endl;
}


int main() {
    Stack s;
    init(s, 100);
    cout << "isEmpty: " << isEmpty(s) << endl;
    cout << "Push 3 2 1 into stack" << endl;
    Push(s, 3);
    Push(s, 2);
    Push(s, 1);
    printS(s);
    cout << "Pop 1 time" << endl;
    Pop(s);
    printS(s);
    cout << "Size: " << Size(s) << endl;
    cout << "Empty stack" << endl;
    Empty(s);
    printS(s);
    return 0;
}