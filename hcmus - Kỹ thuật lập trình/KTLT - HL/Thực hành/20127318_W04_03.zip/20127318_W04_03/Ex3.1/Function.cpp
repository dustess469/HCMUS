#include "Header.h"

istream& operator>>(istream& is, Fraction& F)
{
	cout << "Nhap tu so: ";
	is >> F.num;
	cout << "Nhap mau so: ";
	is >> F.deno;
	cout << endl;

	return is;
}

ostream& operator<<(ostream& os, Fraction& F)
{
	os << F.num << "/" << F.deno << endl;

	return os;
}

void inputNFraction(Fraction* f)
{
	cout << "Nhap so luong phan so: ";
	cin >> f->n;
	for (size_t i = 0; i < f->n; i++)
	{
		cin >> *(f + i);
	}
}

void outputNFraction(Fraction* f)
{
	for (size_t i = 0; i < f->n; i++)
	{
		cout << "Phan so " << i + 1 << ": " << *(f + i) << endl;
	}
}

Fraction* negativeFraction(Fraction* f)
{
	Fraction* p = new Fraction[100];
	int tmp = 0;
	for (size_t i = 0; i < f->n; i++)
	{
		if (f[i].num * f[i].deno < 0)
		{
			p[tmp] = f[i];
			tmp++;
		}
	}
	p->n = tmp;

	return p;
}

Fraction* positiveFraction(Fraction* f)
{
	Fraction* p = new Fraction[100];
	int tmp = 0;
	for (size_t i = 0; i < f->n; i++)
	{
		if (f[i].num * f[i].deno > 0)
		{
			p[tmp] = f[i];
			tmp++;
		}
	}
	p->n = tmp;

	return p;
}

void Reduction(int& num1, int& deno1)
{
	int a, b;

	a = abs(num1);
	b = abs(deno1);
	while (a != b) {
		if (a > b) {
			a = a - b;
		}
		else {
			b = b - a;
		}
	}
	num1 = num1 / a;
	deno1 = deno1 / a;
}

void sumPositiveFraction(Fraction* f)
{
	int a = f[0].num, b = f[0].deno;

	for (size_t i = 1; i < f->n; i++)
	{
		a = a * f[i].deno + b * f[i].num;
		b = b * f[i].deno;
	}

	Reduction(a, b);
	cout << a << "/" << b << endl;
}
