#ifndef _HEADER_
#define _HEADER_

#include <iostream>

using namespace std;

struct Fraction
{
	int num, deno;
	int n;
};

istream& operator>>(istream& is, Fraction& F);
ostream& operator<<(ostream& os, Fraction& F);
void inputNFraction(Fraction* f);
void outputNFraction(Fraction* f);
Fraction* negativeFraction(Fraction* f);
Fraction* positiveFraction(Fraction* f);
void sumPositiveFraction(Fraction* f);

#endif // !_HEADER_#pragma once
