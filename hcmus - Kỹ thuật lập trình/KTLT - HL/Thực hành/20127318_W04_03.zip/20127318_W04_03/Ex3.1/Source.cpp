#include "Header.h"

int main()
{
	Fraction* f = new Fraction[100];
	inputNFraction(f);
	outputNFraction(f);

	cout << "Danh sach cac phan so am: \n";
	Fraction* n = negativeFraction(f);
	outputNFraction(n);

	cout << "Tong cac phan so duong: \n";

	Fraction* e = positiveFraction(f);
	sumPositiveFraction(e);
	delete[] f;
	delete[] n;
	delete[] e;

	return 0;
}