#ifndef _HEADER_
#define _HEADER_

#include<iostream>
#include<string.h>

using namespace std;

struct Student {
	int id;
	char* name;
	double score;
	char* address;
	int n;
};

istream& operator>>(istream& is, Student& S);
ostream& operator<<(ostream& os, Student& S);
void input(Student* s);
void output(Student* s);

#endif // !_HEADER_
