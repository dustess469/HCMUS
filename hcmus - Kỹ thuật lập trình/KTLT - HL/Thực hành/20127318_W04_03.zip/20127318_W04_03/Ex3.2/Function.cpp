#include"Header.h"

istream& operator>>(istream& is, Student& S)
{
	cout << "Nhap ID: ";
	is >> S.id;
	cout << "Nhap ten: ";
	is.ignore();
	is.getline(S.name,100);
	cout << "Nhap diem: ";
	is >> S.score;
	cout << "Nhap dia chi: ";
	is.ignore();
	is.getline(S.address, 100);
	cout << endl;

	return is;
}

ostream& operator<<(ostream& os, Student& S)
{
	os << "ID: " << S.id << endl;
	os << "Ten: " << S.name << endl;
	os << "Diem: " << S.score << endl;
	os << "Dia chi: " << S.address << endl;

	return os;
}
void input(Student* s)
{
	cout << "Nhap so luong hoc sinh: ";
	cin >> s->n;
	for (size_t i = 0; i < s->n; i++)
	{
		cin >> *(s + i);
	}
}

void output(Student* s)
{
	for (size_t i = 0; i < s->n; i++)
	{
		cout << *(s + i) << endl;
	}
}