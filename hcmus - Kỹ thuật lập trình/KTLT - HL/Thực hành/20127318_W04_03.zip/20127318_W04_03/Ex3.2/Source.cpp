#include"Header.h"

int main()
{
	Student* s = new Student[100];
	input(s);
	output(s);
}