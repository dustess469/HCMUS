#ifndef _HEADER_
#define _HEADER_

#include <iostream>
#include <iomanip>

using namespace std;

int Show_Menu();				 //To show main menu
void Show_Chart();			    //To show seating chart

const char FULL = '*';			//Seat taken
const char EMPTY = '#';		   //Seat open
const int rows = 15;		  //Number of rows
const int columns = 30;		 //Number of seats per row
char map[rows][columns];	//Array to hold seating chart
double price;
int total = 0;
int seat = 450;
int seat2 = 0;
int Quit = 1;

#endif // !_HEADER_
