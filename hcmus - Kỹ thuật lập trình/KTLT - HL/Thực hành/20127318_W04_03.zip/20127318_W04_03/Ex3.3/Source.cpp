#include"Header.h"


int main()
{
	const int Num_Rows = 15;
	int price[Num_Rows];
	int row2, column2, cost;
	int answer;


	//Main Logo

	cout << "\t*********************************************************" << endl;
	cout << "\t*                                                       *" << endl;
	cout << "\t*	  Welcome to The our small town Theater         *" << endl;
	cout << "\t*                                                       *" << endl;
	cout << "\t*********************************************************" << endl;

	cout << endl << endl;



	//Sets the row prices.

	for (int count = 0; count < rows; count++)
	{
		cout << "Please enter the price for row " << (count + 1) << ": ";
		cin >> price[count];

	}

	cout << "_____________________\n\n";

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
			map[i][j] = EMPTY;
	}


	int choice;
	do
	{
		choice = Show_Menu();	  // Shows the main menu function.

		switch (choice)
		{
		case 1:
			cout << "View Seat Prices\n\n";

			for (int count = 0; count < rows; count++)
			{
				cout << "The price for row " << (count + 1) << ": ";
				cout << price[count] << endl;
			}
			cout << "_____________________\n\n";

			break;

		case 2:
			cout << "Purchase a Ticket\n\n";

			do
			{
				cout << "Please select the row you would like to sit in: ";
				cin >> row2;
				cout << "Please select the seat you would like to sit in: ";
				cin >> column2;

				if (map[row2][column2] == '*')
				{
					cout << "Sorry that seat is sold-out, Please select a new seat.";
					cout << endl;
				}

				else
				{
					cost = price[row2] + 0;
					total = total + cost;
					cout << "That ticket costs: " << cost << endl;
					cout << "Confirm Purchase? Enter (1 = YES / 2 = NO)";
					cin >> answer;
					seat = seat - answer;
					seat2 += answer;

					if (answer == 1)
					{
						cout << "Your ticket purchase has been confirmed." << endl;
						map[row2][column2] = FULL;
					}
					else if (answer == 2)
					{
						cout << "Would you like to look at another seat? (1 = YES / 2 = NO)";
						cout << endl;
						cin >> Quit;
					}

					cout << "Would you like to look at another seat?(1 = YES / 2 = NO)";
					cin >> Quit;
				}

			} while (Quit == 1);
			cout << "_____________________\n\n";

			break;

		case 3:
			cout << "View Available Seats\n\n";
			Show_Chart();
			cout << "_____________________\n\n";

			break;

		case 4:
			cout << "View Seat Sales\n\n";
			cout << "$$$	SOLD OUT TICKETS	$$$\n";
			cout << "_____________________\n\n";

			break;

		case 5:
			cout << "Quit\n";
			cout << "_____________________\n\n";
			break;

		default: cout << "Error input\n";
		}

	} while (choice != 5);



	return 0;
}