#include"Header.h"

// Show Menu Function...

int Show_Menu()
{
	int MenuChoice;
	cout << endl << endl;
	cout << " \tMAIN MENU\n";
	cout << " 1. View Seat Prices.\n";
	cout << " 2. Purchase a Ticket.\n";
	cout << " 3. View Available Seats.\n";
	cout << " 4. View Ticket Sales.\n";
	cout << " 5. Quit the program.\n";
	cout << "_____________________\n\n";
	cout << "Please enter your choice: ";
	cin >> MenuChoice;
	cout << endl << endl;
	return MenuChoice;
}



//Show Seating Chart Function

void Show_Chart()
{
	cout << "\tSeats" << endl;
	cout << "      1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30\n";

	for (int count = 0; count < 15; count++)
	{
		cout << endl << "Row " << (count + 1);

		for (int count2 = 0; count2 < 30; count2++)
		{
			cout << " " << map[count][count2];
		}
	}
	cout << endl;
}