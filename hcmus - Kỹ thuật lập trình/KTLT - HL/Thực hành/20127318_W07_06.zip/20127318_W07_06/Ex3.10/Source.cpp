﻿#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <string> 


using namespace std;


//tạo cấu trúc node
struct Node {
    //dữ liệu
    int data;
    Node* pNext;
};
struct MyList {
    Node* pHead;
};

Node* createNode(int value) {
    Node* temp = new Node;
    temp->data = value;
    temp->pNext = NULL;

    return temp;
}

bool checkEmpty(Node* pHead) {
    if (pHead == NULL)
        return true;
    return false;
}

void addHead(Node*& pHead, Node* p) {
    if (checkEmpty(pHead)) {//rỗng
        pHead = p;
    }
    else {
        p->pNext = pHead;
        pHead = p;
    }
}
void addHead(MyList& l, Node* p) {
    if (checkEmpty(l.pHead)) {//rỗng
        l.pHead = p;
    }
    else {
        p->pNext = l.pHead;
        l.pHead = p;
    }
}

void addTail(Node*& pHead, Node* p) {
    if (checkEmpty(pHead)) {//rỗng
        pHead = p;
    }
    else {
        //Tìm thằng cuối
        Node* temp = pHead;//node cuối là temp khi xong while
        while (temp->pNext != NULL) {
            temp = temp->pNext;
        }
        temp->pNext = p;
    }
}

void printList(Node* pHead) {
    Node* temp = pHead;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->pNext;
    }
    cout << endl;
}
void printList(MyList l) {
    Node* temp = l.pHead;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->pNext;
    }
    cout << endl;
}

//3.10
long long ListToNumber(MyList a) {
    long long ans = 0;
    string temp = "";
    Node* p = a.pHead;
    while (p != nullptr) {
        temp += (char)(48 + p->data);
        p = p->pNext;
    }
    ans = stoi(temp);
    return ans;
}


int main() {
    Node* p;
    long long ll;
    MyList list;
    list.pHead = nullptr;
    int a = 1, i = 1;
    cout << "Nhap 0 de dung chuong trinh!" << endl;
    cout << "Nhap danh sach lien ket: " << endl;
    while (a != 0) {
        cout << "Phan tu thu " << i << ": ";
        cin >> a;
        ++i;
        p = createNode(a);
        addTail(list.pHead, p);
    }
    cout << "Danh sach lien ket: ";
    printList(list);

    ll = ListToNumber(list);
    cout << "Chuyen tu linked list sang int: " << ll << endl;

    return 0;
}