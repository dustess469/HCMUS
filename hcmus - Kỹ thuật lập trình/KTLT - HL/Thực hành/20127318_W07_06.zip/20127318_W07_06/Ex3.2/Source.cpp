﻿#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <string> 


using namespace std;


//tạo cấu trúc node
struct Node {
    //dữ liệu
    int data;
    Node* pNext;
};
struct MyList {
    Node* pHead;
};

Node* createNode(int value) {
    Node* temp = new Node;
    temp->data = value;
    temp->pNext = NULL;

    return temp;
}

bool checkEmpty(Node* pHead) {
    if (pHead == NULL)
        return true;
    return false;
}

void addHead(Node*& pHead, Node* p) {
    if (checkEmpty(pHead)) {//rỗng
        pHead = p;
    }
    else {
        p->pNext = pHead;
        pHead = p;
    }
}
void addHead(MyList& l, Node* p) {
    if (checkEmpty(l.pHead)) {//rỗng
        l.pHead = p;
    }
    else {
        p->pNext = l.pHead;
        l.pHead = p;
    }
}

void addTail(Node*& pHead, Node* p) {
    if (checkEmpty(pHead)) {//rỗng
        pHead = p;
    }
    else {
        //Tìm thằng cuối
        Node* temp = pHead;//node cuối là temp khi xong while
        while (temp->pNext != NULL) {
            temp = temp->pNext;
        }
        temp->pNext = p;
    }
}

void printList(Node* pHead) {
    Node* temp = pHead;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->pNext;
    }
    cout << endl;
}
void printList(MyList l) {
    Node* temp = l.pHead;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->pNext;
    }
    cout << endl;
}

//3.2
MyList removeDup(MyList a) {
    Node* p = a.pHead;
    set<int> s;
    MyList newls;
    newls.pHead = nullptr;
    while (p != nullptr) {
        int temp = s.size();
        s.insert(p->data);
        if (s.size() != temp) {
            Node* p1 = createNode(p->data);
            addTail(newls.pHead, p1);
        }
        p = p->pNext;
    }
    return newls;
}

int main() {
    Node* p;
    long long ll;
    MyList list;
    list.pHead = nullptr;
    int a = 1, i = 1;
    cout << "Nhap 0 de dung chuong trinh!" << endl;
    cout << "Nhap danh sach lien ket: " << endl;
    while (a != 0) {
        cout << "Phan tu thu " << i << ": ";
        cin >> a;
        ++i;
        p = createNode(a);
        addTail(list.pHead, p);
    }
    cout << "Danh sach lien ket: ";
    printList(list);

    list = removeDup(list);
    cout << "Danh sach lien ket sau khi xoa di cac phan tu trung lap: ";
    printList(list);

    return 0;
}