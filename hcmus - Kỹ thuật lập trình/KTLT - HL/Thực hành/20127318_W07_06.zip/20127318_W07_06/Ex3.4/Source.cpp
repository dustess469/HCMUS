﻿#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <string> 


using namespace std;


//tạo cấu trúc node
struct Node {
    //dữ liệu
    int data;
    Node* pNext;
};
struct MyList {
    Node* pHead;
};

Node* createNode(int value) {
    Node* temp = new Node;
    temp->data = value;
    temp->pNext = NULL;

    return temp;
}

bool checkEmpty(Node* pHead) {
    if (pHead == NULL)
        return true;
    return false;
}

void addHead(Node*& pHead, Node* p) {
    if (checkEmpty(pHead)) {//rỗng
        pHead = p;
    }
    else {
        p->pNext = pHead;
        pHead = p;
    }
}
void addHead(MyList& l, Node* p) {
    if (checkEmpty(l.pHead)) {//rỗng
        l.pHead = p;
    }
    else {
        p->pNext = l.pHead;
        l.pHead = p;
    }
}

void addTail(Node*& pHead, Node* p) {
    if (checkEmpty(pHead)) {//rỗng
        pHead = p;
    }
    else {
        //Tìm thằng cuối
        Node* temp = pHead;//node cuối là temp khi xong while
        while (temp->pNext != NULL) {
            temp = temp->pNext;
        }
        temp->pNext = p;
    }
}

void printList(Node* pHead) {
    Node* temp = pHead;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->pNext;
    }
    cout << endl;
}
void printList(MyList l) {
    Node* temp = l.pHead;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->pNext;
    }
    cout << endl;
}

//3.4
MyList InsertEven(MyList a) {
    MyList list;
    list.pHead = nullptr;
    int ev = 2;
    Node* p = a.pHead, * temp;
    while (p != nullptr) {
        temp = createNode(ev);
        addTail(list.pHead, temp);
        ev += 2;
        temp = createNode(p->data);
        addTail(list.pHead, temp);
        p = p->pNext;
    }
    return list;
}


int main() {
    Node* p;
    long long ll;
    MyList list;
    list.pHead = nullptr;
    int a = 1, i = 1;
    cout << "Nhap 0 de dung chuong trinh!" << endl;
    cout << "Nhap danh sach lien ket: " << endl;
    while (a != 0) {
        cout << "Phan tu thu " << i << ": ";
        cin >> a;
        ++i;
        p = createNode(a);
        addTail(list.pHead, p);
    }
    cout << "Danh sach lien ket: ";
    printList(list);

    list = InsertEven(list);
    cout << "Danh sach lien ket sau khi them so chan: ";
    printList(list);

    return 0;
}