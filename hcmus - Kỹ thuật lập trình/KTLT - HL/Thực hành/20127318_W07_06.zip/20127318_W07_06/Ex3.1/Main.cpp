#include"Header.h"

int main()
{


	Node* head = NULL;
	head = push(head, 0);
	head = push(head, 6);
	head = push(head, 2);
	head = push(head, 4);
	head = push(head, 2);
	head = push(head, 2);
	head = push(head, 1);


	cout << "New Linked list:\n";
	printList(head);

	int key;
	cout << "\n\nValue want to delete: ";
	cin >> key;

	head = deleteKey(head, key);
	cout << "\nLinked List after delete:\n";
	printList(head);
	cout << endl;

	return 0;
}