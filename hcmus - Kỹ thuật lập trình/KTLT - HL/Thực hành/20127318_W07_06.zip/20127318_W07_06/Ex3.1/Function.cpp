#include"Header.h"

Node* push(Node* head, int new_data)
{
	Node* new_node = new Node();
	new_node->data = new_data;
	new_node->next = head;
	head = new_node;
	return head;
}



Node* deleteKey(Node* head, int x)
{

	Node* tmp = head;

	while (head->data == x)
	{
		head = head->next;
	}
	while (tmp->next != NULL)
	{
		if (tmp->next->data == x)
		{
			tmp->next = tmp->next->next;
		}
		else
		{
			tmp = tmp->next;
		}
	}
	return head;
}


void printList(Node* node)
{
	while (node->next != NULL)
	{
		cout << node->data << " ";
		node = node->next;
	}
	cout << node->data;
}