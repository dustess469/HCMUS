#ifndef _HEADER_
#define _HEADER_

#include <iostream>

using namespace std;

class Node
{
public:
	int data;
	Node* next;
};

Node* push(Node* head, int new_data);
Node* deleteKey(Node* head, int x);
void printList(Node* node);
#endif // !_HEADER_
