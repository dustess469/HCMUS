#include"Header.h"

istream& operator>>(istream& ci, Student& S)
{
	cout << "Nhap MSSV: ";
	ci >> S.mssv;
	S.name = new char[100];
	cout << "Nhap ho ten: ";
	ci.ignore();
	ci.getline(S.name, 100);
	cout << "Nhap diem: ";
	ci >> S.average;

	return ci;
}

ostream& operator<<(ostream& co, Student& S)
{
	co << "MSSV: " << S.mssv << endl;
	co << "Ten: " << S.name << endl;
	co << "Diem trung binh: " << S.average << endl;

	return co;
}

void input(Student* s)
{
	cout << "Nhap so luong hoc sinh: ";
	cin >> s->n;
	for (size_t i = 0; i < s->n; i++)
	{
		cout << "Sinh vien thu " << i + 1 << endl;
		cin >> *(s + i);
		cout << endl;
	}
}

void output(Student* s)
{
	cout << "\nDanh sach sinh vien\n";
	for (size_t i = 0; i < s->n; i++)
	{
		cout << "Sinh vien thu " << i + 1 << endl;
		cout << * (s + i) << endl;
	}
	cout << "-------------\n\n";
}

int logarit(int n)
{
	int dem = 0;
	while (n != 0) 
	{
		n /= 10;
		dem++;
	}
	return dem;
}

void checkMSSV(Student* s)
{
	cout << "\nKiem tra MSSV";
	for (size_t i = 0; i < s->n; i++)
	{
		if (logarit(s[i].mssv) == 7)
		{
			cout << "\nMSSV cua sinh vien thu " << i + 1 << " hop le" << endl;
		}
		else
			cout << "\nMSSV cua sinh vien thu " << i + 1 << " khong hop le" << endl;
	}
	cout << "-------------\n\n";
}

void capitalizeName(Student* s)
{
	cout << "\nHieu chi ten sinh vien";
	for (size_t i = 0; i < s->n; i++)
	{
		for (size_t j = 0; j < strlen(s[i].name); j++)
		{
			s[i].name[0] = toupper(s[i].name[0]);
			if (s[i].name[j] == ' ')
			{
				if (s[i].name[j + 1] >= 'a' && s[i].name[j + 1] <= 'z')
				{
					s[i].name[j + 1] -= 32;
				}
			}
		}
	}
}

bool checkName(char* str, char* name)
{
	int lena = strlen(str);
	int lenb = strlen(name);

	for (int i = 0;i<=lenb-lena; i++)
	{
		for (int j = 0; j < lena; j++)
		{
			if (str[i + j] != name[j])
				break;

			if (j == lena)
				return true;
		}
	}
	return false;
	cout << "-------------\n\n";
}

void compare(Student* s)
{
	cout << "\nSinh vien co diem trung binh cao nhat\n";

	double max = s[0].average;

	for (size_t i = 0; i < s->n; i++)
	{
		if (max < s[i].average)
			max = s[i].average;
	}

	for (size_t i = 0; i < s->n; i++)
	{
		if (s[i].average == max)
			cout << s[i].mssv << " " << s[i].name << " " << s[i].average << endl;
	}

	cout << "-------------\n\n";
}