#include"Header.h"

int main()
{
	Student* s = new Student[100];
	input(s);
	output(s);
	checkMSSV(s);
	capitalizeName(s);

	output(s);

	cout << "\nKiem ta chuoi ki tu";
	char* str = new char[100];
	cin.ignore();
	cout << "\nNhap chuo ki tu: ";
	cin.getline(str, 100);
	cout << checkName(str, s[0].name);
	
	compare(s);
}