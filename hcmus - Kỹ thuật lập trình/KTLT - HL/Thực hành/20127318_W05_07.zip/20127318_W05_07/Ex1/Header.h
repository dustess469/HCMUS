#ifndef _HEADER_
#define _HEADER_

#include<iostream>
#include<string.h>

using namespace std;

struct Student {
	int mssv;
	char* name;
	double average;
	int n;
};

istream& operator>>(istream& ci, Student& S);
ostream& operator<<(ostream& co, Student& S);
void input(Student* s);
void output(Student* s);
void checkMSSV(Student* s);
void capitalizeName(Student* s);
bool checkName(char* str, char* name);
void compare(Student* s);
#endif // !_HEADER_
