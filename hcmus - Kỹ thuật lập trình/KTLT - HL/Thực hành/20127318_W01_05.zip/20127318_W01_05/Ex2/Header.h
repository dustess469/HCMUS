#ifndef _HEARDER_
#define _HEARDER_

#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

struct Circle
{
	double x, y;
	double radius;
};

double Area(Circle a);

#endif // !_HEARDER_