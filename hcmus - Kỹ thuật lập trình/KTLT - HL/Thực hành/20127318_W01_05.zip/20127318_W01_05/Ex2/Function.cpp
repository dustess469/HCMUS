#include "Header.h"

double Area(Circle a)
{
	return 1.00 * 3.14 * pow(a.radius, 2);
}