#include "Header.h"

int main()
{

    ifstream file1;
    Circle c[100];
    int number;
    int i = 0;

    file1.open("input.txt");

    if (!file1.is_open())
    {
        cout << "Can not open file input\n";
        return 0;
    }

    file1 >> number;

    while (!file1.eof())
    {
        file1 >> c[i].x >> c[i].y >> c[i].radius;
        i++;
    }

    file1.close();

    /////////////////////////////////////////////////

    ofstream file2;
    file2.open("output.txt");

    if (!file2.is_open())
    {
        cout << "Can not open file output\n";
        return 0;
    }

    file2 << number << endl;

    for (size_t i = 0; i < number; i++)
    {
        file2 << Area(c[i]) << endl;
    }

    file2.close();

    cout << "Write file successfully\n";

    return 0;
}