#ifndef _HEADER_
#define _HEADER_

#include <iostream>
#include <string.h>
#include <string>
#include <fstream>

using namespace std;

struct Fraction
{
    int tu, mau;
};

int UCLN(int a, int b);
void reduction(Fraction& a);
double calculate(Fraction a);
void sortAscending(Fraction arr[], int n);

#endif // !_HEADER_