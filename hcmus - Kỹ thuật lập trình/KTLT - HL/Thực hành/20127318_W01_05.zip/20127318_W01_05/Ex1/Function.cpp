#include "Header.h"

int UCLN(int a, int b)
{
    if (a == 0 || b == 0)
    {
        return a + b;
    }

    while (a != b)
    {
        if (a > b)
        {
            a -= b;
        }
        else
            b -= a;
    }
    return a;
}

void reduction(Fraction& a)
{
    // Negative number
    if (a.tu * a.mau < 0)
    {
        int temp = -a.tu;
        int tmp = UCLN(temp, a.mau);
        a.tu = a.tu / tmp;
        a.mau = a.mau / tmp;
    }
    else 
    {
        int tmp = UCLN(a.tu, a.mau);
        a.tu = a.tu / tmp;
        a.mau = a.mau / tmp;
    }
}

double calculate(Fraction a)
{
    reduction(a);
    return (a.tu * 1.0) / a.mau;
}

void sortAscending(Fraction arr[], int n)
{
    int min;
    Fraction tmp;

    for (int i = 0; i < n; i++)
    {
        min = i;
        for (int j = i + 1; j < n; j++)
        {
            if (calculate(arr[j]) < calculate(arr[min]))
                min = j;
        }
        tmp = arr[i];
        arr[i] = arr[min];
        arr[min] = tmp;
    }
}