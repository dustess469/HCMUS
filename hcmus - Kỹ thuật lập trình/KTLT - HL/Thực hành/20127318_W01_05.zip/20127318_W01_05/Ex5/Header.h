#ifndef _HEARDER_
#define _HEARDER_

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;

struct Student
{
	string id;
	float gpa;
	string fullName;
};

void sortStudent(Student arr[], int n);

#endif // !_HEARDER_