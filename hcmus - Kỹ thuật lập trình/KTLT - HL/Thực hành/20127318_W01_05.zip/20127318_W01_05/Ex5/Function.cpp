#include "Header.h"

void sortStudent(Student arr[], int n) {
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (arr[i].gpa < arr[j].gpa) {
                Student temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            if (arr[i].gpa == arr[j].gpa) {
                if (arr[i].id > arr[j].id) {
                    Student temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }
}