#include "Header.h"

int main()
{

    ifstream file1;
    Student s[100];
    int n;
    int i = 0;
    string temp;

    file1.open("input.txt");

    if (!file1.is_open())
    {
        cout << "Can not open file input\n";
        return 0;
    }

    file1 >> n;

    while (!file1.eof())
    {
        file1 >> temp;
        s[i].id = temp;
        file1.ignore(1);
        getline(file1, temp);
        s[i].fullName = temp;
        file1 >> temp;
        s[i].gpa = atof(temp.c_str());
        i++;
    }



    sortStudent(s, n);

    file1.close();

    ////////////////////////////////////////////

    ofstream file2;
    file2.open("output.txt");

    if (!file2.is_open())
    {
        cout << "Can not open file input\n";
        return 0;
    }

    file2 << s[0].id << endl;
    file2 << s[0].fullName << endl;
    file2 << s[0].gpa << endl;

    file2.close();

    cout << "Write file successfully\n";

    return 0;
}