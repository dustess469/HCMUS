#include "Header.h"

long total(Product arr[], int n)
{
	long value = 0;
	for (int i = 0; i < n; i++)
		value = value + (arr[i].price * arr[i].stock);
	return value;
}