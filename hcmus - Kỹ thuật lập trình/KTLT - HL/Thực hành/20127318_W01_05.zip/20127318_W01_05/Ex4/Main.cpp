#include "Header.h"

int main()
{
    ifstream file1;
    Product p[100];
    int n;
    int i = 0;

    file1.open("input.txt");

    if (!file1.is_open())
    {
        cout << "Can not open file input\n";
        return 0;
    }

    file1 >> n;

    while (!file1.eof())
    {
        file1 >> p[i].id;
        file1.ignore();
        getline(file1, p[i].name, '\n');
        file1 >> p[i].stock;
        file1 >> p[i].price;
        i++;
    }

    total(p, n);

    file1.close();

    ////////////////////////////////////////////

    ofstream file2;
    file2.open("output.txt");

    if (!file2.is_open())
    {
        cout << "Can not open file input\n";
        return 0;
    }

    //file2 << n << endl;

    file2 << total(p, n) << endl;
    

    file2.close();

    cout << "Write file successfully\n";

    return 0;
}