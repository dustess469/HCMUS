#ifndef _HEARDER_
#define _HEARDER_

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Product
{
	int id, stock;
	string name;
	long price;
};

long total(Product arr[], int n);

#endif // !_HEARDER_