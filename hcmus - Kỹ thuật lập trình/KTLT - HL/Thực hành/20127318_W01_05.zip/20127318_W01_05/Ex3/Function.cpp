#include "Header.h"

bool compare(const Date& d1, const Date& d2)
{
    if (d1.year < d2.year)
        return true;
    if (d1.year == d2.year && d1.month < d2.month)
        return true;
    if (d1.year == d2.year && d1.month == d2.month &&
        d1.day < d2.day)
        return true;

    return false;
}


void sortDate(Date arr[], int n)
{
    sort(arr, arr + n, compare);
}