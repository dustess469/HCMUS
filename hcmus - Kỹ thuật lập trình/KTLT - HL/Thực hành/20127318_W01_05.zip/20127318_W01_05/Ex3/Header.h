#ifndef _HEARDER_
#define _HEARDER_

#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

struct Date
{
	int year, month, day;
};

bool compare(const Date& d1, const Date& d2);
void sortDate(Date arr[], int n);

#endif // !_HEARDER_