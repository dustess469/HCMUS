#include "Header.h"

int main()
{

    ifstream file1;
    Date d[100];
    int n;
    int i = 0;

    file1.open("input.txt");

    if (!file1.is_open())
    {
        cout << "Can not open file input\n";
        return 0;
    }

    file1 >> n;

    while (!file1.eof())
    {
        file1 >> d[i].year >> d[i].month >> d[i].day;
        i++;
    }

    sortDate(d, n);

    file1.close();

    ////////////////////////////////////////////

    ofstream file2;
    file2.open("output.txt");

    if (!file2.is_open())
    {
        cout << "Can not open file output\n";
        return 0;
    }

    file2 << n << endl;

    for (size_t i = 0; i < n; i++)
    {
        file2 << d[i].year << " " << d[i].month << " " 
            << d[i].day << endl;

    }

    file2.close();

    cout << "Write file successfully\n";

    return 0;
}