#include<iostream>
#include<string.h>

using namespace std;

bool isPalindrome(char* cstr)
{
	char* front = cstr;
	char* back = cstr + strlen(cstr) - 1;

	while (front <= back)
	{
		// Complete code here
		if (*back == *front)
		{
			back--;
			front++;
		}
		else break;
	}

	if (front > back)
		return true;
	return false;
}

int main()
{
	char a[100];
	bool check;

	cout << "Please enter an word or phrase: ";
	cin.getline(a, 30);

	check = isPalindrome(a);

	if (check == true)
	{
		cout << "\nInput is a palindrome\n";
	}
	else
	{
		cout << "\nInput is not a palindrome\n";
	}

	return 0;
}
