#include <iostream>

using namespace std;

void addOne(int* ptrNum) 
{
	(*ptrNum) = (*ptrNum) + 1;
}

int main() 
{
	int n;
	cout << "Enter n: ";
	cin >> n;

	cout << "\nCurrent value: " << n << endl;
	
	addOne(&n);
	
	cout << "\nValue after increase: " << n << endl;
	return 0;
}