#include <iostream>

using namespace std;

int getMode(int array[], const int size)
{
    int maxValue = 0,
        maxCount = 0,
        i, j;

    for (i = 0; i < size; i++)
    {
        int count = 0;

        for (j = 0; j < size; j++)
        {
            if (*(array + j) == *(array + i))
            {
                count++;
            }
        }

        if (count > maxCount)
        {
            maxCount = count;
            maxValue = *(array + i);
        }
        else if (maxCount == 1)
            maxValue = -1;
    }

    return maxValue;
}

int main()
{
    int size;
    cout << "Enter the size of array: ";
    cin >> size;

    int* numberList = new int[size];
    cout << endl;

    for (int i = 0; i < size; i++)
    {
        cout << "Enter the number " << i + 1 << ": ";
        cin >> numberList[i];
    }

    int mode = getMode(numberList, size);

    cout << "\nMode = " << mode << endl;

    return 0;
}