#include<iostream>

using namespace std;

int doSomething(int* x, int* y)
{
    int temp = *x;
    *x = *y * 10;
    *y = temp * 10;
    return *x + *y;
}

int main()
{
    int x;
    int y;

    cout << "Enter x: ";
    cin >> x;
    cout << "Enter y: ";
    cin >> y;
    
    cout << "\nAfter run function doSomething: " << doSomething(&x, &y) << endl;

}