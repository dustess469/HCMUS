#include<iostream>

using namespace std;

double getMedian(int array[], const int size)
{
	double median = 0.0;

	if (size % 2 != 0)
	{
		median = *(array + (size / 2));
	}
	else
		median = (*(array + ((size - 1) / 2)) + *(array + (size / 2))) / 2.0;

	return median;
}

int main()
{
	int size;
	cout << "Enter the size of array: ";
	cin >> size;

	int* numberList = new int[size];
	cout << endl;

	for (int i = 0; i < size; i++)
	{
		cout << "Enter the number " << i + 1 << ": ";
		cin >> numberList[i];
	}

	double median = getMedian(numberList, size);
	cout << "\nThe median of the array: " << median << endl;

	return 0;
}