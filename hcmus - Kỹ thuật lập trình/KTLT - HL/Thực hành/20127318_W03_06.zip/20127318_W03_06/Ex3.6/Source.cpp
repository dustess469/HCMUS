#include <iostream>

using namespace std;

int* doubleArraySize(int array[], const int size)
{
    const int NEW_SIZE = size * 2;
    int* newArray = new int[NEW_SIZE];

    for (int i = 0; i < NEW_SIZE; i++)
    {
        if (i >= size)
            *(newArray + i) = 0;
        else
            *(newArray + i) = array[i];
    }

    return newArray;
}

void displayArray(int* array, const int size)
{
    for (int i = 0; i < size; i++)
        cout << *(array + i) << " ";
}

int main()
{
    int size;
    cout << "Enter the size of array: ";
    cin >> size;

    int* numberList = new int[size];
    cout << endl;

    for (int i = 0; i < size; i++)
    {
        cout << "Enter the number " << i + 1 << ": ";
        cin >> numberList[i];
    }
    int* numbers_doubled = doubleArraySize(numberList, size);

    displayArray(numberList, size);
    cout << endl;
    displayArray(numbers_doubled, (size * 2));
    cout << endl << endl;

    delete[] numbers_doubled;
    numbers_doubled = nullptr;

    return 0;
}