﻿//Which one of the following is not a possible state for a pointer.
//đáp án: D.point to a tye