#include<stdio.h>

int main()
{
	int x = 20, * y, * z;

	y = &x;
	z = y;
	*y++;
	*z++;
	x++;
	printf("x = %d, y = %d, z = %d \n", x, y, z);
	return 0;
}

//output: x = 21, y = -1356859992, z = -1356859992