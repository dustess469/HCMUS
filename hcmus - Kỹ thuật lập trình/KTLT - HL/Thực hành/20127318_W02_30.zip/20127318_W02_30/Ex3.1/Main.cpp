﻿#include <iostream>

using namespace std;

void main()
{
	int a = 3;
	int* b = &a;
	cout << b << endl; 
	//print the value of variable b: 004FFAD8

	cout << *b << endl; 
	//print the value at the virtual memory address of variable b: 3

	cout << &b << endl; 
	//print the virtual memory address of variable b: 004FFACC

	cout << a << endl; 
	//print the value of variable a: 3

	cout << &a << endl; 
	//print the virtual memory address of variable a: 004FFAD8
}