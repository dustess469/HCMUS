//What is a pointer?
//answer: A.Pointer contains an address of a variable