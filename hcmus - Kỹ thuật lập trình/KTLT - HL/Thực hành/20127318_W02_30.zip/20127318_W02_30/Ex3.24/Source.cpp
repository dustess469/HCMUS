//Which operator returns the address of unallocated blocks in memory?
//answer: C.The new operator