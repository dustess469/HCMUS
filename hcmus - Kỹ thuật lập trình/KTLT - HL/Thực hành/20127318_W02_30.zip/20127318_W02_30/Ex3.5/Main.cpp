#include<iostream>

using namespace std;

void main()
{
	int v = 8, * r, * s;
	int* p;
	int q = 100;
	p = &q;
	r = p;
	*p = 20;
	p = new int;
	*r = 30;
	q = v;
	s = p;
	*s = 50;

	cout << *p << endl; //print the value at the virtual memory address of variable p: 50
	cout << q << endl;  //print the value of variable q: 8
	cout << *r << endl; //print the value at the virtual memory address of variable r: 8
	cout << v << endl;  //print the value of variable v: 8 
	cout << *s << endl; //print the value at the virtual memory address of variable s: 50
}