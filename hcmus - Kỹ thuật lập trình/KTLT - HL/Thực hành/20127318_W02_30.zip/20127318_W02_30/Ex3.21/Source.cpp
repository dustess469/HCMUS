//a pointer can be initialized with
//answer: D.All of them