﻿//Which of the following is illegal?
//đáp án: C. int i; double* dp = &i;