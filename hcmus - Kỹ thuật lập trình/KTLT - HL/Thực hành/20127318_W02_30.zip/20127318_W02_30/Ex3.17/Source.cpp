﻿int a = 100, b = 200;
int* p = &a, * q = &b;
p = q;

//đáp án: B.p now points to b