﻿//chosse the right option
//string *x,y
//đáp án: A.x is a pointer to a string, y is a string