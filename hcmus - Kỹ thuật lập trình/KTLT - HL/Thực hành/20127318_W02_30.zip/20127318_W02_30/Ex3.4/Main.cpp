#include <iostream>

using namespace std;

void main()
{
	int a = 3;
	int* p = &a;
	cout << *p << endl; //print the value at the virtual memory address of variable p(before): 3
	p = new int(5);
	cout << *p << endl; //print the value at the virtual memory address of variable p(after): 5
}