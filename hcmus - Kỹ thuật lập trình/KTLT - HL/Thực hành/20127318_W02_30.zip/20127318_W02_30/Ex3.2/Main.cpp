﻿#include <iostream>

using namespace std;

void main()
{
	int x, z;
	float y;
	char ch, * chp;
	int* ip1, * ip2;
	float* fp;
		
	x = 100;
	y = 20.0;
	z = 50;
	ch = 'Z';

	ip1 = &x;
	ip2 = &z;
	fp = &y;
	chp = &ch;

	ip2 = ip1;
	ip1 = &z;
	*ip1 = *ip2;

	*ip1 = 200;
	*ip1 = *ip2 + 300;
	*fp = 1.2;

	cout << x << endl; //print the value of variable x: 100
	cout << y << endl; //print the value of variable y: 1.2
	cout << z << endl; //print the value of variable z: 400

	cout << ip1 << endl;  //print the value of variable ip1: 008FFC58
	cout << *ip1 << endl; //print the value at the virtual memory address of variable ip1: 400
	cout << &ip1 << endl; //print the virtual memory address of variable ip1: 008FFC28

	cout << ip2 << endl;  //print the value of variable ip2: 008FFC64
	cout << *ip2 << endl; //print the value at the virtual memory address of variable ip2: 100
	cout << &ip2 << endl; //print the virtual memory address of variable ip2: 008FFC1C

	cout << fp << endl;  //print the value of variable fp: 008FFC4C
	cout << *fp << endl; //print the value at the virtual memory address of variable fp: 1.2
	cout << &fp << endl; //print the virtual memory address of variable fp: 008FFC10

	cout << chp << endl;  //print the value of variable chp: Z╠╠╠╠╠╠╠╠ÜÖÖ?╠╠╠╠╠╠╠╠É☺
	cout << *chp << endl; //print the value at the virtual memory address of variable: Z
	cout << &chp << endl; //print the virtual memory address of variable chp: 008FFC34
}