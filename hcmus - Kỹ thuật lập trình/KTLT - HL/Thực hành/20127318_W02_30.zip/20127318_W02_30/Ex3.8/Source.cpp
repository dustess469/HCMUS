﻿#include <stdio.h>
#include<string.h>

int main()
{
	int i, n;
	char* x = "Alice";
	n = strlen(x);
	*x = x[n];
	for (i = 0 ; i <= n; i++)
	{
		printf("%s ", x);
		x++;
	}
	printf("\n", x);
	return 0;
}

//Đáp án: a value of type "const char *" cannot be used to initialize an entity of type "char 