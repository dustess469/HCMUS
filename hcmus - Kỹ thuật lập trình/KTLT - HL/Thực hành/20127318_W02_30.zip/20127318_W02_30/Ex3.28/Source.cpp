//There are how many values that can be used to initialize a pointer
//answer: C.3