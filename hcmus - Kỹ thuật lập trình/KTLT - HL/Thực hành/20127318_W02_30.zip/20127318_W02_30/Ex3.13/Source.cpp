﻿//the operator used for dereferencing or indirection is
//Đáp án: A.*