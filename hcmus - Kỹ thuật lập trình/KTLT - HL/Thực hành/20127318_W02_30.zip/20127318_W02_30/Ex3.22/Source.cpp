//Which from the following is not a correct way to pass a pointer to a function?
//answer: D.All of them