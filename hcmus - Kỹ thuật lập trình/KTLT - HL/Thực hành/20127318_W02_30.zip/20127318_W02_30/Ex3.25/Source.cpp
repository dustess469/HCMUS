//Referencing a value through a pointer is called
//answer: B.Indirection