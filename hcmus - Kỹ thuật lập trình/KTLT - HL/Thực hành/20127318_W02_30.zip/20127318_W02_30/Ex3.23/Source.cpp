//A qualifier that enables the programmers to inform the compiler that the value of a particular variable should not be modified?
//answer: B.const