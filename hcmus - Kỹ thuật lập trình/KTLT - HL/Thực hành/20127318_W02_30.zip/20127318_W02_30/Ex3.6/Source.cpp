﻿#include <iostream>

using namespace std;

int main()
{
	int* p, * q, v, nom[5];
	p = &v;
	*p = 12;
	q = p;
	nom[0] = *q;
	p = nom;
	p++;
	nom[2] = 12;
	*p = 13;
	*q = 10;
	v = 11;
	*(p + 3) = 16;
	p = &nom[3];
	*p = 10;
	p--;

	cout << *p << endl; //xuất ra giá trị của biến p đang trỏ đến: 12
	cout << *q << endl; //xuất ra giá trị của biến q đang trỏ đến: 11
	cout << v << endl; //xuất ra giá trị của biến v: 11
	cout << nom << endl; //xuất ra giá trị của biến nom: 000000D130EFF7A8
}