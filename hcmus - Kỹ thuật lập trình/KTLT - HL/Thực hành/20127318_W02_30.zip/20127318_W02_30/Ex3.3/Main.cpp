#include <iostream>

using namespace std;

void main()
{
	int* a = new int;
	int* b = new int;
	*a = 2;
	b = a;
	cout << *a << endl; //print the value at the virtual memory address of variable a: 2
	cout << *b << endl; //print the value at the virtual memory address of variable b: 2
	delete a; //error memory release 
	delete b; //error memory release 
}