//Which unary operator is used for determining size of array
//answer: A.sizeof