//A unary operator that returns the address of its operands, are called
//answer: A.Pointer operator