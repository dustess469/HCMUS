﻿#include <stdio.h>

int main()
{
	int* x;
	*x = 100;
	return 0;
}

//Đáp án: A.Error: invalid assignment for x