#include <iostream>
#include <math.h>

using namespace std;

struct Linklist {
	int data;
	Linklist* next;
};

struct list {
	Linklist* head;
};

void init(list a) {
	Linklist* p = a.head;
	p = nullptr;
}

Linklist* taoNode(int data) {
	Linklist* node = new Linklist;
	node->data = data;
	node->next = NULL;
	return node;
}

void chenThem(list& a, int data) {
	Linklist* p = new Linklist;
	p->data = data;
	p->next = a.head;
	a.head = p;
}

Linklist* taoNode1(list& a, int data) {
	Linklist* newnode = new Linklist;
	newnode->data = data;
	newnode->next = nullptr;
	return newnode;
}

// cau a
void nhapList(list& a, int n) {
	int data;
	n = n + 1;
	int mu = 0;
	while (n != 0) {
		cout << "a" << mu << ": ";
		cin >> data;
		chenThem(a, data);
		++mu;
		--n;
	}
}

void nhapList1(list& a, int n) {
	n = n + 1;
	while (n != 0) {
		chenThem(a, 0);
		--n;
	}
}

//cau b
void xuatList(list a, int n) {
	if (a.head == nullptr) {
		cout << " ";
		return;
	}
	while (a.head != nullptr) {
		if (a.head->next == nullptr) {
			if (n == 0) {
				cout << a.head->data;
			}
			else {
				cout << a.head->data << "x^" << n;
			}
		}
		else if (a.head->data == 0) {
			--n;
		}
		else {
			cout << a.head->data << "x^" << n << " + ";
			--n;
		}
		a.head = a.head->next;
	}
	cout << endl;
}

// cau c
double tongX0(list a, int n, int x0) {
	double sum = 0;
	Linklist* p = a.head;
	if (p == nullptr) return 0;
	else {
		while (n >= 0) {
			sum += p->data * pow(x0, n);
			p = p->next;
			--n;
		}
	}
	return sum;
}

// cau d
void congDathuc(list a, list b, list& c, int n, int m, int& k) {
	if (n >= m) {
		k = n;
	}
	else k = m;
	nhapList1(c, k);
	Linklist* p1 = a.head;
	Linklist* p2 = b.head;
	Linklist* p3 = c.head;
	if (p1 == NULL || p2 == nullptr) {
		cout << "0\n";
		return;
	}
	while (n >= 0) {
		if (n == m) {
			p3->data = p1->data + p2->data;
			--n;
			--m;
			p1 = p1->next;
			p2 = p2->next;
		}
		else if (n > m) {
			p3->data = p1->data;
			p1 = p1->next;
			--n;
		}
		else {
			p3->data = p2->data;
			p2 = p2->next;
			--m;
		}
		p3 = p3->next;
	}
}


int main() {
	list a = { 0 }, b = { 0 }, c = { 0 };
	int n, m, k;
	double x0;
	cout << "Nhap bac cua da thuc 1: ";
	cin >> n;
	cout << "Nhap da thuc 1: " << endl;
	nhapList(a, n);
	xuatList(a, n);
	cout << "Nhap x0 cua da thuc 1: ";
	cin >> x0;
	cout << "Gia tri cua da thuc 1 tai x0: " << tongX0(a, n, x0) << endl;
	cout << endl;
	cout << "\nNhap bac cua da thuc 2: ";
	cin >> m;
	cout << "Nhap da thuc 2: " << endl;
	nhapList(b, m);
	cout << "\nKet qua cong 2 da thuc: ";
	congDathuc(a, b, c, n, m, k);
	xuatList(c, k);
	return 0;
}