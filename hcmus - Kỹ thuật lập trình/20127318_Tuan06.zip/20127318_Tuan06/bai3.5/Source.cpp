#include<iostream>

using namespace std;

struct Linklist {
	int data;
	Linklist* next;
};

struct list {
	Linklist* head;
};

void init(list ls) {
	Linklist* p = ls.head;
	p = nullptr;
}

void chenThem(list& ls, int data) {
	Linklist* p = new Linklist;

	p->data = data;
	p->next = ls.head;
	ls.head = p;
}

void nhapList(list& ls, int n) {
	int a;
	while (n != 0) {
		cout << "Nhap so: ";
		cin >> a;
		chenThem(ls, a);
		n--;
		if (n < 0) 
			cout << "Nhap sai! Moi nhap lai" << endl;
	}

}


// cau a
int tinhTong(list& ls) {
	Linklist* p = ls.head;
	if (p == nullptr) return 0;
	else
	{
		ls.head = p->next;
		return tinhTong(ls) + p->data;
	}

}

void swap(Linklist*& current, Linklist*& nextnode) {
	Linklist* temp = new Linklist;
	current = temp;
	current = nextnode;
	temp = current;
}


// cau b
bool kiemTra(list& ls, int nums) {
	Linklist* p = ls.head;
	if (p == nullptr) {
		return false;
	}
	else {
		while (p != nullptr) {
			if (p->data == nums) {
				return true;
			}
			p = p->next;
		}
		return false;
	}
}


//cau c
void sapXep(list& ls) {
	Linklist* current = ls.head;
	Linklist* nextnode = current->next;
	for (current; current != nullptr; current = current->next) {
		for (nextnode = current; nextnode != nullptr; nextnode = nextnode->next) {
			if (current->data > nextnode->data) {
				swap(current->data, nextnode->data);
			}
		}
	}

}


void xuatList(list ls) {
	while (ls.head != nullptr)
	{
		cout << ls.head->data << " ";
		ls.head = ls.head->next;
	}
}

int main() {

	int n;
	int x;
	cout << "Nhap gia tri can kiem tra: ";
	cin >> x;
	cout << "\nSo luong phan tu co trong danh sach lien ket: ";
	cin >> n;
	if (n == 0) {
		cout << "\nNhap sai! Moi nhap lai\n";
		return 0;
	}
	list ls1 = { 0 };
	init(ls1);
	nhapList(ls1, n);
	cout << "\nKiem tra: ";
	cout << kiemTra(ls1, x);
	cout << endl;
	cout << "\nSau khi sap xep: ";
	sapXep(ls1);
	xuatList(ls1);
	cout << endl;
	cout << "\nTong so la: " << tinhTong(ls1) << endl;
	return 0;
}