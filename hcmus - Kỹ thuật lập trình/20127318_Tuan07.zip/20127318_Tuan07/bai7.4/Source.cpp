#include<iostream>
#include<vector>

using namespace std;

bool prime(int x) {
	int count = 0;
	for (int i = 1; i <= x; ++i) {
		if (x % i == 0) {
			++count;
		}
	}
	if (count == 2) {
		return true;
	}
	return false;
}

int main() {
	vector<int> x;
	int n;
	cout << "Nhap so nguyen: ";
	cin >> n;
	if (n == 1) {
		cout << "Nhap sai!\n";
	}
	x.resize(n - 1);
	for (int i = 0; i < x.size(); ++i) {
		x[i] = i + 2;
	}
	for (auto pass : x) {
		if (prime(pass) == true) {
			cout << pass << " ";
		}
	}
	return 0;
}