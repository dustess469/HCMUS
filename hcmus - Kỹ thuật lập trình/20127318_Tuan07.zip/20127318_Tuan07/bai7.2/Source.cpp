#include <iostream>
#include <array>
#include <vector>
#include <functional>

using namespace std;


int main() {
	int a, b;
	cin >> a >> b;
	[](int a, int b) {return a * b; }(a, b);


	int multiply = [](int a, int b) {return a * b; }(a, b);
	cout << "Multiply: " << multiply << endl;
	

	multiply = [](int a, int b) {return a * b; }(2,10);
	int product = multiply;
	cout << "Product: " << product << endl;
	return 0;
}