#include"Header.h"


int main() {
	array_double();
	cout << endl;
	
	vector_num();
	cout << endl;

	auto_num();
	cout << endl;

	insert_pos();
	cout << endl;

	food();
	cout << endl;

	binary_search();
	return 0;

}