#ifndef bai1
#define bai1

#include<iostream>
#include<array>
#include<vector>
#include<map>
#include<algorithm>

using namespace std;

void array_double();

void vector_num();

void auto_num();

void insert_pos();

void food();

void binary_search();
#endif