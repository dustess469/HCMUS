#include"Header.h"

void array_double() {
	array<double, 10>numbers = { 12.2,3.4,6.7,8.7,5.6,1.8,6.7,7.8,7.5,8.9 };
	array<double, 10>::iterator a;
	for (a = numbers.begin(); a != numbers.end(); a++) {
		cout << *a << " ";
	}
}

void vector_num() {
	vector<int>vector1 = { 10,20,30,40,50 };
	vector<int>vct;
	vector<int>::iterator v;
	vct = vector1;
	for (v = vct.begin(); v != vct.end(); v++) {
		cout << *v << " ";
	}
}

void auto_num() {
	cout << endl;
	array<double, 10>numbers = { 12.2,3.4,6.7,8.7,5.6,1.8,6.7,7.8,7.5,8.9 };
	array<double, 10>::iterator a;
	for (auto x : numbers) {
		cout << x << " ";
	}
	cout << endl;
	vector<int>vt = { 10,20,30,40,50 };
	vector<int>vct;
	vector<int>::iterator v;
	vct = vt;
	for (auto x : vct) {
		cout << x << " ";
	}

}

void insert_pos() {
	vector<int>vector1 = { 10,20,30,40,50,60,70 };
	vector<int>::iterator v;
	int n; 
	cout << "Nhap gia tri can chen vao trung tam: ";
	cin >> n;
	int pos = vector1.size() / 2;
	vector1.insert(vector1.begin() + pos, n);
	cout << "Sau khi chen: ";
	for (auto num : vector1) {
		cout << num << " ";
	}
}

void food() {
	map<string, int >food;
	string s;
	int n; cout << "Nhap so luong thuc an: ";
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> s;
		food.emplace(s, i);
	}
	for (auto& x : food) {
		cout << x.second << " " << x.first << endl;
	}
}

void binary_search() {
	cout << endl;
	vector<int>vt = { 10,20,30,40,50,60,70 };
	vector<int>::iterator v;
	int n;
	cout << "So can tim: "; 
	cin >> n;
	for (v = vt.begin(); v != vt.end(); v++) {
		if (binary_search(vt.begin(), vt.end(), n)) {
			cout << n << " co trong vector\n";
			break;
		}
		else {
			cout << "Khong co trong vector\n";
			break;
		}
	}
}