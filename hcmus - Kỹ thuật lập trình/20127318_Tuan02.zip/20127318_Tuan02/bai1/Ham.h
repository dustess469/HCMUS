#ifndef bai1
#define bai1

#include<iostream>

using namespace std;

int taiTho(int n);

#endif // !bai1
