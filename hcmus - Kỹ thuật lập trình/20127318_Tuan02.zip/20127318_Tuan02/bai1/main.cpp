#include"Ham.h"

int main() {
	int n;
	cout << "Nhap so tho: ";
	cin >> n;
	cout << "Ket qua 1: " << taiTho(n);
	return 0;
}