#include"Ham.h"

int taiTho(int n) {
	if (n == 0)
		return 0;
	else if (n % 2 == 0)
		return taiTho(n - 1) + 3;
	else
		return taiTho(n - 1) + 2;
}