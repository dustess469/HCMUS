#include"Ham.h"

int them(int tongWrap, int wrap) {
	if (tongWrap < wrap)
		return 0;
	else {
		int bonus = tongWrap / wrap;
		int tmp = bonus + (tongWrap % wrap);
		return bonus + them(tmp, wrap);
	} 
}

int chocolate(int tien, int gia, int wrap) {
	int choco = tien / gia;
	return choco + them(choco, wrap);
}