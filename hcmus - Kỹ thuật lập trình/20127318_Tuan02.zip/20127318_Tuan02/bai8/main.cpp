#include"Ham.h"

int main() {
	int tien, gia, wrap;
	cout << "Nhap tien: ";
	cin >> tien;
	cout << "Nhap gia: ";
	cin >> gia;
	cout << "Nhap wrap: ";
	cin >> wrap;
	cout << "So luong chocolate duoc nhan nhieu nhat la: " << chocolate(tien, gia, wrap);
	return 0;
}