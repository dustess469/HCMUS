#ifndef bai8
#define bai8

#include<iostream>

using namespace std;

int them(int tongWrap, int wrap);
int chocolate(int tien, int gia, int wrap);
#endif // !bai8
