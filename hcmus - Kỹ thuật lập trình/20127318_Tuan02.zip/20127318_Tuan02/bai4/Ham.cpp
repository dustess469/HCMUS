#include"Ham.h"

void parenBit(char* s, int n, int flag) {
	if (n == strlen(s)) return;
	else {
		if (s[n] == '(') {
			flag = 1;
			cout << '(';
			return parenBit(s, n + 1, flag);
		}
		else if (s[n] == ')') {
			flag = 0;
			cout << ')';
			return parenBit(s, n + 1, flag);
		}
	}
	if (flag == 1) {
		cout << s[n];
		return parenBit(s, n + 1, flag);
	}
	if (flag == 0) {
		parenBit(s, n + 1, flag);
	}
}