#ifndef bai4
#define bai4

#include<iostream>

using namespace std;

void parenBit(char* s, int n, int flag);

#endif // !bai4
