#include"Ham.h"

int main() {
	char s[100];
	cout << "Nhap chuoi: ";
	cin >> s;
	parenBit(s, 0, 0);
	return 0;
}