#ifndef bai2
#define bai2

#include<iostream>

using namespace std;

int count(int n);

#endif // !bai2
