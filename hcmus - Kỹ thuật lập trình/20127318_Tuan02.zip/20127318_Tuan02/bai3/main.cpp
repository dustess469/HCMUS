#include"Ham.h"

int main() {
	int n;
	cout << "Nhap hang: ";
	cin >> n;
	cout << "Tong so khoi: " << count(n);
	return 0;
}