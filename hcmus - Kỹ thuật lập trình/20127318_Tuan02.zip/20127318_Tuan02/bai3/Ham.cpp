#include"Ham.h"

int count(int n) {
	if (n == 1)
		return 1;
	else 
		return n + count(n - 1);
}