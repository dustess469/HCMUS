#include"Ham.h"

int main() {
	char* a = new char;
	int n = 0, dem = 0;
	cout << "Nhap chuoi: ";
	cin >> a;
	cout << "Ket qua 2: " << countHi(a, n, dem);
	return 0;
}