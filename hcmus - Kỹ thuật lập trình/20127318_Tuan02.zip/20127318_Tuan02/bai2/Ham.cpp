#include"Ham.h"

int countHi(char* a, int n, int dem) {
	if (strlen(a) == n)
		return dem;
	else if (a[n] == 'h' && a[n + 1] == 'i') {
		dem++;
		return countHi(a, n + 2, dem);
	}
	else if (a[n] == 'x') {
		if (a[n + 1] == 'h' && a[n + 2] == 'i')
			return countHi(a, n + 3, dem);
		else
			return countHi(a, n + 1, dem);
	}
	else
		return countHi(a, n + 1, dem);
}