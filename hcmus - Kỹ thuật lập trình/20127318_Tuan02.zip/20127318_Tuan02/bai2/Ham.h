#ifndef bai2
#define bai2

#include<iostream>

using namespace std;

int countHi(char* a, int n, int dem);

#endif // !bai2
