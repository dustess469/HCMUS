#include "Ham.h"

int main() {
	int a[15][15], f[15][15];
	int  m, n;
	cout << "Nhap m = ";
	cin >> m;
	cout << "Nhap n = ";
	cin >> n;

	for (int j = 0; j <= n; ++j) {
		f[0][j] = f[m + 1][j] = -1e9;
	}
	for (int i = 1; i <= m; ++i) {
		for (int j = 1; j <= n; ++j) {
			cin >> a[i][j];
		}
	}

	for (int j = 2; j <= n; ++j) {
		for (int i = 1; i <= m; ++i) {
			f[i][j] += max(a[i - 1][j - 1], max(a[i][j - 1], a[i + 1][j - 1]));
		}
	}
	int tmp = -1e9;
	for (int i = 1; i <= m; ++i) {
		tmp = max(tmp, f[i][n]);
	}
	cout << tmp;
	return 0;
}