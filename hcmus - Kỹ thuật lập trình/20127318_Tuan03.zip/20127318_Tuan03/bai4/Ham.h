#ifndef bai4
#define bai4

#include <iostream>
#include <algorithm>

using namespace std;

#endif // !bai4
