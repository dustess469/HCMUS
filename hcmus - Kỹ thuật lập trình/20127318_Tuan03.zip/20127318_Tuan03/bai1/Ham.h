#ifndef bai1
#define bai1

#include<iostream>
#include<vector>
#include<algorithm>

#endif // !bai1
