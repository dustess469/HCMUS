#include "Ham.h"

using namespace std;

int main() {
	int a[1005], b[1005], tv[1005];
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap so: ";
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		b[i] = 1;
		tv[i] = 0;
	}
	for (int i = 1; i < n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (a[i] <= a[j]) {
				b[j] = max(b[j], b[i] + 1);
				tv[j] = i;
			}
		}
	}
	int c = 0, kq = 0;
	for (int i = 1; i <= n; i++) {
		if (b[i] > kq) {
			c = i, kq = b[i];
		}
	}
	cout << kq << endl;
	vector <int> tmp;
	while (c != 0) {
		tmp.push_back(a[c]);
		c = tv[c];
	}
	for (int i = (int)tmp.size() - 1; i >= 0; i--) {
		cout << tmp[i] << "\t";
	}
	cout << endl;
	return 0;
}