#include "Ham.h"

int main() {
	int a[105], f[105][105];
	int n, M;
	cout << "Nhap n mon hang = ";
	cin >> n;
	cout << "Nhap khoi luong balo = ";
	cin >> M;
	cout << "Nhap khoi luong n mon hang = ";
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	}
	for (int j = 0; j <= M; ++j) {
		f[0][j] = 0;
	}
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j <= M; ++j) {
			f[i][j] = f[i - 1][j];
			if (a[i] <= j) {
				f[i][j] = max(f[i][j], f[i - 1][j - a[i]] + a[i]);
			}
		}
	}
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j <= M; ++j) {
			cout << f[i][j] << " ";
		}
		cout << endl;
	}
	cout << f[n][M];
	return 0;
}