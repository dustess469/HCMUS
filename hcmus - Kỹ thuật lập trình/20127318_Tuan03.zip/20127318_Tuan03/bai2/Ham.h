#ifndef bai2
#define bai2

#include <iostream>
#include <algorithm>

using namespace std;

#endif // !bai2