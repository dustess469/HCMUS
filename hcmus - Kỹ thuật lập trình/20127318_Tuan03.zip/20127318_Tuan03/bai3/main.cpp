#include "Ham.h"

int main() {
	int a[105], f[105][105], v[105];
	int n, M;
	cout << "Nhap n mon hang = ";
	cin >> n;
	cout << "Khoi luong balo = ";
	cin >> M;

	for (int i = 1; i <= n; ++i) {
		cin >> a[i] >> v[i];
	}

	for (int j = 0; j <= M; ++j) {
		f[0][j] = 0;
	}
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j <= M; ++j) {
			f[i][j] = f[i - 1][j];
			if (a[i] <= j) {
				f[i][j] = max(f[i][j], f[i - 1][j - a[i]] + v[i]);
			}
		}

	}
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j <= M; ++j) {
			cout << f[i][j] << " ";
		}
		cout << endl;
	}
	cout << f[n][M];
	return 0;
}