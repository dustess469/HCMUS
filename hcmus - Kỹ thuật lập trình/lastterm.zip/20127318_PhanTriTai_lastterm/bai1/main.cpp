#include "Header.h"

int main() {
	LinkedList a = { 0 };
	SV b[100], c[100];
	int n, n1, n2;
	cout << "Nhap so luong sinh vien: ";
	cin >> n;
	input(a, n);
	diemCaonhat(a, b, n1);
	for (int i = 0; i < n1; ++i) {
		output1(b[i]);
	}
	return 0;
}

