#ifndef bai1
#define bai1

#include <iostream>
#include <string>
#include<string.h>

using namespace std;

struct SV {
	int MSSV;
	string name;
	int year;
	string lop;
	double score;
};

struct node
{
	SV data;
	node* next;
};

struct LinkedList {
	node* dau;
};

node* createNode(SV data);
void init(LinkedList a);
void insert1(LinkedList& a, SV data);
node* create2(LinkedList& a, SV data);
void input(LinkedList& a, int n);
void input1(SV& a);
void output(LinkedList a, int n);
void output1(SV a);
void diemCaonhat(LinkedList& a, SV b[], int& n);

#endif // !Final
