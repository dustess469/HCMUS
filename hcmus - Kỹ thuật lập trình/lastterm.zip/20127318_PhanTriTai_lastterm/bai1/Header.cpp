#include "Header.h"

node* createNode(SV data) {
	node* n = new node;
	n->data = data;
	n->next = nullptr;
	return n;
}

void init(LinkedList a) {
	node* p = a.dau;
	p = nullptr;
}

void insert1(LinkedList& a, SV data) {
	node* p = new node;
	p->data = data;
	p->next = a.dau;
	a.dau = p;
}


node* create2(LinkedList& a, SV data) {
	node* newnode = new node;
	newnode->data = data;
	newnode->next = nullptr;
	return newnode;
}

void input1(SV& a) {
	cout << "Nhap MSSV: ";
	cin >> a.MSSV;
	cout << "Nhap ho va ten: ";
	cin.ignore(1);
	getline(cin, a.name);
	cout << "Nhap nam sinh: ";
	cin >> a.year;
	cout << "Nhap lop hoc: ";
	cin.ignore(1);
	getline(cin, a.lop);
	cout << "Nhap diem trung binh: ";
	cin >> a.score;
	cout << endl;
}

void input(LinkedList& a, int n) {
	SV data;
	while (n != 0) {
		input1(data);
		insert1(a, data);
		--n;
	}
}

void output1(SV a) {
	cout << "MSSV: " << a.MSSV << endl;
	cout << "Ho va ten: " << a.name << endl;
	cout << "Nam sinh: " << a.year << endl;
	cout << "Lop hoc: " << a.lop << endl;
	cout << "Diem trung binh: " << a.score << endl;
	cout << endl;
}


void output(LinkedList a, int n) {
	while (a.dau != nullptr) {
		output1(a.dau->data);
		a.dau = a.dau->next;
	}
}

void highestGpa(LinkedList& a, SV b[], int& n) {
	node* p = a.dau;
	double max = 0;
	if (p == nullptr) {
		cout << "Mang rong" << endl;
		return;
	}
	while (p != nullptr) {
		if (max < p->data.score) {
			max = p->data.score;
		}
		p = p->next;
	}
	int i = 0;
	p = a.dau;
	while (p != nullptr) {
		if (max == p->data.score) {
			b[i] = p->data;
			++i;
		}
		p = p->next;
	}
	n = i;
}

