#include<iostream>

using namespace std;

//cach de quy 
int dayFibo(int n) {
	if (n == 0) return 1;
	else if (n == 1) return 2;
	else
		return 2 * dayFibo(n - 1) + 3 * dayFibo(n - 2);
}

//cach ko de quy
int Fibonacci(int n) {
	int a[10000];
	a[0] = 1;
	a[1] = 2;
	for (int i = 2; i <= n; ++i) {
		a[i] = 2 * a[i - 1] + 3 * a[i - 2];
	}
	return a[n];
}

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "f(" << n << ") = " << dayFibo(n) << endl;
    cout << "f(" << n << ") = " << Fibonacci(n) << endl;
	return 0;
}