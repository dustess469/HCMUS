#include <iostream>

using namespace std;


bool checkSNT(int a) {
	int count = 0;
	for (int i = 1; i <= a; ++i) {
		if (a % i == 0) {
			++count;
		}
	}
	if (count == 2) {
		return 1;
	}
	else {
		return 0;
	}
}

int main() {
	int n;
	cout << "Nhap so phan tu cua mang: ";
	cin >> n;
	int* a = new int[n];
	int* b = new int[n];
	int j = 0;
	for (int i = 0; i < n; i++) {
		cout << "Nhap a[" << i << "] = ";
		cin >> *(a + i);
	}
	for (int i = 0; i < n; i++) {
		if (checkSNT(*(a + i)) == 1) {
			*(b + j) = *(a + i);
			++j;
		}
	}
	cout << "So nguyen to trong n: ";
	for (int i = 0; i < j; ++i) {
		cout << *(b + i) << " ";
	}
	cout << endl;
	delete[]a;
	delete[]b;
	return 0;
}