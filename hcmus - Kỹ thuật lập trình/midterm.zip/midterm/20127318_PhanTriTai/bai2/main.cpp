#include<iostream>

using namespace std;

int main() {
	int n, i1 = 0, max, count = 0, count1 = 0;
	cout << "Nhap so phan tu cua mang: ";
	cin >> n;
	int* a = new int[n];
	double* b = new double[n * n * n];
	for (int i = 0; i < n; ++i) {
		cout << "Nhap a[" << i << "]: ";
		cin >> *(a + i);
		++count;
	}
	if (count < 3) {
		cout << "\nMang khong hop le\n";
		return 0;
	}
	for (int i = 0; i < n; ++i) {
		for (int j = i + 1; j < n; ++j) {
			for (int k = j + 1; k < n; ++k) {
				*(b + i1) = *(a + i) * *(a + j) * *(a + k);
				++i1;
				++count1;
			}
		}
	}
	max = *b;
	for (int i = 0; i < count1; ++i) {
		if (max < *(b + i)) max = *(b + i);
	}
	cout << "Ba so co tich lon nhat la: " << max;
	return 0;
}