#include <iostream>
#include<stack>

using namespace std;

void push(int a[], int& n, int x) {
	++n;
	a[n - 1] = x;
}

void pop(int a[], int& n) {
	for (int i = 0; i < n; ++i) {
		a[i] = a[i + 1];
	}
	--n;
}

void output(int a[], int n) {
	for (int i = 0; i < n; ++i) {
		cout << a[i] << " ";
	}
}

int main() {
	int a[1000], c;
	int n = 0, option = 1;
	while (option != 0) {
		cout << "Choose: \n";
		cout << "0 : Break\n";
		cout << "1 : Push\n";
		cout << "2 : Pop\n";
		cin >> option;
		if (option == 1) {
			if (n == 1000) {
				cout << "Queue is full\n";
			}
			else {
				cout << "Which number do you want to push: ";
				cin >> c;
				push(a, n, c);
				cout << "Queue now is: ";
				output(a, n);
				cout << endl;
			}
		}
		if (option == 2) {
			if (n == 0) {
				cout << "Queue is empty\n";
			}
			else {
				pop(a, n);
				cout << "Queue now is: ";
				output(a, n);
				cout << endl;
			}
		}
		cout << endl;
		if (option == 0) {
			break;
		}
	}
	return 0;
}