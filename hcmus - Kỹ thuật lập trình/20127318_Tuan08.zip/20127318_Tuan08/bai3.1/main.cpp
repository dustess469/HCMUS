#include <iostream>

using namespace std;


void push(char a[], int& n, char x) {
	++n;
	a[n] = x;
}

void pop(char a[], int& n) {
	--n;
}

void output(char a[], int n) {
	for (int i = n; i != 0; --i) {
		cout << a[i] << " ";
	}
}

int main() {
	char a[1000], c;
	int n = 0, option = 1;
	while (option != 0) {
		cout << "Choose: \n";
		cout << "0 : Break\n";
		cout << "1 : Push\n";
		cout << "2 : Pop\n";
		cin >> option;
		if (option == 1) {
			if (n == 1000) {
				cout << "Stack is full\n";
			}
			else {
				cout << "Which character do you want to push: ";
				cin >> c;
				push(a, n, c);
				cout << "Stack now is: ";
				output(a, n);
				cout << endl;
			}
		}
		if (option == 2) {
			if (n == 0) {
				cout << "Stack is empty\n";
			}
			else {
				pop(a, n);
				cout << "Stack now is: ";
				output(a, n);
				cout << endl;
			}
		}
		cout << endl;
		if (option == 0) {
			break;
		}
	}
	return 0;
}