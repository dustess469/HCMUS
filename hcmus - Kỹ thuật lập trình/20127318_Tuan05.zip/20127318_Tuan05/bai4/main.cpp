#include<iostream>

using namespace std;

void nhapMang(int* a,int *b, int n, int m) {
	for (int i = 0; i < n; ++i) {
		cout << "a[" << i << "] = ";
		cin >> *(a + i);
	}
	for (int i = 0; i < m; i++) {
		cout << "b[" << i << "] = ";
		cin >> *(b + i);
	}
}

void xuatMang(int* a, int n) {
	cout << "Mang c sau khi noi mang a va b: ";
	for (int i = 0; i < n; ++i) {
		cout << *(a + i) << " ";
	}
	cout << endl;
}

void noiDay(int* a, int* b, int n, int m) {
	int* c = new int[n + m + 5];
	for (int i = 0; i < n; ++i) {
		*(c + i) = *(a + i);
	}
	for (int i = 0; i < m; ++i) {
		*(c + i + n) = *(b + i);
	}
	xuatMang(c, n + m);
}

int main() {
	int n, m;
	cout << "Nhap so phan tu mang a: ";
	cin >> n;
	cout << "Nhap so phan tu mang b: ";
	cin >> m;
	int* a = new int[n], * b = new int[m];
	nhapMang(a, b, n, m);
	noiDay(a, b, n, m);
	delete[]a;
	delete[]b;
	return 0;
}