#include <iostream>

using namespace std;

void nhapMang(int* a, int n) {
	for (int i = 0; i < n; ++i) {
		cout << "a[" << i << "] = ";
		cin >> *(a + i);
	}
}

void xuatMang(int* a, int n) {
	cout << "Mang da duoc xoa phan tu k: ";
	for (int i = 0; i < n; ++i) {
		cout << *(a + i) << " ";
	}
}

void xoaPhantu(int* a, int k, int& n) {
	for (int i = k - 1; i < n - 1; ++i) {
		*(a + i) = *(a + i + 1);
	}
	--n;
}

int main() {
	int n, k;
	int *a = new int[100];
	cout << "Nhap so phan tu trong mang: ";
	cin >> n;
	cout << "Nhap vi tri muon xoa: ";
	cin >> k;
	nhapMang(a, n);
	xoaPhantu(a, k, n);
	xuatMang(a, n);
	delete[]a;
	return 0;
}