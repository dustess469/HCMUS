#include <iostream>

using namespace std;

void nhapMang(int* a, int n) {
	for (int i = 0; i < n; ++i) {
		cout << "a[" << i << "] = ";
		cin >> *(a + i);
	}
}

void xuatMang(int* a, int n) {
	cout << "Mang khi xoa so nguyen to: ";
	for (int i = 0; i < n; ++i) {
		cout << *(a + i) << " ";
	}
	cout << endl;
}

void xoaPhantu(int* a, int k, int n) {
	for (int i = k - 1; i < n - 1; ++i) {
		*(a + i) = *(a + i + 1);
	}
	--n;
}

int soNguyento(int n) {
	if (n < 1) {
		return 0;
	}
	int count = 0;
	for (int i = 1; i <= n; ++i) {
		if (n % i == 0) {
			++count;
		}
	}
	if (count == 2) {
		return 1;
	}
	else
		return 0;
}

void xoaSonguyento(int* a, int& n) {
	int count = 0;
	for (int i = 0; i < n; ++i) {
		if (soNguyento(*(a + i)) == 1) {
			++count;
		}
	}
	for (int i = 0; i < n; ++i) {
		if (soNguyento(*(a + i)) == 1) {
			xoaPhantu(a, i + 1, n);
			--i;
		}
	}
	n = n - count;
}

int main() {
	int n, * a = new int[100];
	cout << "Nhap so phan tu cua mang: ";
	cin >> n;
	nhapMang(a, n);
	xoaSonguyento(a, n);
	xuatMang(a, n);
	delete[]a;
	return 0;
}
