#include <iostream>

using namespace std;

void nhapMang(int* a, int n) {
	for (int i = 0; i < n; ++i) {
		cout << "a[" << i << "] = ";
		cin >> *(a + i);
	}
}

void xuatMang(int* a, int n) {
	cout << "Mang da duoc chen phan tu k: ";
	for (int i = 0; i < n; ++i) {
		cout << *(a + i) << " ";
	}
	cout << endl;
}

void chenPhantu(int *a, int& n){
	int x, y;
	cout << "Nhap so can chen: ";
	cin >> x;
	cout << "Nhap vi tri can chen: ";
	cin >> y;
	y = y - 1;
	if (y >= 0 && y < n)
	{
		for (int i = n; i > y; i--)
			a[i] = a[i - 1];
		a[y] = x;
		n++;
	}
}

int main() {
	int n, k, * a = new int[100];
	cout << "Nhap so phan tu trong mang: ";
	cin >> n;
	nhapMang(a, n);
	chenPhantu(a, n);
	xuatMang(a, n);
	delete[]a;
	return 0;
}