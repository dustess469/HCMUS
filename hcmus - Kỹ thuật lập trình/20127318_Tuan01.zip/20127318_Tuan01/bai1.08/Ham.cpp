#include"Ham.h"

double tong(double n) {
	if (n == 0) {
		return 0.5;
	}
	else
		return tong(n - 1) + ((2 * n + 1) / (2 * n + 2));
}