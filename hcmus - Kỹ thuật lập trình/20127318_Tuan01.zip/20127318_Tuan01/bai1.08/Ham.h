#ifndef bai8
#define bai8

#include<iostream>

using namespace std;

double tong(double n);

#endif

