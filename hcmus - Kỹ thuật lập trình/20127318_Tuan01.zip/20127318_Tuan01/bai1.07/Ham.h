#ifndef bai7
#define bai7

#include<iostream>

using namespace std;

double tong(double n);
#endif