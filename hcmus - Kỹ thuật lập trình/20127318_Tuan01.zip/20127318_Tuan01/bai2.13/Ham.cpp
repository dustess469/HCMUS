#include"Ham.h"

double tong(double x, int n) {
	if (n == 1)
		return x * x;
	else
		return tong(x, n - 1) + pow(x, 2 * n);
}