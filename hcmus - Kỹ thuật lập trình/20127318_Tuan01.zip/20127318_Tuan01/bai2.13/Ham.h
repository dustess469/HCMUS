#ifndef bai13
#define bai13

#include<iostream>

using namespace std;

double tong(double x, int n);

#endif
