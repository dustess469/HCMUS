#include"Ham.h"

int main() {
	double x;
	int n;
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 2.13: " << tong(x, n);
	return 0;
}