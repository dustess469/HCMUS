#ifndef bai18
#define bai18

#include<iostream>

using namespace std;

int demSo(int n);

#endif