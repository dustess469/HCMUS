#include"Ham.h"

int main() {
	int n;
	int n1;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 7.1: " << demSo(n);
	return 0;
}