#include"Ham.h"

int demSo(int n) {
	if (n < 10)
		return 1;
	else
		return 1 + demSo(n / 10);
}