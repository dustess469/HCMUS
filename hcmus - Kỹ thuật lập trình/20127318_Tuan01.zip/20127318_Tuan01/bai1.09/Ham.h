#ifndef bai9
#define bai9

#include<iostream>

using namespace std;

double tong(double n);
#endif
