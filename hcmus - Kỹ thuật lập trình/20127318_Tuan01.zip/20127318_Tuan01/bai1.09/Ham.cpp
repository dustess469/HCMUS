#include"Ham.h"

double tong(double n) {
	if (n == 1)
		return 1;
	else
		return tong(n - 1) * n;
}