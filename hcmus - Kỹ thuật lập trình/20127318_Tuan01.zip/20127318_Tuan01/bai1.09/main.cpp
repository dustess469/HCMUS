#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Tong cua 1.9: " << tong(n);
	return 0;
}