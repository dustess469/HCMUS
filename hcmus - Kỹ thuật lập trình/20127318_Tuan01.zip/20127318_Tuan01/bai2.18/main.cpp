#include"Ham.h"

int main() {
	int n;
	double x;
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 2.18: " << tong(x, n);
	return 0;
}