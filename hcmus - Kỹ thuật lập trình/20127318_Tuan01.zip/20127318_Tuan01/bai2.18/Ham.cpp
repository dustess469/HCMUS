#include"Ham.h"

double giaithua(int n) {
	if (n == 0)
		return 1;
	else {
		return giaithua(n - 1) * n;
	}
}

double tong(double x, int n) {
	if (n == 0)
		return 1;
	else
		return pow(x, 2 * n) / giaithua(2 * n) + tong(x, n - 1);
}
