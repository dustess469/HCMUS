#ifndef bai17
#define bai17

#include<iostream>

using namespace std;

double tong(double x, int n);
double giaithua(int n);

#endif