#include"Ham.h"

double giaithua(int n) {
	if (n == 1)
		return 1;
	else {
		return giaithua(n - 1) * n;
	}
}

double tong(double x, int n) {
	if (n == 1)
		return x;
	else
		return pow(x, n) / giaithua(n) + tong(x, n - 1);
}
