#include"Ham.h"

double sum(int n) {
	if (n == 1)
		return 1;
	else {
		return sum(n - 1) + n;
	}
}

double tong(double x, int n) {
	if (n == 1)
		return x;
	else
		return pow(x,n) / sum(n) + tong(x, n - 1);
}
