#ifndef Bai2
#define Bai2

#include<iostream>

using namespace std;

int tong(int n);

#endif
