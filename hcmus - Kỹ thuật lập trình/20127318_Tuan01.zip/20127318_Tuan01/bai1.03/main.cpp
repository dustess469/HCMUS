#include"Ham.h"

int main() {
	double n;
	cout << "Nhap n: ";
	cin >> n;
	if (n == 0) cout << "Gia tri khong hop le";
	else
		cout << "Tong cua bai3: " << tong(n);
	return 0;
}