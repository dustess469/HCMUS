#ifndef bai18
#define bai18

#include<iostream>

using namespace std;

int tichLe(int n);

#endif