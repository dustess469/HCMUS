#include"Ham.h"

int tichLe(int n) {
	if (n < 10 && n % 2 == 1)
		return n;
	else if (n < 10 && n % 2 == 0) 
		return 1;
	else 
		if ((n % 10) % 2 == 0) 
			return 1 * tichLe(n / 10);
	if ((n % 10) % 2 == 1)
		return n % 10 * tichLe(n / 10);
}