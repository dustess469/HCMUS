#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 7.3: " << tichLe(n);
	return 0;
}