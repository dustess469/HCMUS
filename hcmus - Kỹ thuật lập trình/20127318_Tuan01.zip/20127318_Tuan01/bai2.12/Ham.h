#ifndef bai12
#define bai12

#include<iostream>

using namespace std;

double tong(double x, int n);

#endif
