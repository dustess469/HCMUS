#ifndef bai5
#define bai5

#include<iostream>

using namespace std;

double tong(double n);
#endif
