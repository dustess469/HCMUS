#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Tong cua bai5: " << tong(n);
	return 0;
}