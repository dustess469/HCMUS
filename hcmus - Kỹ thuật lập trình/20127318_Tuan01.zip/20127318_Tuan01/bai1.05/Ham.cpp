#include"Ham.h"

double tong(double n) {
	if (n == 0) {
		return 1;
	}
	else
		return tong(n - 1) + (1 / ((2 * n) + 1));
}