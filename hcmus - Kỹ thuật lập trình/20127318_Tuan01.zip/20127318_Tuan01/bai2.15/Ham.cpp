#include"Ham.h"

double sum(int n) {
	if (n == 1) 
		return 1;
	else {
		return sum(n - 1) + n;
	}
}

double tong(int n) {
	if (n == 1)
		return 1;
	else
		return 1.0 / sum(n) + tong(n - 1);
}
