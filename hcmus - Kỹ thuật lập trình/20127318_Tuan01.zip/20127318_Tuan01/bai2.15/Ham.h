#ifndef bai15
#define bai15

#include<iostream>

using namespace std;

double tong(int n);
double sum(int n);

#endif
