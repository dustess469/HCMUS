#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 2.15: " << tong(n);
	return 0;
}