#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Tong cua bai 1.6: " << tong(n);
	return 0;
}