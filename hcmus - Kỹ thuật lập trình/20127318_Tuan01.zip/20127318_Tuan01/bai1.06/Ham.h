#ifndef bai6
#define bai6

#include<iostream>

using namespace std;

double tong(double n);
#endif