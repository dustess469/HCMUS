#ifndef bai14
#define bai14

#include<iostream>

using namespace std;

double tong(double x, int n);

#endif

