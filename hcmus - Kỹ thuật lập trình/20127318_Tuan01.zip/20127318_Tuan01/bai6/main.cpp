#include"Ham.h"

int main() {
	string d;
	cout << "Nhap chuoi: ";
	cin >> d;
	cout << "Chuoi doi xung: " << doiXung(d);
	return 0;
}