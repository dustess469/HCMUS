#include"Ham.h"

int doiXung(string d) {
    int n = d.size();
    for (int i = 0; i < n / 2; i++)
    {
        if (d[i] == d[n - i - 1])
            return -1;
        else
            return 0;
    }
}