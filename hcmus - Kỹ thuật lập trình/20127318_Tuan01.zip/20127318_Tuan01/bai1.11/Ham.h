#ifndef bai11
#define bai11

#include<iostream>

using namespace std;

int tong(int n);

#endif

