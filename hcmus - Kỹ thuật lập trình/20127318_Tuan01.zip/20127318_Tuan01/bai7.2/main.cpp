#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 7.2: " << tong(n);
	return 0;
}