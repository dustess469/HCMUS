#ifndef bai4
#define bai4

#include<iostream>

using namespace std;

double tinhx(int n);
double tinhy(int n);

#endif