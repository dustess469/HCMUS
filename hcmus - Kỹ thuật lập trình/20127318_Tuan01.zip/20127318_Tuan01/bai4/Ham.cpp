#include"Ham.h"

double tinhx(int n)
{
	if (n == 0)
		return 1;
	else
		return tinhx(n - 1) - tinhy(n - 1);
}
double tinhy(int n) {
	if (n == 0)
		return 0;
	else
		return 3 * tinhx(n - 1) - 2 * tinhy(n - 1);
}