#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua cua x(n): " << tinhx(n) << endl;
	cout << "Ket qua cua y(n): " << tinhy(n);
	return 0;
}