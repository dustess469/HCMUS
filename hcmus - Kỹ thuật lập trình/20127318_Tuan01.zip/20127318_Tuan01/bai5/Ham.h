#ifndef bai18
#define bai18

#include<iostream>

using namespace std;

int toHop(int k, int n);

#endif