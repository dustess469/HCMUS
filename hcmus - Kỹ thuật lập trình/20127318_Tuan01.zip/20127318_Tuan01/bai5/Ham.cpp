#include"Ham.h"

int toHop(int k, int n) {
	if (k == 1)
		return n;
	else if (n == k)
		return 1;
	else
		return toHop(n - 1, k) + toHop(n - 1, k - 1);
}