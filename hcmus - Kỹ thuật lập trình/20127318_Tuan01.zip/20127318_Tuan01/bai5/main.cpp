#include"Ham.h"

int main() {
	int n,k;
	cout << "Nhap k: ";
	cin >> k;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 5: " << toHop(k,n);
	return 0;
}