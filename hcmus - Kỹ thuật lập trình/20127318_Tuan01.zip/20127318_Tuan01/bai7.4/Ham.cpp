#include"Ham.h"

int soChan(int n) {
	if (n < 10 && n % 2 == 1)
		return 0;
	else if (n < 10 && n % 2 == 0)
		return 1;
	else {
		if ((n % 10) % 2 == 1) 
			return 0;
		else 
			return soChan(n / 10);
	}
}