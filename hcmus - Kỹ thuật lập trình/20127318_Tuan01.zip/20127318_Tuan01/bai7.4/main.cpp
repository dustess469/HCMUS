#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << "Ket qua 7.4: " << soChan(n);
	return 0;
}