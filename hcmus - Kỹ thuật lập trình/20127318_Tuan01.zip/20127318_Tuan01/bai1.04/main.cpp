#include"Ham.h"

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	if (n == 0) cout << "Gia tri khong hop le";
	else
		cout << "Tong cua bai4: " << tong(n);
	puts("");
	return 0;
}