#include"Ham.h"

double tong(double n) {
	if (n == 1) {
		return 0.5;
	}
	else
		return tong(n - 1) + (1 / (2 * (n)));
}