#ifndef bai4
#define bai4

#include<iostream>

using namespace std;

double tong(double n);
#endif

