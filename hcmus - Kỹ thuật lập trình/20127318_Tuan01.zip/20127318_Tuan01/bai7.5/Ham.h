#ifndef bai18
#define bai18

#include<iostream>

using namespace std;

int soLe(int n);

#endif