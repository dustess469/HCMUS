#ifndef bai1
#define bai1

#include<iostream>

using namespace std;

int tong(int n);

#endif
