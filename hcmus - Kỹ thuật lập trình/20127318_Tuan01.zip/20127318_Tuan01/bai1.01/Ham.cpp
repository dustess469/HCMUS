#include"Ham.h"


int tong(int n) {
	if (n == 1) {
		return 1;
	}
	else {
		return tong(n - 1) + n;
	}
}
