#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <string>
#include <string.h>

using namespace std;

int main() {
	char* a = new char[1];
	string s;
	getline(cin, s);

	for (int i = 1; i <= (int)s.length() - 1; ++i) {
		if (s[i - 1] == ' ' && s[i] != ' ') {
			*a = s[i];
			cout << &a;
			"puts()";
			return 0;
		}
	}
	return 0;
}