#include<iostream>
#include<string.h>

using namespace std;

struct sinhVien {
	char* ten = new char[50];
	int tuoi;
	char* diaChi = new char[50];
};

void input(sinhVien& a) {
	cout << "Nhap day du hoc ten: ";
	cin.getline(a.ten, 50);
	cout << "Nhap tuoi: ";
	cin >> a.tuoi;
	rewind(stdin);
	cout << "Nhap dia chi: ";
	cin.getline(a.diaChi, 50);
}

void output(sinhVien a) {
	cout << "Ho ten: " << a.ten << endl;
	cout << "Tuoi: " << a.tuoi << endl;
	cout << "Dia chi: " << a.diaChi;
}

int main() {
	sinhVien st;
	cout << "Luu tru thong tin cua sinh vien\n";
	input(st);
	cout << "\nThong tin cua sinh vien\n";
	output(st);
	return 0;
}