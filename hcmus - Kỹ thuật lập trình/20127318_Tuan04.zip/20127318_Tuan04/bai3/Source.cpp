#include <iostream> 

using namespace std;

void nhap(float* x, int& n) {
	cout << "Nhap phan tu: ";
	cin >> n;
	for (int i = 0; i < n; ++i) {
		cout << "Phan tu a[" << i << "]: ";
		cin >> *(x + i);
	}
}

void max(float* x, int n) {
	float max = *x;
	for (int i = 0; i < n; ++i) {
		if (*(x + i) >= max) {
			max = *(x + i);
		}
	}
	cout << "Max =  " << max << endl;
}


int main() {
	float x[101];
	int n = 0;
	nhap(x, n);

	max(x, n);
	return 0;
}