#include<iostream>

using namespace std;

void nhap(int* x, int n) {
	for (int i = 0; i < n; ++i) {
		cin >> *(x + i);
	}
}

void xuat(int* x, int n) {
	for (int i = 0; i < n; ++i) {
		cout << *(x + i) << " ";
	}
}

void phantuKhong(int* x, int n) {
	for (int i = 0; i < n; ++i) {
		*(x + i) = 0;
	}
}

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	int* x = new int[n];
	nhap(x, n);
	cout << "Mang duoc tao ra:  " << endl;
	xuat(x, n);
	phantuKhong(x, n);
	cout << "\nSau phan tu khong: " << endl;
	xuat(x, n);
	return 0;
}
