#include<iostream>

using namespace std;

void swap1(int* a, int* b) {
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

void swap2(int& a, int& b) {
	int tmp = a;
	a = b;
	b = tmp;
}

int main() {
	int a, b;
	cout << "Nhap a = ";
	cin >> a;
	cout << "Nhap b = ";
	cin >> b;

	swap1(&a, &b);
	cout << "Sau khi swap lan 1 su dung pointers\n";
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << endl;

	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;

	swap2(a, b);
	cout << "Sau khi swap lan 2 thi su dung references\n";
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;
	cout << endl;
	return 0;
}