#include<iostream>

using namespace std;

void nhap(int* a, int n) {
	for (int i = 0; i < n; i++) {
		cout << "a[" << i << "] = ";
		cin >> *(a + i);
	}
}

void xuat(int* a, int n) {
	for (int i = 0; i < n; i++) {
		cout << *(a + i) << " ";
	}
}
bool giamDan(int trai, int phai) {
	return trai < phai;
}

bool tangDan(int trai, int phai) {
	return trai > phai;
}

void sapXep(int* a, int n, bool(*fcompare)(int, int)) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (fcompare(a[i], a[j])) {
				int temp = a[i];
				a[i]= a[j];
				a[j] = temp;
			}
		}
	}
}

int main() {
	int n;
	cout << "Enter n: ";
	cin >> n;
	int* a = new int[n];
	nhap(a, n);
	cout << "Array is created: " << endl;
	xuat(a, n);
	int choose = 0;

	do {
		cout << "\n----------Sap xep mang----------\n";
		cout << "1. Sap xep theo thu tu tang dan\n";
		cout << "2. Sap xep theo thu tu giam dan\n";
		cout << "0. Thoat";
		cout << "Nhap lua chon: ";
		cin >> choose;

		if (choose < 0 || choose > 2) {
			cout << "Nhap sai. Moi nhap lai\n";
			system("pause");
		}
		else if (choose == 1) {
			sapXep(a, n, tangDan);
			cout << "Mang duoc sap xep theo thu tu tang dan: \n";
			xuat(a, n);
		}
		else if (choose == 2) {
			sapXep(a, n, giamDan);
			cout << "Mang duoc sap xep theo thu tu giam dan: \n";
			xuat(a, n);
		}
		else if (choose == 0) {
			cout << "---------------------------------------------\n";
			break;
		}
	} 
	while (true);
	delete[]a;
	return 0;
}