#include<iostream>

using namespace std;

int main() {
	//cau1
	char* ex1;
	//cau2
	char** ex2 = &ex1;
	//cau3
	char** ex3[10];
	//cau4
	char* ex4[30];
	//cau5
	char(*ex5[10])[500];
	//cau6
	int* const ex6 = new int;
	//cau7
	int const* ex7;
}