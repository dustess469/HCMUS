#include<iostream>

using namespace std;

void khoiTao(double* x) {
	for (int i = 0; i < 10; i++) {
		*(x + i) = 1.0;
	}
}
int main() {
	double* x = new double[10];
	khoiTao(x);
	delete[]x;
	return 0;
}