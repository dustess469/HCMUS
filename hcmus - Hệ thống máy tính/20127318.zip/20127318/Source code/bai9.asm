%include "io.inc"
extern _getch
section .data
    tb1 db "Nhap chuoi: ",0
    tb2 db "Chuoi nguoc la: ",0
    fmt1 db "%d",0
    fmt2 db "%d",0
section .bss
    arr resd 100
    string resd 100
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1
    call _printf
    add esp,4
    
    GET_STRING string,100
    
    mov esi,0
    mov ebx,string
    
_strlenloop:
    inc ebx
    inc esi
    cmp byte[ebx], 0
    jne  _strlenloop
    
    mov ebx, string
    mov edx, arr
    
_reverse:   
    mov eax, [ebx + esi - 2]
    mov [edx], eax
    
    inc edx
    dec esi
    cmp esi, 0
    jne _reverse
    
    push tb2
    call _printf
    add esp, 4
    
    mov edx, arr
    
    push edx
    call _printf
    add esp, 4
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret