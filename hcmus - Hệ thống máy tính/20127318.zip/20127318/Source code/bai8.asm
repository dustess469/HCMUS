%include "io.inc"
extern _getch
section .data
    tb1 db "Nhap mot so: ",0
    fmt db "%d",0
    tb2 db "Tong tu 1 den %d la: %d",0
section .bss
    n resd 1
    kq resd 1
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1 
    call _printf
    add esp,4
    
    ;nhap n 
    push n
    push fmt
    call _scanf
    add esp,8
    mov eax,1
    mov ebx,1
    mov ecx,[n]
    add eax,eax
_tongloop:
    add ebx,eax
    add eax,1
    cmp eax,ecx
    jle _tongloop
    jmp _ketthuc
_ketthuc:
    mov [kq],ebx
    
    push dword[kq]
    push dword[n]
    push tb2
    call _printf
    add esp,12
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret