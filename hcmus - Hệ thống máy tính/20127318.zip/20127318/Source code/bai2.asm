%include "io.inc"
extern _getch

section .data
    tb1 db "Nhap ky tu: ",0
    tb2 db "Ki tu lien truoc: %s",10,0
    tb3 db "ki tu lien sau: %s",0
    fmt db "%s",0
section .bss
    char resb 2
    kq resb 2
    
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1
    call _printf
    add esp,4
    
    ;nhap ky tu
    push char
    push fmt
    call _scanf
    add esp,8
    
    ;xuat ky tu lien truoc
    mov eax,[char]
    sub eax,1
    mov [kq],eax
    
    push kq
    push tb2
    call _printf
    add esp,8
    
    ;xuat ky tu lien sau
    mov eax,[char]
    add eax,1
    mov [kq],eax
    
    push kq
    push tb3
    call _printf
    add esp,8
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret