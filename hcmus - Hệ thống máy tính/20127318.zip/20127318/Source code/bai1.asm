%include "io.inc"
extern _getch

section .data
    tb1 db "Nhap mot chuoi: ",0
    tb2 db "Chuoi da nhap: %s",0
    fmt db "%s",0
section .bss
    string resq 30
section .text
global CMAIN
CMAIN:
   ;write your code here
   
    ;xuat tb1
    push tb1
    call _printf
    add esp,4
    
    ;Nhap chuoi
    GET_STRING string,30
    
    ;xuat tb2
    push string
    push tb2
    call _printf
    add esp,8
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret
