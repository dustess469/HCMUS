%include "io.inc"
extern _getch
section .data
    tb1 db "Nhap mang cac so nguyen: ",0
    fmt1 db "%s",0
    tb2 db "Mang vua nhap la: %s",0
section .bss
    arr resd 100
  
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1
    call _printf
    add esp,4
    
    GET_STRING arr,100
    
    ;xuat tb2
    push arr
    push tb2
    call _printf
    add esp,8
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret