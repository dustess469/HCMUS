%include "io.inc"

extern _getch
section .data
    tb1 db "Nhap a: ",0
    tb2 db "Nhap b: ",0
    tb3 db "Tong: %d",10,0
    tb4 db "Hieu: %d",10,0
    tb5 db "Tich: %d",10,0
    tb6 db "Thuong: %d",10,0
    tb7 db "So du: %d",0
    fmt db "%d",
section .bss
    a resd 1
    b resd 1
    kq resd 1
    du resd 1
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1
    call _printf 
    add esp,4
    
    ;nhap a
    push a
    push fmt
    call _scanf
    add esp,8
    
    ;xuat tb2
    push tb2
    call _printf 
    add esp,4
    
    ;nhap b
    push b
    push fmt
    call _scanf
    add esp,8
    
    mov eax,[a]
    add eax,[b]
    mov [kq],eax
    
    ;xuat tb3
    push dword[kq]
    push tb3
    call _printf
    add esp,8
    
    mov eax,[a]
    sub eax,[b]
    mov [kq],eax
    
    ;xuat tb4
    push dword[kq]
    push tb4
    call _printf
    add esp,8
    
    mov eax,[a]
    mov ecx,[b]
    imul ecx,eax
    mov [kq],ecx
    
    ;xuat tb5
    push dword[kq]
    push tb5
    call _printf
    add esp,8
    
    mov eax,[a]
    mov ecx,[b]
    mov edx,0
    idiv ecx; 
    mov [kq], eax
    mov [du], edx
            
    ;xuat tb6
    push dword[kq]
    push tb6
    call _printf
    add esp,8
    
    ;xuat tb7
    push dword[du]
    push tb7
    call _printf
    add esp,8
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret