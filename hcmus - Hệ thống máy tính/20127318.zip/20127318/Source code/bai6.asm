%include "io.inc"
extern _getch
section .data
    tb1 db "Nhap vao mot ky tu: ",0
    tb2 db "%s la so",0
    tb3 db "%s la chu thuong",0
    tb4 db "%s la chu hoa",0
    fmt1 db "%s",0
    
section .bss 
    char resd 10
    kq resd 10
section .text
global CMAIN
CMAIN:
    ;write your code here
   
    ;xuat tb1 
    push tb1
    call _printf
    add esp,4
    
    push char
    push fmt1
    call _scanf
    add esp,8
    
    mov eax,[char]
    
    cmp eax,57
    jg _jchuhoa
    push char
    push tb2
    call _printf
    add esp,12
    jmp _thoat
_jchuhoa:
    cmp eax,90
    jg _jchuthuong
    push char
    push tb4
    call _printf
    add esp,12
    jmp _thoat
_jchuthuong:
    push char
  
    push tb3
    call _printf
    add esp,12
_thoat: 
    ;stop man hinh
    call _getch
    xor eax, eax
    ret