%include "io.inc"
extern _getch
section .data
    tb db "Em kinh chuc thay mot nam moi 2022 vui ve, tran day suc khoe, hanh phuc ben gia dinh va nhung nguoi than yeu cua minh!", 0 
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb
    push tb
    call _printf
    add esp, 4 
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret