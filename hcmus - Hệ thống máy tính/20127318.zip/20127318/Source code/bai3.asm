%include "io.inc"
extern _getch
section .data
    tb1 db "Nhap ky tu in hoa: ",0
    tb2 db "Ky tu thuong: %s",10,0
    fmt db "%s",0
section .bss
    char resb 2
    kq resb 2
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1
    call _printf
    add esp,4
    
    ;nhap ky tu in hoa
    push char
    push fmt
    call _scanf
    add esp,8
    
    ;bien doi
    mov eax,[char]
    add eax,32
    mov [kq],eax
    
    ;xuat ki tu 
    push kq
    push tb2
    call _printf
    add esp,8
    
    ;stop man hinh
    call _getch
    xor eax, eax
    ret