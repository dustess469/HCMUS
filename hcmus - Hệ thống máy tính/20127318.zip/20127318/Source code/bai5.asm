%include "io.inc"
extern _getch
section .data
    tb1 db "Nhap a: ",0
    tb2 db "Nhap b: ",0
    fmt db "%d",0
    tb3 db "So lon hon la: %d",10,0
section .bss
    a resd 1
    b resd 1
    kq resd 1
section .text
global CMAIN
CMAIN:
    ;write your code here
    
    ;xuat tb1
    push tb1
    call _printf
    add esp,4
    
    ;nhap a
    push a
    push fmt
    call _scanf
    add esp,8
    
    ;xuat tb2
    push tb2
    call _printf
    add esp,4
    
    ;nhap b
    push b
    push fmt
    call _scanf
    add esp,8
    
    mov eax,[a]
    mov ecx,[b]
    cmp eax,ecx
    jle _xuatb
    push eax
    push tb3
    call _printf
    add esp,8
    jmp _ketthuc  
_xuatb:
    push ecx
    push tb3
    call _printf
    add esp,8 
    jmp _ketthuc
_ketthuc:
    ;stop man hinh
    call _getch
    xor eax, eax
    ret