// C++ code
//
#include <Adafruit_LiquidCrystal.h>

int button = 12;
int lastState = LOW;
int count = 0;
int lastS = 0;

Adafruit_LiquidCrystal lcd_1(0);

void setup()
{
  lcd_1.begin(16, 2);
  
  pinMode(button, INPUT);
  pinMode(A0, INPUT);
  Serial.begin(9600);
  
}

void loop()
{  
  int buttonState = digitalRead(button);
  if(buttonState != lastState){
    lastState = buttonState;
    count++;
  }
  
  if(lastS != (count / 2) % 3){
    lcd_1.clear();
    lastS = (count / 2) % 3;
  }
  
  if((count / 2) % 3 == 0){
    lcd_1.setCursor(5, 0);
    lcd_1.print("CLASS");
    lcd_1.setCursor(4, 1);
    lcd_1.print("20CLC04");
    //delay(1000);
  }
  
  else if((count / 2) % 3 == 1){
    lcd_1.setCursor(2, 0);
    lcd_1.print("PHAN TRI TAI");
    lcd_1.setCursor(4, 1);
    lcd_1.print("20127318");
    //delay(1000);
  }
  
  else{
    float value = analogRead(A0);
    float celsius = (value * 5 / 1023) / 0.01 - 50;
    lcd_1.setCursor(2, 0);
    lcd_1.print("TEMP: ");
    lcd_1.setCursor(8, 0);
    lcd_1.println(celsius);
    //delay(1000);
  }
}