// C++ code
//
int trig_pin = 2;
int echo_pin = 3;
int buzzer_pin = 4;
int orange_pin = 5;
int red_pin = 6;
int blue_pin = 7;


long getDistance(){
  digitalWrite(trig_pin, LOW);
  delayMicroseconds(2);
  digitalWrite(trig_pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig_pin, LOW);
  
  long duration = pulseIn(echo_pin, HIGH);
  
  long distanceCm = duration *0.034 / 2;
  
  return distanceCm;
}

void setup()
{
  pinMode(orange_pin, OUTPUT);
  pinMode(red_pin, OUTPUT);
  pinMode(blue_pin, OUTPUT);
  
  Serial.begin(9600);
  pinMode(trig_pin, OUTPUT);
  pinMode(echo_pin, INPUT);
  
  pinMode(buzzer_pin, OUTPUT);
}

void loop()
{
  int distanceCm = getDistance();
  
  if(distanceCm >= 150)
  {
  	digitalWrite(blue_pin, HIGH);
  
    digitalWrite(red_pin, LOW);

    digitalWrite(orange_pin, LOW);
    
    noTone(buzzer_pin);
  }
  
  else if(distanceCm <150 && distanceCm > 50)
  {
    digitalWrite(blue_pin, LOW);
    digitalWrite(orange_pin, LOW);
    digitalWrite(red_pin, HIGH);
    tone(buzzer_pin, 1);
    delay(1000);
    digitalWrite(red_pin, LOW);
    noTone(buzzer_pin);
    delay(1000);
  }
  
  else
  {
   	digitalWrite(blue_pin, HIGH);
   	digitalWrite(red_pin, HIGH);
    digitalWrite(orange_pin, HIGH);
    tone(buzzer_pin, 1);
   	delay(500 + 10 * distanceCm);
    digitalWrite(blue_pin, LOW);
   	digitalWrite(red_pin, LOW);
    digitalWrite(orange_pin, LOW);
    noTone(buzzer_pin);
    delay(500 + 10 * distanceCm);
  }
}