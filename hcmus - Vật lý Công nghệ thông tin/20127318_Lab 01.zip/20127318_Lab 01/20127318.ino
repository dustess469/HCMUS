// C++ code

int button = 13;

int lastMillis = 0;
int lastState = LOW;

void setup()
{

  pinMode(button,INPUT);
  pinMode(7, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(2, OUTPUT);
}

void loop(){
  int buttonState = digitalRead(button);
  if(buttonState != lastState){
    lastMillis = millis();
    lastState = buttonState;
  }
  
  if(buttonState == HIGH){
    if(millis() - lastMillis > 12000){
      digitalWrite(7,HIGH);
      digitalWrite(6,HIGH);
      digitalWrite(5,HIGH);
      digitalWrite(4,HIGH);
      digitalWrite(3,HIGH);
      digitalWrite(2,HIGH);
    }  
    else{
      digitalWrite(7,HIGH);
      delay(1000);
      digitalWrite(7,LOW);
	  
      if(digitalRead(button) == HIGH){
        digitalWrite(6,HIGH);
        delay(1000);
        digitalWrite(6,LOW);
      }
	  
      if(digitalRead(button) == HIGH){
        digitalWrite(5,HIGH);
        delay(1000);
        digitalWrite(5,LOW);
      }

      if(digitalRead(button) == HIGH){
        digitalWrite(4,HIGH);
        delay(1000);
        digitalWrite(4,LOW);
      }

      if(digitalRead(button) == HIGH){
        digitalWrite(3,HIGH);
        delay(1000);
        digitalWrite(3,LOW);
      }

      if(digitalRead(button) == HIGH){
        digitalWrite(2,HIGH);
        delay(1000);
        digitalWrite(2,LOW);
      }
    }
  }
  else{
    digitalWrite(7,LOW);
    digitalWrite(6,LOW);
    digitalWrite(5,LOW);
    digitalWrite(4,LOW);
    digitalWrite(3,LOW);
    digitalWrite(2,LOW);
  }
}