#include<iostream>

using namespace std;

int main() {
	double n,k;
	int tmp;
	cout << "So luong tan gao: ";
	cin >> n;
	tmp = n * 1000;
	k = tmp / 20;
	cout << "So luong bao gao: " << k + 1;
	return 0;
}