#include<iostream>

using namespace std;

int main() {
	double vanToc, quangDuong, thoiGian;
	cout << "Quang duong S: ";
	cin >> quangDuong;
	cout << "Van toc V: ";
	cin >> vanToc;
	thoiGian = quangDuong / vanToc;
	cout << "Thoi gian T: " << thoiGian;
	return 0;
}