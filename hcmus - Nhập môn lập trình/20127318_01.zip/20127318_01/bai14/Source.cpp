#include<iostream>

using namespace std;

int main() {
	int n, m, o, p;
	int to10, to5, to2, to1;
	cout << "Nhap so tien: ";
	cin >> n;
	to10 = n / 10000;
	m = n % 10000;
	to5 = m / 5000;
	o = m % 5000;
	to2 = o / 2000;
	p = o % 2000;
	to1 = p / 1000;
	cout << "So to 10000: " << to10 << endl;
	cout << "So to 5000: " << to5 << endl;
	cout << "So to 2000: " << to2 << endl;
	cout << "So to 1000: " << to1;
	return 0;
}