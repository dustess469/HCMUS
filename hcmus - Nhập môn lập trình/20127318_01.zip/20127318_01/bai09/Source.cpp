#include<iostream>

using namespace std;

int main() {
	double sanPhamKoVAT, sanPhamCoVAT;
	cout << "Gia tien san pham chua co VAT: ";
	cin >> sanPhamKoVAT;
	sanPhamCoVAT = sanPhamKoVAT + (0.1 * sanPhamKoVAT);
	cout << "Thanh tien san pham khi co VAT: " << sanPhamCoVAT;
	return 0;
}