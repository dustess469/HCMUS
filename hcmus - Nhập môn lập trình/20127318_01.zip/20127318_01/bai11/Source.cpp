#include<iostream>

using namespace std;

int main() {
	int giay,gio,phut;
	int n, k;
	cout << "Nhap so giay: ";
	cin >> n;
	gio = n / 3600;
	k = n % 3600;
	phut = k / 60;
	giay = k % 60;
	cout << "Thoi gian: " << gio << ":" << phut << ":" << giay;
	return 0;
}