#include<iostream>

using namespace std;

int main() {
	double r;
	cout << "Nhap r: ";
	cin >> r;
	double dienTich, chuVi;
	dienTich = r * r * 3.14;
	chuVi = 2 * r * 3.14;
	cout << "Chu vi hinh tron: " << chuVi << endl;
	cout << "Dien tich hinh tron: " << dienTich << endl;
	return 0;
}