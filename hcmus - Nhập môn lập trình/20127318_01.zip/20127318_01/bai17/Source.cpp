#include<iostream>

using namespace std;

int main() {
	double w, h;
	double chiSo;
	cout << "Can nang: ";
	cin >> w;
	cout << "Chieu cao: ";
	cin >> h;
	chiSo = w / (h * h);
	cout << "Chi so BMI: " << chiSo;
	return 0;
}