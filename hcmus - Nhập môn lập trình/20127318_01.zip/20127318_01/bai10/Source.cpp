#include<iostream>

using namespace std;

int main() {
	int soNguyenDuong;
	cout << "Nhap so nguyen duong: ";
	cin >> soNguyenDuong;
	cout << "So dao nguoc la: ";
	for (; soNguyenDuong != 0; soNguyenDuong = soNguyenDuong / 10) {
		cout << soNguyenDuong % 10;
	}
	return 0;
}