#include<iostream>

using namespace std;

int main() {
	int a, b, c, d, e;
	int gio, phut, giay;

	cout << "Nhap n: 5\n";
	cout << "Thoi gian nguoi 1: ";
	cin >> a;
	cout << "Thoi gian nguoi 2: ";
	cin >> b;
	cout << "Thoi gian nguoi 3: ";
	cin >> c;
	cout << "Thoi gian nguoi 4: ";
	cin >> d;
	cout << "Thoi gian nguoi 5: ";
	cin >> e;

	int tong = a + b + c + d + e;
	gio = tong/ 3600;
	giay = tong % 3600;
	phut = tong / 60;
	giay = tong % 60;

	cout << gio << ":" << phut << ":" << giay;
	return 0;
}