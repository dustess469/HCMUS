#include<iostream>
#include<cmath>
#include <iomanip>

using namespace std;

int main() {
	double M1, M2;
	double k = 6.67 * pow(10, -11);
	double d,F;
	cout << "Nhap khoi luong 2 vat: ";
	cin >> M1 >> M2;
	cout << "Nhap khoang cach: ";
	cin >> d;
	F = k * ((M1 * M2) / (d * d));
	cout << fixed << setprecision(11) << "Luc hap dan: " << F;
	return 0;
}