#include<iostream>

using namespace std;

int main() {
	cout << 321 - 123 << endl;
	return 0;
}