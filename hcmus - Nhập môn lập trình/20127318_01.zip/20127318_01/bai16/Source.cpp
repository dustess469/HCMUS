#include <iostream>

using namespace std;

int main() {
	int x, y;
	int a, b, c;
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
	cout << endl;

	if (x > 1000 || x < 99 || y > 1000 || y < 99)
		cout << "Nhap loi";
	else {
		a = y / 100;
		c = y % 10;
		b = (y % 100) / 10;
		cout << "   " << x << endl;
		cout << " x " << y << endl;
		cout << "-------------" << endl;
		cout << "      " << c * x << endl;
		cout << "    " << b * x << endl;
		cout << "  " << a * x << endl;
		cout << "-------------" << endl;
		cout << x * y << endl;
	}
	return 0;
}
