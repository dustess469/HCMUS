#include<iostream>

using namespace std;

int main() {
	double khoiLuong, khoiLuongRieng, theTich;
	cout << "Khoi luong m: ";
	cin >> khoiLuong;
	cout << "Khoi luong rieng D: ";
	cin >> khoiLuongRieng;
	theTich = khoiLuong / khoiLuongRieng;
	cout << "The tich V: " << theTich << endl;
	return 0;
}