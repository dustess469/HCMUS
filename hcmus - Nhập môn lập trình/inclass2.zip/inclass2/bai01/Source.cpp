#include <iostream>
#include <algorithm>
#include <map>
#include <iterator>

using namespace std;

int main() {
	int n; 
	cin >> n;
	int a[105];
	map <int, int> ans;
	for (int i = 1; i <= n; ++i) {
		int tmp; 
		cin >> tmp;
		++ans[tmp];
	}
	int x;
	cin >> x;
	cout << endl;
	cout << ans[x];
	return 0;
}