#include <iostream>
#include <algorithm>
#include <map>
#include <iterator>


using namespace std;

int main() {
	int n; 
	cin >> n;
	int a[105];
	map <int, int> ans;
	int mx = 0;
	for (int i = 1; i <= n; ++i) {
		int tmp; 
		cin >> tmp;
		++ans[tmp];
		mx = max(mx, ans[tmp]);
	}
	for (int i = 1; i <= n; ++i) {
		if (ans[i] == mx) {
			cout << i << endl;
		}
	}
	return 0;
}
