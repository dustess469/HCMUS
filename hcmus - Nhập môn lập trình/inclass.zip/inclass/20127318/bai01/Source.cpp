#include<iostream>

using namespace std;

int main() {
	int a, b;
	cout << "Nhap a = ";
	cin >> a;
	cout << "Nhap b = ";
	cin >> b;

	if (a== 0 || b==0) {
		cout << "Khong co uoc chung\n";
	}
	else {
		for (int i = a; i > 0; --i) {
			if (a % i == 0 && b % i == 0) {
				cout << "Uoc chung lon nhat cua 2 so a,b = " << i << endl;
				break;
			}
		}
	}
	return 0;
}