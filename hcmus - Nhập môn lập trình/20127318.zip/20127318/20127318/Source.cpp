#include <iostream>
#include <string.h> // Mo comment neu dung mang ky tu

using namespace std;

// Struct cho bai 01
struct HocSinh
{
    int maSo;
    float diemTrungBinh;
    char loaiHanhKiem; // 't' - Tot, 'k' - Kha, 'b' - Trung binh, 'y' - Yeu
};

/* Bai 01: Chon danh sach hoc sinh xuat sac
 * - Dau vao:
 *      + danhSachHS: mang mot chieu co kieu du lieu HocSinh
 *      + n: so luong hoc sinh
 */

void Remove(HocSinh danhSachHS[], int& n)
{
    for (int i = 0; i < n; ++i) {
        if (danhSachHS[i].diemTrungBinh < 9 || danhSachHS[i].loaiHanhKiem != 't') {
            for (int j = i; j < n - 1; ++j) {
                danhSachHS[j] = danhSachHS[j + 1];
            }
            --n;
            --i;
        }
    }
}

/* Bai 02: Kiem tra tinh hop le cua mat khau
 * - Dau vao: matKhau <string> - mat khau can kiem tra
 * - Dau ra: hop le hay khong. true - hop le. false - khong hop le.
 */
bool Check(string matKhau)
{
    int count = 0;
    if (matKhau.length() < 8 || matKhau.length() > 20) {
        return false;
    }
    for (int i = 0; i < matKhau.length(); ++i) {
        if (matKhau[i] >= 33 && matKhau[i] <= 38) {
            ++count;
        }
    }
    if (count == 0) {
        return false;
        count = 0;
    }
    for (int i = 0; i < matKhau.length(); ++i) {
        if (matKhau[i] >= 48 && matKhau[i] <= 57) {
            ++count;
        }
    }
    if (count == 0) {
        return false;
    }
    return true;
}

/* Bai 03: Tim vi tri cot ngua
 * - Dau vao:
 *      + manhDat: mang 2 chieu, gia tri 0 --> o dat binh thuong, gia tri 1 --> o dat co co
 *      + mDong: chieu doc cua manh dat
 *      + nCot: chieu ngang cua manh dat
 *      + x: do dai day cot ngua
 * - Dau ra: duoc tra qua tham chieu
 *      + xDong: dong co the cot ngua
 *      + yCot: cot co the cot ngua
 */
void FindCoord(int manhDat[][100], int mDong, int nCot, int x, int& xDong, int& yCot)
{
    int co1 = 0;
    int max = 0;
    xDong = yCot = 0;
    for (int i = 0; i < mDong; ++i) {
        for (int j = 0; j < nCot; ++j) {
            for (int k = 0; k < mDong; ++k) {
                for (int h = 0; h < nCot; ++h) {
                    if (manhDat[k][h] == 1 && (double)x * (double)x >= (abs(i - k) * abs(i - k)) + (abs(j - h) * abs(j - h))) {
                        ++co1;
                    }
                }
            }
            if (co1 > max) {
                max = co1;
                xDong = i;
                yCot = j;
            }
            co1 = 0;
        }
    }
}

/* Bai 04: Tinh bieu thuc
 * - Dau vao: bieuThuc <string> - bieu thuc can tinh
 * - Dau ra: gia tri bieu thuc
 */
int Calc(string bieuThuc)
{
    
    return -1;
}


int main()
{
    // Test bai 01 ----------------------------------------------------------------------------------
    HocSinh danhSachHS[100];
    int n = 5;
    danhSachHS[0] = { 101, 8.0, 't' };
    danhSachHS[1] = { 102, 9.0, 't' };
    danhSachHS[2] = { 103, 8.5, 't' };
    danhSachHS[3] = { 104, 10.0, 't' };
    danhSachHS[4] = { 105, 7.0, 'b' };
    Remove(danhSachHS, n);
    cout << "Bai 01: ";
    if (n == 2 && danhSachHS[0].maSo == 102 && danhSachHS[0].diemTrungBinh == 9 && danhSachHS[0].loaiHanhKiem == 't'
        && danhSachHS[1].maSo == 104 && danhSachHS[1].diemTrungBinh == 10 && danhSachHS[1].loaiHanhKiem == 't')
        cout << "Dung vi du de bai" << endl;
    else
        cout << "Sai vi du de bai" << endl;


    // Test bai 02 ----------------------------------------------------------------------------------
    string matKhau1 = "matkhaumoi1!", matKhau2 = "matkhau123";
    cout << "Bai 02: ";
    if (Check(matKhau1) == true && Check(matKhau2) == false)
        cout << "Dung vi du de bai" << endl;
    else
        cout << "Sai vi du de bai" << endl;


    // Test bai 03 ----------------------------------------------------------------------------------
    int manhDat[100][100] = { {0, 0, 1, 0, 0},
                             {0, 0, 0, 0, 0},
                             {1, 0, 0, 0, 1},
                             {0, 0, 0, 0, 0},
                             {0, 0, 1, 0, 0} };
    int mDong = 5, nCot = 5, x = 2;
    int xDong, yCot;
    FindCoord(manhDat, mDong, nCot, x, xDong, yCot);
    cout << "Bai 03: ";
    if (xDong == 2 && yCot == 2)
        cout << "Dung vi du de bai" << endl;
    else
        cout << "Sai vi du de bai" << endl;


    // Test bai 04 ----------------------------------------------------------------------------------
    string bieuThuc = "12+5x18";
    cout << "Bai 04: ";
    if (Calc(bieuThuc) == 102)
        cout << "Dung vi du de bai" << endl;
    else
        cout << "Sai vi du de bai" << endl;

    return 0;
}