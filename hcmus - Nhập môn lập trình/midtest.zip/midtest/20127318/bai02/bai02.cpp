#include<iostream>

using namespace std;

bool check(int a) {
	a = abs(a);
	while (a > 0) {
		int temp = a % 10;
		if (temp % 2 == 1) {
			return false;
		}
		a /= 10;
	}
	return true;
}

int main() {
	int a[100], count = 0, min, ans;
	for (int i = 0; a[i - 1] != -1; ++i) {
		std::cout << "Nhap vao so du thuong (nhap -1 de dung) : ";
		cin >> a[i];
		++count;
	}
	a[count - 1] = '\0';
	min = a[0];
	for (int i = 0; a[i] != '\0'; ++i) {
		if (min > a[i]) {
			min = a[i];
		}
	}
	ans = min;
	for (int i = 0; a[i] != '\0'; ++i) {
		if (check(a[i]) == 1 && a[i] > ans) {
			ans = a[i];
		}
	}

	std::cout << endl;
	std::cout << "So may man trung giai la: " << ans << endl;
	return 0;
}