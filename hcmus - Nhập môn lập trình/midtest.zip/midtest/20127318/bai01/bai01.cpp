#include <iostream>

using namespace std;

int main() {
	int kWh[100], ans = 0, thang;
	cout << "Nhap vao so thang su dung: ";
	cin >> thang;
	cout << endl;
	for (int i = 1; i <= thang; ++i) {
		cout << "Nhap san luong dien thang " << i << ": ";
		cin >> kWh[i];
	}
	for (int i = 1; i <= thang; ++i) {
		if (kWh[i] <= 150) {
			kWh[i] = kWh[i] * 1484;
		}
		else if (kWh[i] >= 151 && kWh[i] <= 300) {
			kWh[i] = 150 * 1484 + (kWh[i] - 150) * 1533;
		}
		else if (kWh[i] >= 301 && kWh[i] <= 450) {
			kWh[i] = 150 * 1484 + 150 * 1533 + (kWh[i] - 300) * 1786;
		}
		else if (kWh[i] >= 451 && kWh[i] <= 600) {
			kWh[i] = 150 * 1484 + 150 * 1533 + 150 * 1786 + (kWh[i] - 450) * 2242;
		}
		else if (kWh[i] >= 601 && kWh[i] <= 750) {
			kWh[i] = 150 * 1484 + 150 * 1533 + 150 * 1786 + 150 * 2242 + (kWh[i] - 600) * 2503;
		}
		else {
			kWh[i] = 150 * 1484 + 150 * 1533 + 150 * 1786 + 150 * 2242 + 150 * 2503 + (kWh[i] - 750) * 2587;
		}
	}
	for (int i = 1; i <= thang; ++i) {
		ans += kWh[i];
	}
	cout << "\nTong tien phai tra: " << ans << " (dong)\n";
	return 0;
}