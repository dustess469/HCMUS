#include<iostream>

using namespace std;

int main() {
	int n;

	cout << "nhap x: ";
	cin >> n;

	if (n <= 9) 
		cout << static_cast<char>(n + 48);
	else 
		cout << static_cast<char>(n + 55);
}