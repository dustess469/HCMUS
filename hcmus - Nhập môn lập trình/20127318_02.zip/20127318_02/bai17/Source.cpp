#include<iostream>

using namespace std;

int main() {
	string a;

	cout << "Nhap gioi tinh: ";
	cin >> a;
	
	if (a == "nu") {
		double a1, a2, a3, a4, a5;
		double b, mo, phantram;
		cout << "Nhap can nang: ";
		cin >> a1;
		cout << "Nhap kich thuoc co tay: ";
		cin >> a2;
		cout << "Nhap kich thuoc eo: ";
		cin >> a3;
		cout << "Nhap kich thuoc hong: ";
		cin >> a4;
		cout << "Nhap kich thuoc canh tay: ";
		cin >> a5;
		
		b = (a1 * 0.732) + 8.987 + a2 / 3.14 - a3 * 0.157 - a4 * 0.249 + a5 * 0.434;
		mo = a1 - b;
		phantram = mo * 100 / a1;
		
		cout << "Luong mo: " << mo << endl;
		cout << "Phan tram luong mo: " << phantram << endl;
	}
	else if (a == "nam") {
		double a1, a2;

		cout << "Nhap can nang: ";
		cin >> a1;
		cout << "Nhap kich thuoc co tay: ";
		cin >> a2;
		
		double b = a1 * 1.082 + 9.442 - a2 * 4.15;
		double mo = a1 - b;
		double phantram = mo * 100 / a1;
		
		cout << "Luong mo: " << mo << endl;
		cout << "Phan tram luong mo: " << phantram << endl;
	}
	return 0;
}