#include<iostream>

using namespace std;

int main() {
	int n,x;
	cout << "Nhap n: ";
	cin >> n;
	if (n > 0) {
		x = sqrt(n);
		if (x * x == n) {
			cout << n << " la so chinh phuong\n";
		}
		else {
			cout << n << " khong la so chinh phuong\n";
		}
	}
	else {
		cout << "Nhap sai. Moi nhap lai\n";
	}
}