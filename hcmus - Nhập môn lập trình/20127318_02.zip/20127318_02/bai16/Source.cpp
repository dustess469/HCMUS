#include<iostream>

using namespace std;

int main() {
	char account;
	double min, money;

	cout << "Nhap loai tai khoan" << endl;
	cout << "Nhap 't' neu la tai khoan tiet kiem" << endl;
	cout << "Nhap 'v' neu la tai khoan vang lai" << endl;
	cin >> account;
	cout << "Nhap so du toi thieu: ";
	cin >> min;
	cout << "Nhap so du cuoi thang: ";
	cin >> money;

	if (account == 't') {
		if (min > money)
			cout << "So tien phat: $10\n";
		else
			cout << "So tien lai: " << money * 0.04 << endl;
	}
	else {
		if (min > money) 
			cout << "So tien phat: $25\n";
		else {
			if (money - min >= 50000) {
				cout << "So tien lai: " << money * 0.03 << endl;
			}
			else {
				cout << "So tien lai: " << money * 0.05 << endl;
			}
		}
	}
	return 0;
}