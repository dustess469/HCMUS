#include<iostream>

using namespace std;

int main() {
	int tocDo;
	double mucPhat;

	cout << "Nhap toc do: ";
	cin >> tocDo;

	if (tocDo <= 5)
		cout << "Khong bi phat" << endl;
	else if (tocDo > 5 && tocDo <= 10)
		mucPhat = 0.7;
	else if (tocDo > 10 && tocDo <= 20)
		mucPhat = 2.5;
	else if (tocDo > 20 && tocDo <= 35)
		mucPhat = 5.5;
	else
		mucPhat = 7.5;
	cout << "So tien phat: " << mucPhat << " trieu" << endl;
	return 0;
}