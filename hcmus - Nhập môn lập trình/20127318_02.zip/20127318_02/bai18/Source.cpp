#include<iostream>

using namespace std;

int main() {
	double w, h;
	double BMI;

	cout << "Nhap can nang: ";
	cin >> w;
	cout << "Nhap chieu cao: ";
	cin >> h;

	BMI = w / (h * h);

	if (BMI < 18.5) 
		cout << "Duoi chuan\n";
	if (BMI >= 18.5 && BMI < 25) 
		cout << "Chuan\n";
	if (BMI >= 25 && BMI < 30) 
		cout << "Thua can\n";
	if (BMI >= 30 && BMI < 40) 
		cout << "Beo - nen giam can\n";
	if (BMI >= 40) 
		cout << "Rat beo - can giam can ngay\n";
	return 0;
}