#include<iostream>

using namespace std;

int main() {
	int km;
	int tongTien;

	cout << "Nhap km: ";
	cin >> km;

	if (km == 1)
		tongTien = 15000;
	else if (km >= 2 && km <= 5)
		tongTien = (13500 * (km - 1)) + 15000;
	else if (km >= 6)
		tongTien = (11000 * (km - 5)) + (13500 * (km - 1)) + 15000;
	if (km > 120)
		tongTien = ((11000 * (km - 5)) + (13500 * (km - 1)) + 15000) * 0.1;

	cout << "Tien di taxi: " << tongTien << "d\n";
	return 0;
}