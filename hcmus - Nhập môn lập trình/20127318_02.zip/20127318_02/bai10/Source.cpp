#include<iostream>

using namespace std;
 
int main() {
	int soCu, soMoi, tienTra, tieuThu;

	cout << "Nhap chi so cu: ";
	cin >> soCu;
	cout << "Nhap chi so moi: ";
	cin >> soMoi;

	tieuThu = soMoi - soCu;
	if (tieuThu <= 100)
		tienTra = tieuThu * 1000;
	else if (tieuThu >= 101 && tieuThu <= 150)
		tienTra = 100 * 1000 + (tieuThu - 100) * 1200;
	else if (tieuThu >= 151 && tieuThu <= 200)
		tienTra = 100 * 1000 + 50 * 1200 + (tieuThu - 150) * 2000;
	else
		tienTra = 100 * 1000 + 50 * 1200 + 50 * 2000 + (tieuThu - 200) * 2500;
	cout << "So tien phai tra: " << tienTra << endl;
	return 0;
}