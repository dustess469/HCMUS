#include<iostream>

using namespace std;

int main() {
	double a, b, c;

	cout << "Nhap 3 canh: ";
	cin >> a >> b >> c;

	if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
		cout << "3 so tren la 3 canh cua tam giac vuong\n";
	else
		cout << "3 so tren khong la 3 canh cua tam giac vuong\n";
	return 0;
}