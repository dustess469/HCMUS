#include<iostream>

using namespace std;

int main() {
	float a, b;
	char toanTu;

	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap toan tu: ";
	cin >> toanTu;
	
	switch (toanTu)
	{
	case'+':
		cout << "Tong: " << a + b << endl;
		break;
	case'-':
		cout << "Hieu: " << a - b << endl;
		break;
	case'*':
		cout << "Tich: " << a * b << endl;
		break;
	case'/':
		if (b == 0)
			cout << "Gia tri khong hop le\n";
		else
			cout << "Thuong: " << a / b << endl;
		break;
	default:
		cout << "Nhap sai\n";
		break;
	}
	return 0;
}