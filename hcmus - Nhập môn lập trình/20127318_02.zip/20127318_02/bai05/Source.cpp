#include<iostream>

using namespace std;

int main() {
	int thang, nam;
	bool namNhuan = false;

	cout << "Nhap thang: ";
	cin >> thang;
	cout << "Nhap nam: ";
	cin >> nam;
	cout << endl;

	if ((nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0)) {
		namNhuan = true;
		cout << "Nam " << nam << " la nam nhuan\n";
	}
	else
		cout << "Nam " << nam << " khong la nam nhuan\n";

	switch (thang) {
	case 1: case 3: case 5:case 7: case 8:case 10: case 12:
		cout << "Thang " << thang << " co 31 ngay\n";
		break;
	case 4:case 6: case 9: case 11:
		cout << "Thang " << thang << " co 30 ngay\n";
		break;
	case 2:
		if (namNhuan == true)
			cout << "Thang " << thang << " co 29 ngay\n";
		else
			cout << "Thang " << thang << " co 28 ngay\n";
		break;
	default:
		cout << "Nhap sai! Moi nhap lai";
		break;
	}
	return 0;
}