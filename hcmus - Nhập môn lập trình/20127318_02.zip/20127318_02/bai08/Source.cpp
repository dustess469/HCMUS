#include<iostream>

using namespace std;

int main() {
	int a, b, c;

	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;
	
	if ((a + b > c) && (a + c > b) && (b + c > a)) {
		cout << "3 canh tren lap thanh mot tam giac\n" ;
		if (a == b || a == c || b == c)
			cout << "Tam giac tren la tam giac can\n";
		else if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
			cout << "Tam giac tren la tam giac vuong\n";
		else if (a == b && b == c && a == c)
			cout << "Tam giac tren la tam giac deu\n";
		else
			cout << "Tam giac tren la tam giac thuong\n";
	}
	else cout << "3 canh tren khong lap thanh mot tam giac\n";
	return 0;
}