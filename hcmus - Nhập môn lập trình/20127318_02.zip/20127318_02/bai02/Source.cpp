#include<iostream>

using namespace std;

int main() {
	double toan, ly, hoa;
	double tong = toan + ly + hoa;

	cout << "Nhap diem Toan: ";
	cin >> toan;
	cout << "Nhap diem Ly: ";
	cin >> ly;
	cout << "Nhap diem Hoa: ";
	cin >> hoa;
	
	if ((tong >= 15) && (toan >= 4) && (ly >= 4) && (hoa >= 4)) {
		cout << "Dau\n";
		if ((toan > 5) && (ly > 5) && (hoa > 5))
		cout << "Hoc deu cac mon\n";
		else if ((toan < 5) || (ly < 5) || (hoa < 5))
		cout << "Hoc chua deu cac mon\n";
	}
	else
		cout << "Thi hong\n";
	return 0;
}