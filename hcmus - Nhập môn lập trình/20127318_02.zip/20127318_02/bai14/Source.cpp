#include<iostream>
#include<math.h>

using namespace std;

int main() {
	float a, b, c, delta, x, y;

	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;

	if (a == 0) {
		if (b == 0) {
			if (c == 0) {
				cout << "Phuong trinh co vo so nghiem\n";
			}
			else
				cout << "Phuong trinh vo nghiem\n";
		}
		else
			cout << "Phuong trinh co mot nghiem: " << -c / b << endl;
	}
	else {
		delta = (b * b) - (4 * a * c);
		if (delta > 0) {
			x = (-b + sqrt(delta)) / (2 * a);
			y = (-b - sqrt(delta)) / (2 * a);
			cout << "Nghiem thu nhat: " << x << endl;
			cout << "Nghiem thu hai: " << y << endl;
		}
		else if (delta == 0)
			cout << "Phuong trinh co nghiem kep: x = y = " << -b / (2 * a) << endl;
		else
			cout << "Phuong trinh vo nghiem\n";
	}
	return 0;
}