#include<iostream>

using namespace std;

int main() {
	int a, b, c;

	cout << "Nhap a,b,c: ";
	cin >> a >> b >> c;

	int max = a;
	int min = b;

	//Max
	if (b > a) 
		max = b;
	if (c > a)
		max = c;

	//Min
	if (a < b)
		min = a;
	if (c < b)
		min = c;

	cout << "So lon nhat: " << max << endl;
	cout << "So nho nhat: " << min << endl;
	return 0;
}