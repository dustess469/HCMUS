#include<iostream>

using namespace std;

int main() {
	int gio, phut, giay;

	cout << "Nhap gio: ";
	cin >> gio;
	cout << "Nhap phut: ";
	cin >> phut;
	cout << "Nhap giay: ";
	cin >> giay;
	
	if ((gio >= 0 && gio <= 23) && (phut >= 0 && phut <= 59) && (giay >= 0 && giay <= 59)) {
		cout << "Thoi gian hop le\n";
	}
	else {
		cout << "Thoi gian khong hop le\n";
	}
	return 0;
}