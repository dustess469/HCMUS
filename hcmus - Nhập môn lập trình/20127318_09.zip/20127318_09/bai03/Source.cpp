#include<iostream>

using namespace std;

struct phanSo {
	int tu;
	int mau;
};

void input(phanSo& p) {
	cout << "\nNhap tu: ";
	cin >> p.tu;
	cout << "Nhap mau: ";
	cin >> p.mau;
}

void output(phanSo p) {
	if (p.mau == 0) {
		cout << "Nhap sai! Moi nhap lai\n";
	}
	else {
		cout << p.tu << "/" << p.mau << endl;
	}
}

phanSo nhoNhat(phanSo a[], int n) {
	phanSo min = a[0];
	int i = 0;
	int b, c;
	while (i < n) {
		c = min.tu * a[i].mau;
		b = a[i].tu * min.mau;
		if (c > b)
		{
			min = a[i];
		}
		++i;
	}
	return min;
}
int main() {
	phanSo a[100];
	int n;
	cout << "Nhap so luong phan tu: ";
	cin >> n;
	for (int i = 0; i < n; ++i) {
		cout << "Nhap phan so thu " << i + 1 << " : ";
		input(a[i]);
	}
	cout << "Phan so nho nhat: ";
	output(nhoNhat(a, n));
	return 0;
}