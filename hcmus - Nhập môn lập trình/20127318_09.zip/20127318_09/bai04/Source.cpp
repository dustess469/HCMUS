#include <iostream>
#include <string.h>
#include<string>

using namespace std;

struct Info {
	int id;
	char name[100];
	double math;
	double physic;
	double chemistry;
};

void input(Info& a) {
	cout << "Nhap id cua sinh vien: ";
	cin >> a.id;
	cin.ignore(1);
	cout << "Nhap ten cua sinh vien: ";
	cin.getline(a.name, 100);
	cout << "Nhap diem toan: ";
	cin >> a.math;
	cout << "Nhap diem ly: ";
	cin >> a.physic;
	cout << "Nhap diem hoa: ";
	cin >> a.chemistry;
}

void output(Info a) {
	cout << "Id: " << a.id << endl;
	cout << "Ten: " << a.name << endl;
	cout << "Diem toan: " << a.math << endl;
	cout << "Diem ly: " << a.physic << endl;
	cout << "Diem hoa: " << a.chemistry << endl;
}

int main() {
	Info student[100];
	double average = 0, gpa[100], max, min;
	int n, pos1 = 0, pos2 = 0;
	cout << "Nhap so luong so luong sinh vien: ";
	cin >> n;
	for (int i = 0; i < n; ++i) {
		cout << "\nNhap thong tin cua sinh vien " << i + 1 << ": " << endl;
		input(student[i]);
		average = (student[i].math + student[i].physic + student[i].chemistry) / 3;
		gpa[i] = average;
	}
	max = min = gpa[0];
	for (int i = 0; i < n; ++i) {
		if (max < gpa[i]) {
			max = gpa[i];
			pos1 = i;
		}
		if (min > gpa[i]) {
			min = gpa[i];
			pos2 = i;
		}
	}
	cout << "\nThong tin sinh vien co diem trung binh cao nhat: " << endl;
	output(student[pos1]);
	cout << "\nThong tin sinh vien co diem trung binh thap nhat: " << endl;
	output(student[pos2]);
	return 0;
}