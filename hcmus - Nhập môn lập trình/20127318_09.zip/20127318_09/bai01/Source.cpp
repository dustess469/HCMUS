#include<iostream>

using namespace std;

struct thoiGian {
	int gio, phut, giay;
};

void input(thoiGian& t) {
	cout << "Nhap gio: ";
	cin >> t.gio;
	cout << "Nhap phut: ";
	cin >> t.phut;
	cout << "Nhap giay: ";
	cin >> t.giay;
}

void output(thoiGian t) {
	if (t.gio < 0 || t.gio>24 || t.phut < 0 || t.phut>59 || t.giay < 0 || t.giay>59) {
		cout << "Nhap sai! Moi nhap lai";
	}
	else {
		cout << t.gio << " : " << t.phut << " : " << t.giay;
	}
}


int main() {
	thoiGian t1;
	cout << "Nhap thoi gian thu nhat:\n";
	input(t1);

	thoiGian t2;
	cout << "Nhap thoi gian thu hai:\n";
	input(t2);

	int tmp1 = t1.gio * 3600 + t1.phut * 60 + t1.giay;
	int tmp2 = t2.gio * 3600 + t2.phut * 60 + t2.giay;
	int time = abs(tmp1 - tmp2);
	int hour = time / 3600;
	time -= hour * 3600;
	int minute = time / 60;
	time -= minute * 60;
	int second = time;

	if (t1.gio < 0 || t1.gio>24 || t1.phut < 0 || t1.phut>59 || t1.giay < 0 || t1.giay>59 || t2.gio < 0 || t2.gio>24 || t2.phut < 0 || t2.phut>59 || t2.giay < 0 || t2.giay>59) {
		cout << "\nNhap sai! Moi nhap lai\n";
	}
	else {
		cout << "\nKhoang thoi gian giua 2 moc thoi gian: " << hour << " : " << minute << " : " << second << endl;
	}
	return 0;
}