#include<iostream>
#include<string.h>
#include<string>

using namespace std;

struct car {
	string carMake;
	string carModel;
	int yearModel;
	double cost;
	int quantity;
};

void input(car& a) {
	cin.ignore(1);
	cout << "Nhap ten hang: ";
	getline(cin, a.carMake);
	cout << "Nhap ten Model: ";
	getline(cin, a.carModel);
	cout << "Nhap nam san xuat: ";
	cin >> a.yearModel;
	cout << "Nhap gia: ";
	cin >> a.cost;
	cout << "Nhap so luong: ";
	cin >> a.quantity;
}

void output(car a) {
	cout << "Ten hang: " << a.carMake << endl;
	cout << "Ten model: " << a.carModel << endl;
	cout << "Nam san xuat: " << a.yearModel << endl;
	cout << "Gia: " << a.carMake << endl;
	cout << "So luong: " << a.quantity << endl;
}

void Add(car a[], int& n) {
	++n;
	cout << "Nhap thong tin xe muon them: " << endl;
	input(a[n - 1]);
	cout << endl;
}

void Sell(car a[], int& n, string s) {
	int pos = 0, count = 0;
	for (int i = 0; i < n; ++i) {
		if (a[i].carModel == s) {
			++count;
			pos = i;
		}
	}
	if (count == 0) {
		cout << "Khong co loai xe nay trong cua hang" << endl;
		return;
	}
	if (count == 1) {
		if (a[pos].quantity <= 0) {
			cout << "Khong con loai xe nay trong cua hang" << endl;
			return;
		}
		else {
			a[pos].quantity -= 1;
			cout << "Cua hang con loai xe nay" << endl;
			return;
		}
	}
}

void Delete(car a[], int number, string s, int n) {
	for (int i = 0; i < n; ++i) {
		if (a[i].carModel == s) {
			a[i].quantity -= number;
		}
	}
}

int main() {
	car a[100];
	int n, number;
	string s;
	cout << "Nhap so luong cac xe dang co trong cua hang: ";
	cin >> n;
	for (int i = 0; i < n; ++i) {
		cout << "Xe thu " << i + 1 << ": " << endl;
		input(a[i]);
		cout << endl;
		cout << endl;
	}

	cout << "Cac xe dang co trong cua hang: " << endl;
	for (int i = 0; i < n; ++i) {
		output(a[i]);
		cout << endl;
	}

	Add(a, n);

	cin.ignore(1);
	cout << "Nhap model xe khach hang muon mua: " << endl;
	getline(cin, s);
	Sell(a, n, s);


	cout << "Nhap model xe muon xoa: " << endl;
	cin.ignore(1);
	getline(cin, s);
	cout << "Nhap so luong muon xoa cua model nay: ";
	cin >> number;
	Delete(a, number, s, n);

	return 0;
}