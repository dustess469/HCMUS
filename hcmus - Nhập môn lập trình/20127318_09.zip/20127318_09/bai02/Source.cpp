#include<iostream>

using namespace std;

struct phanSo {
	int tu, mau;
};

void input(phanSo& p) {
	cout << "Nhap tu: ";
	cin >> p.tu;
	cout << "Nhap mau: ";
	cin >> p.mau;
}

void output(phanSo p) {
	if (p.mau == 0) {
		cout << "Nhap sai! Moi nhap lai\n";
	}
	else {
		cout << p.tu << "/" << p.mau << endl;
	}
}


int main() {
	phanSo p1;
	cout << "Nhap phan so 1:\n";
	input(p1);

	phanSo p2;
	cout << "\nNhap phan so 2:\n";
	input(p2);

	cout << "\nPhan so 1: ";
	output(p1);

	cout << "Phan so 2: ";
	output(p2);

	phanSo tong;
	tong.tu = (p1.tu * p2.mau) + (p2.tu * p1.mau);
	tong.mau = p1.mau * p2.mau;
	cout << "Tong 2 phan so: ";
	if (p1.mau == 0 || p2.mau == 0) {
		cout << "Error\n";
	}
	else if (tong.tu == tong.mau) {
		if (tong.mau != 0) {
			cout << "1\n";
		}
		else {
			cout << "Error\n";
		}
	}
	else {
		cout << tong.tu << " / " << tong.mau << endl;
	}
	return 0;
}
