#include<iostream>

using namespace std;

//bai 1
void setArray(int a[], int& n) {
    for (int i = 0; i < n; i++) {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
}

void setArray1(int b[], int& n) {
    for (int i = 0; i < n; i++) {
        cout << "b[" << i << "] = ";
        cin >> b[i];
    }
}

//bai 2
void printArray(int a[], int n) {
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
}

//bai 3
int sumArray(int a[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
    return sum;
}

//bai 4
int findMin(int a[], int n) {
    for (int i = 0; i < n; i++) {
        int min = a[0];
        if (min > a[i]) {
            min = a[i];
        }
        return min;
    }
}

//bai 5
bool Prime(int n) {
    if (n <= 1) {
        return 0;
    }
    int count = 0;
    for (int i = 1; i <= n; ++i) {
        if (n % i == 0) {
            ++count;
        }
    }
    if (count == 2) {
        return 1;
    }
    else {
        return 0;
    }
}

int countNumberofPrime(int a[], int n) {
    int count = 0;
    for (int i = 0; i < n; ++i) {
        if (Prime(a[i]) == 0) {
            ++count;
        }
    }
    return count;
}

//bai 6
bool ascending(int a[], int n) {
    for (int i = 0; i < n - 1; ++i) {
        if (a[i] > a[i + 1]) {
            return 0;
        }
    }
    return 1;
}

//bai 7
int appear(int a[], int n, int x) {
    int count = 0;
    for (int i = 0; i < n; ++i) {
        if (a[i] == x) {
            ++count;
        }
    }
    return count;
}

//bai 8
void myDelete(int a[], int& n, int pos) {
    for (int i = pos; i <= n; ++i) {
        a[i] = a[i + 1];
    }
    --n;
}

void deleteItem(int a[], int& n, int x) {
    for (int i = 0; i < n; ++i) {
        if (a[i] == x) {
            myDelete(a, n, i);
            --i;
        }
    }
}

//bai 9
void deleteItemFromIndex(int a[], int& n, int pos, int num) {
    for (int i = 1; i <= num; ++i) {
        myDelete(a, n, pos - 1);
    }
    ++n;
}

//bai 10
void connect(int a[], int n, int b[], int m,int c[]){
    for (int i = 0; i <= n; ++i) {
        c[i] = a[i];
    }
    int d = 0;
    for (int i = n + 1; i < n + m + 1; ++i) {
        c[i] = b[d];
        ++d;
    }
}

//bai 11
void alternating(int a[], int n, int b[], int m, int c[]) {
    for (int i = 0; i < n; ++i) {
        c[i * 2] = a[i];
    }
    for (int i = 0; i < m; ++i) {
        c[(i * 2) + 1] = b[i];
    }
}

int main() {
    int a[1000];
    int n;

    //bai1
    cout << "Nhap n: ";
    cin >> n;
    setArray(a, n);
    cout << endl;

    //bai2
    cout << "Xuat mang: ";
    printArray(a, n);
    cout << endl;
    cout << endl;

    //bai3
    int sum;
    sum = sumArray(a, n);
    cout << "Tong cac so trong mang: " << sum << endl;
    cout << endl;

    //bai 4
    int min;
    min = findMin(a, n);
    cout << "So nho nhat trong mang: " << min << endl;
    cout << endl;

    // bai 5
    cout << "So luong so nguyen to trong mang: " << countNumberofPrime(a, n) << endl;
    cout << endl;

    // bai 6
    if (ascending(a, n) == 1) {
        cout << "Mang tang dan" << endl;
    }
    else {
        cout << "Mang ko tang dan" << endl;
    }
    cout << endl;

    // bai 7
    int x;
    cout << "Nhap x: ";
    cin >> x;
    cout << "So lan x xuat hien trong mang: " << appear(a, n, x) << endl;
    cout << endl;

    // bai 8
    int temp[100];
    for (int i = 0; i < n; ++i) {
        temp[i] = a[i];
    }
    cout << "Mang sau khi xoa cac phan tu co gia tri x: ";
    deleteItem(temp, n, x);
    printArray(temp, n);
    cout << endl;
    cout << endl;

    // bai 9
    int num, pos;
    cout << "Nhap so luong phan tu xoa: ";
    cin >> num;
    cout << "Nhap vi tri index: ";
    cin >> pos;
    for (int i = 0; i < n; ++i) {
        temp[i] = a[i];
    }
    int tmp1 = n;
    int tmp = a[tmp1];
    deleteItemFromIndex(temp, tmp1, pos, num);
    temp[tmp1 - 1] = tmp;
    printArray(temp, tmp1);
    cout << endl;
    cout << endl;

    // bai 10
    int b[100], m, temp1[100],c[100];
    cout << "Nhap so phan tu mang b: "; 
    cin >> m;
    setArray1(b, m);
    for (int i = 0; i < n; ++i) {
        temp[i] = a[i];
    }
    for (int i = 0; i < m; ++i) {
        temp1[i] = b[i];
    }
    connect(temp, n, temp1, m, c);
    c[n] = a[n];
    cout << "Mang moi: ";
    printArray(c, n + m + 1);
    cout << endl;
    cout << endl;

    // bai 11
    cout << "Mang xen ke: ";
    alternating(a, n, b, m, c);
    printArray(c, n + m + 1);
    cout << endl;


    return 0;
}