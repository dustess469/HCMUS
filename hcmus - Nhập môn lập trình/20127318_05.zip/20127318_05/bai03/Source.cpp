#include <iostream>

using namespace std;

//bai 1
void inputMaxtrix(int a[100][100], int m, int n) {
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			cout << "Nhap a[" << i << "][" << j << "] = ";
			cin >> a[i][j];
		}
	}
}

//bai 2
void outputMatrix(int a[100][100], int m, int n) {
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			cout << a[i][j] << " ";
		}
		cout << endl;
	}
}

//bai 3
int sumMatrix(int a[100][100], int m, int n) {
	int sum = 0;
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			sum = sum + a[i][j];
		}
	}
	return sum;
}

//bai 4
int sumMain(int a[100][100], int n) {
	int sum = 0;
	for (int i = 0; i < n; ++i) {
		sum = sum + a[i][i];
	}
	return sum;
}

//bai 5
int min(int a[100][100], int m, int n) {
	int min = a[0][0];
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			if (min > a[i][j]) {
				min = a[i][j];
			}
		}
	}
	return min;
}

//bai 6
bool prime(int n) {
	if (n <= 1) {
		return 0;
	}
	int count = 0;
	for (int i = 1; i <= n; ++i) {
		if (n % i == 0) {
			++count;
		}
	}
	if (count == 2) {
		return 1;
	}
	else {
		return 0;
	}
}

int numberOfPrime(int a[100][100], int m, int n) {
	int count = 0;
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			if (prime(a[i][j]) == 1) {
				++count;
			}
		}
	}
	return count;
}

//bai 7
int numberOfVar(int a[100][100], int m, int n, int x) {
	int count = 0;
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			if (a[i][j] == x) {
				++count;
			}
		}
	}
	return count;
}

//bai 8
void deleteRow(int a[100][100], int &m, int n, int r) {
	for (int i = r; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			a[i][j] = a[i + 1][j];
		}
	}
	--m;
}

void delteteCol(int a[100][100], int m, int &n, int c) {
	for (int i = 0; i < m; ++i) {
		for (int j = c; j < n; ++j) {
			a[i][j] = a[i][j + 1];
		}
	}
	--n;
}

void myDelete(int a[100][100], int& m, int& n, int x) {
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			if (a[i][j] == x) {
				deleteRow(a, m, n, i);
				delteteCol(a, m, n, j);
			}
		}
	}
}

int main() {
	int a[100][100], n , m ;
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;

	// bai 1
	inputMaxtrix(a, m, n);
	cout << endl;

	// bai 2
	cout << "Xuat mang :" << endl;
	outputMatrix(a, m, n);
	cout << endl;

	// bai 3 
	cout << "Tong cac phan tu trong mang: ";
	cout << sumMatrix(a, m, n) << endl;
	cout << endl;

	// bai 4
	if (m == n) {
		cout << "Tong duong cheo chinh: ";
		cout << sumMain(a, n) << endl;
	}
	else {
		cout << "Mang khong tinh duoc tong duong cheo chinh" << endl;
	}
	cout << endl;

	// bai 5
	cout << "Gia tri nho nhat trong mang: ";
	cout << min(a, m, n) << endl;
	cout << endl;

	// bai 6
	cout << "So luong nguyen to trong mang: " << numberOfPrime(a, m, n) << endl;
	cout << endl;

	// bai 7
	int x;
	cout << "Nhap x: ";
	cin >> x;
	cout << "So lan xuat hien cua x trong mang: " << numberOfVar(a, m, n, x) << endl;
	cout << endl;

	// bai 8

	cout << "Mang sau khi xoa dong cot co gia tri x: " << endl;
	myDelete(a, m, n, x);
	outputMatrix(a, m, n);


	return 0;
}



