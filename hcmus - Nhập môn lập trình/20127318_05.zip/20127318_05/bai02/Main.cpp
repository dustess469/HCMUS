#include <iostream>

using namespace std;

void input(char a[], int n) {
	for (int i = 0; i < n; ++i) {
		cout << "a[" << i << "] = ";
		cin >> a[i];
	}
}

void output(char a[], int n) {
	for (int i = 0; i < n; ++i) {
		cout << a[i] << " ";
	}
}

//bai 1
void myReverse(char a[], int n) {
	int left = 0, right = n - 1;
	char tmp;
	for (int i = 0; left <= right; ++i) {
		tmp = a[left];
		a[left] = a[right];
		a[right] = tmp;
		++left;
		--right;
	}
}

//bai 2
bool check(char a[], int n) {
	char b[100];
	for (int i = 0; i < n; ++i) {
		b[i] = a[i];
	}
	myReverse(a, n);
	for (int i = 0; i < n; ++i) {
		if (a[i] != b[i]) {
			return 0;
		}
	}
	return 1;
}

//bai 3
int countNumber(char a[], int n, char b) {
	int count = 0;
	for (int i = 0; i < n; ++i) {
		if (a[i] == b) {
			++count;
		}
	}
	return count;
}

//bai 4
void mostFrequent(char a[],int n, char& b, int& time) {
	time = countNumber(a,n,a[0]);
	b = a[0];
	for (int i = 1; i < n; ++i) {
		if (countNumber(a, n, a[i]) > time) {
			time = countNumber(a, n, a[i]);
			b = a[i];
		}
	}
}

//bai 5
void insertChar(char a[], int &n, char b,int pos) {
	n = n + 1;
	for (int i = n - 1; i > pos - 2; --i) {
		a[i + 1] = a[i];
	}
	a[pos - 1] = b;
}

	
int main() {
	char a[100], tmp, temp[100], c,b,d;
	int n, time, pos, tmp1;
	cout << "Nhap so luong mang: ";
	cin >> n;
	input(a, n);
	
	// bai 1
	for (int i = 0; i < n; ++i) {
		temp[i] = a[i];
	}
	myReverse(temp, n);
	output(temp, n);
	cout << endl;

	// bai 2
	for (int i = 0; i < n; ++i) {
		temp[i] = a[i];
	}
	if (check(temp, n) == 1) {
		cout << "Chuoi doi xung" << endl;
	}
	else {
		cout << "Chuoi khong doi xung" << endl;
	}
	cout << endl;


	// bai 3
	cout << "Nhap ki tu c: ";
	cin >> c;
	cout << "So lan xuat hien cua ki tu c: " << countNumber(a, n, c) << endl;
	cout << endl;

	// bai 4
	mostFrequent(a, n, b, time);
	cout << "Ki tu xuat hien nhieu nhat: " << b << endl;
	cout << "So lan xuat hien: " << time << endl;
	cout << endl;

	// bai 5
	cout << "Vi tri chen ki tu: ";
	cin >> pos;
	cout << "Nhap ki tu muon chen: ";
	cin >> d;
	for (int i = 0; i < n; ++i) {
		temp[i] = a[i];
	}
	tmp1 = n;
	insertChar(temp, tmp1, d, pos);
	output(temp, tmp1);
	cout << endl;
	cout << endl;
	return 0;
}