#include<iostream>
#define MAX 100

using namespace std;

//bai 1
void set2dArray(int a[][MAX], int m, int n) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << "Nhap phan tu a[" << i << "][" << j << "]: ";
			cin >> a[i][j];
		}
	}
}

//bai 2
void print2dArray(int a[][MAX], int m, int n) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << a[i][j] << " ";
		}
		cout << endl;
	}
}

//bai 3
int sumArray(int a[][MAX], int m, int n) {
	int sum = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			sum += a[i][j];
		}
	}
	return sum;
}

//bai 4
int sumDiagonal(int a[][MAX], int m, int n) {
	int sum = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++){
			if (i == j) {
				sum += a[i][j];
			}
		}
	}
	return sum;
}

//bai 5
int findMin(int a[][MAX], int m, int n) {
	int min = a[0][0];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if (a[i][j] < min) {
				min = a[i][j];
			}
		}
	}
	return min;
}

//bai 6
bool checkPrime(int n) {
	if (n <= 1) {
		return false;
	}
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) {
			return false;
		}
	}
	return true;
}

int countNumberofPrime(int a[][MAX], int m, int n) {
	int count = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			count += checkPrime(a[i][j]);
		}
	}
	return count;
}

//bai 7
int countOccurrences(int a[][MAX], int m, int n, int x) {
	int count = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if (x == a[i][j]) {
				count++;
			}
		}
	}
	return count;
}

//bai 8
void deleteRow(int a[][MAX], int& m, int n, int index) {
	for (int i = index; i < m - 1; i++) {
		for (int j = 0; j < n; j++) {
			a[i][j] = a[i + 1][j];
		}
	}
	m--;
}

void deleteCol(int a[][MAX], int m, int& n, int index) {
	for (int j = index; j < n; j++) {
		for (int i = 0; i < m; i++) {
			a[i][j] = a[i][j + 1];
		}
	}
	n--;
}

void deleteItems(int a[][MAX], int& m, int& n, int x) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if (a[i][j] == x) {
				deleteRow(a, m, n, i);
				deleteCol(a, m, n, j);
				i--;
				break;
			}
		}
	}

}

int main() {
	int m, n, x;
	int a[MAX][MAX];
	cout << "Nhap dong: ";
	cin >> m;
	cout << "Nhap cot: ";
	cin >> n;
	//bai 1
	cout << "\nNhap mang: " << endl;
	set2dArray(a, m, n);

	//bai 2
	cout << "\nXuat mang: " << endl;
	print2dArray(a, m, n);
	cout << endl;

	//bai 3
	cout << "\nTong cua cac phan tu trong mang: " << sumArray(a, m, n);
	cout << endl;

	//bai 4
	cout << "\nTong cac duong cheo chinh: " << sumDiagonal(a, m, n);
	cout << endl;

	//bai 5
	cout << "\nSo nho nhat cua mang: " << findMin(a, m, n);
	cout << endl;

	//bai 6
	cout << "\nSo luong so nguyen to co trong mang: " << countNumberofPrime(a, m, n);
	cout << endl;

	//bai 7
	cout << "\nNhap x: ";
	cin >> x;
	cout << "\nSo lan xuat hien cua gia tri x: " << countOccurrences(a, m, n, x) << endl;;

	//bai 8
	cout << "\nMang sau khi da xoa cac dong va cot chua gia tr x: " << endl;
	deleteItems(a, m, n, x);
	print2dArray(a, m, n);
	cout << endl;
	return 0;
}