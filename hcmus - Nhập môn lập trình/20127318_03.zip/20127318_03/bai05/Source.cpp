#include<iostream>

using namespace std;

bool ngto(int n) {
	int count = 0;
	for (int i = 1; i <= n; ++i) {
		if (n % i == 0) ++count;
	}
	if (count == 2) return true;
	else return false;
}

int main() {
	int n;
	cout << "Nhap n (0 < n < 50): ";
	cin >> n;
	if (n == 1 or n == 2) {
		cout << "Khong ton tai so nguyen to nho hon n";
		return 0;
	}
	--n;
	while (ngto(n) != 1) {
		--n;
	}
	cout << "So nguyen to lon nhat nho hon n la: " << n;
	return 0;
}