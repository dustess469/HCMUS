#include<iostream>

using namespace std;

int main() {
	int sum = 0, n, a[1005], i1 = 0, count = 0;
	cout << "Nhap so nguyen duong: ";
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		if (n % i == 0) {
			++count;
			a[i1] = i;
			sum += i;
			++i1;
		}
	}
	cout << "Cac uoc so cua n la: ";
	for (int i = 0; i < count; ++i) {
		cout << a[i] << " ";
	}
	cout << endl;
	cout << "So uoc so la: " << count << endl;
	cout << "Tong cac uoc so la: " << sum << endl;
	return 0;
}
