#include<iostream>

using namespace std;

int main() {
	int phut, giay;
	cout << "Nhap vao so phut: ";
	cin >> phut;
	cout << "Nhap vao so giay: ";
	cin >> giay;
	cout << endl;
	for (int i = phut; i >= 0; --i) {
		for (int j = 59; j >= 0; --j) {
			if (giay >= 01 && giay <= 05) {
				cout << giay << " Tich tac\n";
			}
			else if (giay == 00) {
				cout << giay << " Tich tac\n";
			}
		}
	}
	cout << phut << ":" << giay << endl;	
	return 0;
}
//Ham sleep
//setfill