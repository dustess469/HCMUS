#include<iostream>

using namespace std;

int main() {
	double n;
	double sum = 1;
	cout << "Nhap n: ";
	cin >> n;
	if (n <= 1) {
		cout << "n khong hop le\n";
		return 0;
	}
	for (double i = 2; i <= n; i++) {
		sum = sum + i / (i - 1);
	}
	cout << "Tong: " << sum;
	return 0;
}