#include<iostream>

using namespace std;

int main() {
	int n;
	int giaiThua = 1;
	int sum = 0;

	cout << "Nhap n: ";
	cin >> n;
	for (int i = 1; i <= n; i++) {
		if (n == 0)
			return 1;
		else
			giaiThua *= i;
		sum += giaiThua;
	}
	cout << "Ket qua: " << sum << endl;
	return 0;
}