#include<iostream>

using namespace std;

int main() {
	int n, fibo1 = 1, fibo2 = 1, count;
	cout << "Nhap n: ";
	cin >> n;
	if (n < 0) 
		cout << "n khong hop le" << endl;
	if (n == 0) 
		cout << "Fibo(" << n << ") = 1" << endl;
	if (n == 1 or n == 2) 
		cout << "Fibo(" << n << ") = 1" << endl;
	for (int i = 3; i <= n; ++i) {
		int tmp = fibo1 + fibo2;
		fibo1 = fibo2;
		fibo2 = tmp;
		count = i;
	}
	cout << "Fibo(" << count << ") = " << fibo2;
	return 0;
}