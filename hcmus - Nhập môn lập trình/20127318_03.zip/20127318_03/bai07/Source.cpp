#include<iostream>

using namespace std;

int main() {
	int a[105];
	int n;
	cout << "Nhap n: ";
	cin >> n;
	int cnt = 0;
	for (int i = 1; i <= 4; ++i) {
		a[++cnt] = n % 2;
		n /= 2;
	}
	for (int i = cnt; i >= 1; --i) {
		cout << a[i];
	}
	cout << endl;
	return 0;
}