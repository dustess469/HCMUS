#include<iostream>

using namespace std;

int main() {
	int so;
	int count1 = 0;
	int count2 = 0;
	cout << "Nhap so nguyen duong: ";
	cin >> so;
	cout << "So nguoc lai la: ";
	for (; so != 0; so = so / 10) {
		if (so % 2 != 0) {
			count1++;
		}
		else
			count2++;
		cout << so % 10;
	}
	cout << endl;
	cout << "So luong so le = " << count1 << endl;
	cout << "So luong so chan = " << count2 << endl;
	cout << endl;
	return 0;
}