#include <iostream>

using namespace std;

int main() {
	int danA, danB;
	double s1, s2;

	cout << "Nhap dan so thanh pho A: ";
	cin >> danA;
	cout << "Nhap dan so thanh pho B: ";
	cin >> danB;
	cout << "Nhap muc do tang tang truong thanh pho A: ";
	cin >> s1;
	cout << "Nhap muc do tang tang truong thanh pho B: ";
	cin >> s2;

	if (danA >= danB) {
		cout << "Du lieu sai";
	}
	if (s1 <= s2) {
		cout << "Du lieu sai";
	}
	for (int i = 1; danA <= danB; ++i) {
		danA = danA * (1 + (s1 / 100));
		danA = danB * (1 + (s2 / 100));
		if (danA > danB) {
			cout << "So nam de dan so thanh pho A vuot qua thanh pho B la: " << i;
			break;
		}
	}
	return 0;
}