#include<iostream>

using namespace std;

int main() {
	int x;
	int count = 0;
	cout << "x = ";
	cin >> x;
	while (x > 1) {
		if (x % 2 != 0) {
			x = 3 * x + 1;
			cout << x << " ";
			count++;
		}
		else {
			x = x / 2;
			cout << x << " ";
			count++;
		}
	}
	cout << "k = " << count << endl;
	return 0;
}