#include<iostream>

using namespace std;

int main() {
	int ga, cho;
	for(ga = 1; ga <36; ga++)
		for(cho = 1; cho < 36; cho++)
			if ((ga + cho == 36) && ((ga * 2) + (cho * 4) == 100)) {
				cout << "Con ga = " << ga << endl;
				cout << "Con cho = " << cho << endl;
			}
	return 0;
}