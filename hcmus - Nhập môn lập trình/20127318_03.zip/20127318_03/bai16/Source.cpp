#include<iostream>

using namespace std;

int main() {
	while (true) {
		int n, a, b;
		cout << "MAY TINH DON GIAN\n";
		cout << "1. Cong\n";
		cout << "2. Tru\n";
		cout << "3. Nhan\n";
		cout << "4. Chia\n";
		cout << "0. Dung chuong trinh\n";
		cout << endl;
		cout << "Lua chon cua ban la: ";
		cin >> n;
		cout << endl;
		if (n == 1) {
			cout << "Moi nhap so thu nhat: ";
			cin >> a;
			cout << "Moi nhap so thu hai: ";
			cin >> b;
			cout << "Ket qua: " << a << " + " << b << " = " << a + b << endl;
			cout << "-------------------------\n";
		}
		else if (n == 2) {
			cout << "Moi nhap so thu nhat: ";
			cin >> a;
			cout << "Moi nhap so thu hai: ";
			cin >> b;
			cout << "Ket qua: " << a << " - " << b << " = " << a - b << endl;
			cout << "-------------------------\n";
		}
		else if (n == 3) {
			cout << "Moi nhap so thu nhat: ";
			cin >> a;
			cout << "Moi nhap so thu hai: ";
			cin >> b;
			cout << "Ket qua: " << a << " * " << b << " = " << a * b << endl;
			cout << "-------------------------\n";
		}
		else if (n == 4) {
			cout << "Moi nhap so thu nhat: ";
			cin >> a;
			cout << "Moi nhap so thu hai: ";
			cin >> b;
			if (b == 0) {
				cout << "Ket qua: Khong co gia tri hop le\n";
			}
			else
				cout << "Ket qua: " << a << " + " << b << " = " << a + b << endl;
			cout << "-------------------------\n";
		}
		else if (n == 0) {
			cout << "Dung chuong trinh\n";
			break;
		}
	}
	return 0;
}