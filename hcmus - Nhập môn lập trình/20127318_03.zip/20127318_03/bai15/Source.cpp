#include<iostream>

using namespace std;

int main() {
	double a[1005], min, max;
	int count = 0;
	int i = 0;
	while (a[i - 1] != 0) {
		cout << "Nhap chieu cao: ";
		cin >> a[i];
		++i;
		++count;
	}
	min = a[0];
	max = a[0];
	for (int i = 0; i < count - 1; ++i) {
		if (a[i] > max) max = a[i];
		if (a[i] < min) min = a[i];
	}
	cout << "Chieu cao cua hoc sinh dung dau danh sach: " << min << " m" << endl;
	cout << "Chieu cao cua hoc sinh dung cuoi danh sach: " << max << " m" <<  endl;
	return 0;
}