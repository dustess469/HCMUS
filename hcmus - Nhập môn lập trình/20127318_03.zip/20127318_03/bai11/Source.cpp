#include<iostream>

using namespace std;

int main() {
	int n, tien = 1;
	cout << "Nhap ngay: ";
	cin >> n;
	int sum = 0;
	if (n <= 0) {
		cout << "Nhap sai. Moi nhap lai\n";
	}
	else {
		cout << "Tien ngay 1 = 1 dong" << endl;
		for (int i = 2; i <= n; ++i) {
			tien = tien * 2;
			sum += tien;
			cout << "Tien ngay " << i << " = " << tien << " dong" << endl;
		}
	}
	cout << "Tong luong nhan sau " << n << " ngay = " << sum << " dong" << endl;
	return 0;
}