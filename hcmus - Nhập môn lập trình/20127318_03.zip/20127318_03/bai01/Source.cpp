#include<iostream>

using namespace std;

int main() {
	int n;
	int sum = 0;
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++) {
		if (i % 4 == 0 && i % 5 != 0) {
			sum += i;
		}
	}
	/*C2:for (int i = 4; i < n; i+=4) {
		if (i % 5 != 0) {
			sum += i;
		}
	}
	*/
	cout << "Tong: " << sum << endl;
	return 0;
}