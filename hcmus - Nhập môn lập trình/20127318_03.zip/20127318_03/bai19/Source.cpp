#include<iostream>

using namespace std;

int main() {
	char a[300];
	for (int i = 65; i <= 122; i++) {
		if ((i >= 65 && i <= 90) || (i >= 97 && i <= 122)){
		cout << i << "\t" << (char)i << endl;
		}
	}
	return 0;
}