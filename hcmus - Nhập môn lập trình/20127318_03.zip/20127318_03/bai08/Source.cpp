#include<iostream>

using namespace std;

int main() {
	int n, tich;
	cout << "Bang cuu chuong: ";
	cin >> n;
	for (int i = 1; i <= 10; ++i) {
		tich = n * i;
		cout << n << " x " << i << " = " << tich << endl;
	}
	return 0;
}