#include<iostream>

using namespace std;

int euclid(int a, int b) {
	int temp;
	while (b != 0) {
		temp = a % b;
		a = b;
		b = temp;
	}
	return a;
}

void Extended_Euclid(int a, int b, int& x, int& y) {
	bool status = false;
	int temp;
	if (euclid(a, b) == a) {
		x = 1;
		y = 0;
		return;
	}
	if (euclid(a, b) == b) {
		x = 0;
		y = 1;
		return;
	}
	if (b > a) {
		temp = a;
		a = b;
		b = temp;
		status = true;
	}
	int tmp = a, ri = b, qi, yi, xi, xi_2 = 0, xi_1 = 1, yi_2 = 1, yi_1 = 0;
	while (tmp % ri != 0) {
		qi = tmp / ri;
		temp = tmp % ri;
		tmp = ri;
		ri = temp;
		xi = xi_2 - qi * xi_1;
		xi_2 = xi_1;
		xi_1 = xi;
		yi = yi_2 - qi * yi_1;
		yi_2 = yi_1;
		yi_1 = yi;
	}
	if (status == false) {
		int temp1 = xi;
		xi = yi;
		yi = temp1;
	}
	x = xi;
	y = yi;
}

int bsc(int a, int b) {
	bool status = false;
	int temp;
	if (a < b) {
		status = true;
		temp = a;
		a = b;
		b = temp;
	}
	for (int i = a; i <= a * b; ++i) {
		if (i % a == 0 and i % b == 0) {
			return i;
			break;
		}
	}
}


int main() {
	int x, y;
	int a, b;
	cout << "Nhap 2 so a,b: ";
	cin >> a >> b;
	cout << "UCLN la: " << euclid(a, b) << endl;;
	Extended_Euclid(a, b, x, y);
	cout << "x = " << x << endl;
	cout << "y = " << y;
	return 0;
}