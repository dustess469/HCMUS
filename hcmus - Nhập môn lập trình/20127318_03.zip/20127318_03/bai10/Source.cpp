#include<iostream>

using namespace std;

int main() {
	int n;
	cout << "Nhap so phut = ";
	cin >> n;
	for (double i = 3.6; i <= n; i++) {
		if (n == 5) {
			cout << "So luong calo trong 5 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 10) {
			cout << "So luong calo trong 10 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 15) {
			cout << "So luong calo trong 15 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 20) {
			cout << "So luong calo trong 20 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 25) {
			cout << "So luong calo trong 25 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 30) {
			cout << "So luong calo trong 30 phut = " << n * i << " calo" << endl;
			break;
		}
		else
			cout << "So luong calo trong " << n << " phut = " << n * i << " calo" << endl;
		break;
	}
	return 0;
}