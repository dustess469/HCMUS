#ifndef lab2
#define lab2

#include<iostream>

using namespace std;

//bai1
//void time(int gio, int phut, int giay);

//bai2
//void tong(float toan, float ly, float hoa);

//bai3
//void soChinhphuong(int n);

//bai4
//void kiemTra(int n);

//bai5
//void time(int thang, int nam);

//bai6
//void print(int n);

//bai7
//void maxAndmin(int a, int b, int c);

//bai8
//void tamGiac(int a, int b, int c);

//bai9
//void taxi(int km);

//bai10
//void tinhTien(int soCu, int soMoi);

//bai11
//void phat(int tocDo);

//bai12
//void epKieu(int n);

//bai13
//void tamGiacvuong(int a, int b, int c);

//bai14
//void ptBac2(float a, float b, float c);

//bai15
//void phepTinh(float a, float b, char toanTu);

//bai16
//void nganHang(char account, double min, double money);

//bai17
//void canNang(string a);

//bai18
//void tinhTrang(double w, double h);
#endif // !lab2
