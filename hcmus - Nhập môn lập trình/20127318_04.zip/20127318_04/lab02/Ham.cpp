#include"Ham.h"

//bai1
/*
void time(int gio, int phut, int giay) {
	if ((gio >= 0 && gio <= 23) && (phut >= 0 && phut <= 59) && (giay >= 0 && giay <= 59)) {
		cout << "Thoi gian hop le\n";
	}
	else {
		cout << "Thoi gian khong hop le\n";
	}
}
*/

//bai2
/*
void tong(float toan, float ly, float hoa) {
	float tong = toan + ly + hoa;
	if ((tong >= 15) && (toan >= 4) && (ly >= 4) && (hoa >= 4)) {
		cout << "Dau\n";
		if ((toan > 5) && (ly > 5) && (hoa > 5))
			cout << "Hoc deu cac mon\n";
		else if ((toan < 5) || (ly < 5) || (hoa < 5))
			cout << "Hoc chua deu cac mon\n";
	}
	else
		cout << "Thi hong\n";
}
*/


//bai3
/*
void soChinhphuong(int n) {
	if (n > 0) {
		int x = sqrt(n);
		if (x * x == n) {
			cout << n << " la so chinh phuong\n";
		}
		else {
			cout << n << " khong la so chinh phuong\n";
		}
	}
	else {
		cout << "Nhap sai. Moi nhap lai\n";
	}
}
*/

//bai4
/*
void kiemTra(int n) {
	if (n == 0) {
		cout << "Nhap sai. Moi nhap lai\n";
	}
	else
		if (n % 2 == 0) {
			cout << "So chan\n";
		}
		else
			cout << "So le\n";
}
*/

//bai5
/*
void time(int thang, int nam) {
	bool namNhuan = false;
	if ((nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0)) {
		namNhuan = true;
		cout << "Nam " << nam << " la nam nhuan\n";
	}
	else
		cout << "Nam " << nam << " khong la nam nhuan\n";

	switch (thang) {
	case 1: case 3: case 5:case 7: case 8:case 10: case 12:
		cout << "Thang " << thang << " co 31 ngay\n";
		break;
	case 4:case 6: case 9: case 11:
		cout << "Thang " << thang << " co 30 ngay\n";
		break;
	case 2:
		if (namNhuan == true)
			cout << "Thang " << thang << " co 29 ngay\n";
		else
			cout << "Thang " << thang << " co 28 ngay\n";
		break;
	default:
		cout << "Nhap sai! Moi nhap lai";
		break;
	}
}
*/

//bai6
/*
void print(int n) {
	switch (n) {
	case 0:
		cout << "Khong\n";
		break;
	case 1:
		cout << "Mot\n";
		break;
	case 2:
		cout << "Hai\n";
		break;
	case 3:
		cout << "Ba\n";
		break;
	case 4:
		cout << "Bon\n";
		break;
	case 5:
		cout << "Nam\n";
		break;
	case 6:
		cout << "Sau\n";
		break;
	case 7:
		cout << "Bay\n";
		break;
	case 8:
		cout << "Tam\n";
		break;
	case 9:
		cout << "Chin\n";
		break;
	default:
		cout << "n khong dung\n";
		break;
	}
}
*/

//bai7
/*
void maxAndmin(int a, int b, int c) {
	int max = a;
	int min = b;

	//Max
	if (b > a)
		max = b;
	if (c > a)
		max = c;

	//Min
	if (a < b)
		min = a;
	if (c < b)
		min = c;

	cout << "So lon nhat: " << max << endl;
	cout << "So nho nhat: " << min << endl;
}
*/

//bai8
/*
void tamGiac(int a, int b, int c) {
	if ((a + b > c) && (a + c > b) && (b + c > a)) {
		cout << "3 canh tren lap thanh mot tam giac\n";
		if (a == b || a == c || b == c)
			cout << "Tam giac tren la tam giac can\n";
		else if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
			cout << "Tam giac tren la tam giac vuong\n";
		else if (a == b && b == c && a == c)
			cout << "Tam giac tren la tam giac deu\n";
		else
			cout << "Tam giac tren la tam giac thuong\n";
	}
	else cout << "3 canh tren khong lap thanh mot tam giac\n";
}
*/

//bai9
/*
void taxi(int km) {
	int tongTien;
	if (km == 1)
		tongTien = 15000;
	else if (km >= 2 && km <= 5)
		tongTien = (13500 * (km - 1)) + 15000;
	else if (km >= 6)
		tongTien = (11000 * (km - 5)) + (13500 * (km - 1)) + 15000;
	if (km > 120)
		tongTien = ((11000 * (km - 5)) + (13500 * (km - 1)) + 15000) * 0.1;

	cout << "Tien di taxi: " << tongTien << "d\n";
}
*/

//bai10
/*
void tinhTien(int soCu, int soMoi) {
	int tienTra;
	int tieuThu = soMoi - soCu;
	if (tieuThu <= 100)
		tienTra = tieuThu * 1000;
	else if (tieuThu >= 101 && tieuThu <= 150)
		tienTra = 100 * 1000 + (tieuThu - 100) * 1200;
	else if (tieuThu >= 151 && tieuThu <= 200)
		tienTra = 100 * 1000 + 50 * 1200 + (tieuThu - 150) * 2000;
	else
		tienTra = 100 * 1000 + 50 * 1200 + 50 * 2000 + (tieuThu - 200) * 2500;
	cout << "So tien phai tra: " << tienTra << endl;
}
*/

//bai11
/*
void phat(int tocDo) {
	double mucPhat;
	if (tocDo <= 5) {
		cout << "Khong bi phat" << endl;
	}
	else {
		if (tocDo > 5 && tocDo <= 10) {
			mucPhat = 0.7;
		}
		else if (tocDo > 10 && tocDo <= 20) {
			mucPhat = 2.5;
		}
		else if (tocDo > 20 && tocDo <= 35) {
			mucPhat = 5.5;
		}
		else {
			mucPhat = 7.5;
		}
		cout << "So tien phat: " << mucPhat << " trieu" << endl;
	}
}
*/

//bai12
/*
void epKieu(int n) {
	if (n <= 9)
		cout << static_cast<char>(n + 48) << endl;
	else
		cout << static_cast<char>(n + 55) << endl;
}
*/

//bai13
/*
void tamGiacvuong(int a, int b, int c) {
	if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
		cout << "3 so tren la 3 canh cua tam giac vuong\n";
	else
		cout << "3 so tren khong la 3 canh cua tam giac vuong\n";
}
*/

//bai14
/*
void ptBac2(float a, float b, float c) {
	if (a == 0) {
		if (b == 0) {
			if (c == 0) {
				cout << "Phuong trinh co vo so nghiem\n";
			}
			else
				cout << "Phuong trinh vo nghiem\n";
		}
		else
			cout << "Phuong trinh co mot nghiem: " << -c / b << endl;
	}
	else {
		float delta = (b * b) - (4 * a * c);
		if (delta > 0) {
			float x = (-b + sqrt(delta)) / (2 * a);
			float y = (-b - sqrt(delta)) / (2 * a);
			cout << "Nghiem thu nhat: " << x << endl;
			cout << "Nghiem thu hai: " << y << endl;
		}
		else if (delta == 0)
			cout << "Phuong trinh co nghiem kep: x = y = " << -b / (2 * a) << endl;
		else
			cout << "Phuong trinh vo nghiem\n";
	}
}
*/

//bai15
/*
void phepTinh(float a, float b, char toanTu) {
	switch (toanTu)
	{
	case'+':
		cout << "Tong: " << a + b << endl;
		break;
	case'-':
		cout << "Hieu: " << a - b << endl;
		break;
	case'*':
		cout << "Tich: " << a * b << endl;
		break;
	case'/':
		if (b == 0)
			cout << "Gia tri khong hop le\n";
		else
			cout << "Thuong: " << a / b << endl;
		break;
	default:
		cout << "Nhap sai\n";
		break;
	}
}
*/


//bai16
/*
void nganHang(char account, double min, double money) {
	if (account == 't') {
		if (min > money)
			cout << "So tien phat: $10\n";
		else
			cout << "So tien lai: " << money * 0.04 << endl;
	}
	else {
		if (min > money)
			cout << "So tien phat: $25\n";
		else {
			if (money - min >= 50000) {
				cout << "So tien lai: " << money * 0.03 << endl;
			}
			else {
				cout << "So tien lai: " << money * 0.05 << endl;
			}
		}
	}
}
*/

//bai17
/*
void canNang(string a) {
	if (a == "nu") {
		double a1, a2, a3, a4, a5;
		double b, mo, phantram;
		cout << "Nhap can nang: ";
		cin >> a1;
		cout << "Nhap kich thuoc co tay: ";
		cin >> a2;
		cout << "Nhap kich thuoc eo: ";
		cin >> a3;
		cout << "Nhap kich thuoc hong: ";
		cin >> a4;
		cout << "Nhap kich thuoc canh tay: ";
		cin >> a5;

		b = (a1 * 0.732) + 8.987 + a2 / 3.14 - a3 * 0.157 - a4 * 0.249 + a5 * 0.434;
		mo = a1 - b;
		phantram = mo * 100 / a1;

		cout << "Luong mo: " << mo << endl;
		cout << "Phan tram luong mo: " << phantram << endl;
	}
	else if (a == "nam") {
		double a1, a2;

		cout << "Nhap can nang: ";
		cin >> a1;
		cout << "Nhap kich thuoc co tay: ";
		cin >> a2;

		double b = a1 * 1.082 + 9.442 - a2 * 4.15;
		double mo = a1 - b;
		double phantram = mo * 100 / a1;

		cout << "Luong mo: " << mo << endl;
		cout << "Phan tram luong mo: " << phantram << endl;
	}
}
*/

//bai18
/*
void tinhTrang(double w, double h) {
	double BMI = w / (h * h);

	if (BMI < 18.5)
		cout << "Duoi chuan\n";
	if (BMI >= 18.5 && BMI < 25)
		cout << "Chuan\n";
	if (BMI >= 25 && BMI < 30)
		cout << "Thua can\n";
	if (BMI >= 30 && BMI < 40)
		cout << "Beo - nen giam can\n";
	if (BMI >= 40)
		cout << "Rat beo - can giam can ngay\n";
}
*/