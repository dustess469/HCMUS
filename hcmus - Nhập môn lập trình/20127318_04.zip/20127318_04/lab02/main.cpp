#include"Ham.h"

//bai1
/*int main() {
	int gio, phut, giay;
	cout << "Nhap gio: ";
	cin >> gio;
	cout << "Nhap phut: ";
	cin >> phut;
	cout << "Nhap giay: ";
	cin >> giay;
	time(gio, phut, giay);
	return 0;
}*/

//bai2
/*int main() {
	float toan, ly, hoa;
	cout << "Nhap diem Toan: ";
	cin >> toan;
	cout << "Nhap diem Ly: ";
	cin >> ly;
	cout << "Nhap diem Hoa: ";
	cin >> hoa;
	
	tong(toan, ly, hoa);
	return 0;
}*/

//bai3
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	soChinhphuong(n);
	return 0;
}
*/

//bai4
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	kiemTra(n);
	return 0;
}
*/

//bai5
/*
int main() {
	int thang, nam;
	cout << "Nhap thang: ";
	cin >> thang;
	cout << "Nhap nam: ";
	cin >> nam;
	cout << endl;
	time(thang, nam);
	return 0;
}
*/

//bai6
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	print(n);
}
*/

//bai7
/*
int main() {
	int a, b, c;
	cout << "Nhap a,b,c: ";
	cin >> a >> b >> c;
	maxAndmin(a,b,c);
	return 0;
}
*/

//bai8
/*
int main() {
	int a, b, c;
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;
	tamGiac(a, b, c);
	return 0;
}
*/

//bai9
/*
int main() {
	int km;
	cout << "Nhap km: ";
	cin >> km;
	taxi(km);
	return 0;
}
*/

//bai10 chua hoan thanh
/*
int main() {
	int soCu, soMoi;
	cout << "Nhap chi so cu: ";
	cin >> soCu;
	cout << "Nhap chi so moi: ";
	cin >> soMoi;
	tinhTien(soCu, soMoi);
	return 0;
}
*/

//bai11
/*
int main() {
	int tocDo;
	cout << "Nhap toc do: ";
	cin >> tocDo;
	phat(tocDo);
	return 0;
}
*/

//bai12
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	epKieu(n);
	return 0;
}
*/

//bai13
/*
int main() {
	int a, b, c;
	cout << "Nhap 3 canh: ";
	cin >> a >> b >> c;
	tamGiacvuong(a, b, c);
	return 0;
}
*/

//bai14
/*
int main() {
	float a, b, c;
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap c: ";
	cin >> c;
	ptBac2(a, b, c);
	return 0;
}
*/

//bai15
/*
int main() {
	float a, b;
	char toanTu;
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
	cout << "Nhap toan tu: ";
	cin >> toanTu;
	phepTinh(a, b, toanTu);
	return 0;
}
*/

//bai16
/*
int main() {
	char account;
	double min, money;
	cout << "Nhap loai tai khoan" << endl;
	cout << "Nhap 't' neu la tai khoan tiet kiem" << endl;
	cout << "Nhap 'v' neu la tai khoan vang lai" << endl;
	cin >> account;
	cout << "Nhap so du toi thieu: ";
	cin >> min;
	cout << "Nhap so du cuoi thang: ";
	cin >> money;
	nganHang(account, min, money);
	return 0;
}
*/

//bai17
/*
int main() {
	string a;
	cout << "Nhap gioi tinh: ";
	cin >> a;
	canNang(a);
	return 0;
}
*/

//bai18
/*
int main() {
	double w, h;
	cout << "Nhap can nang: ";
	cin >> w;
	cout << "Nhap chieu cao: ";
	cin >> h;
	tinhTrang(w, h);
	return 0;
}
*/