#include"Ham.h"

//bai1
/*
void tinhTong(int n) {
	int sum = 0;
	for (int i = 0; i < n; i++) {
		if (i % 4 == 0 && i % 5 != 0) {
			sum += i;
		}
	}
	cout << "Tong: " << sum << endl;
}
*/

//bai2
/*
void tinhTong(int n) {
	double sum = 1;
	if (n <= 1) {
		cout << "n khong hop le\n";
	}
	for (double i = 2; i <= n; i++) {
		sum = sum + i / (i - 1);
	}
	cout << "Tong: " << sum;
}
*/

//bai3
/*
void tongGiaithua(int n) {
	int giaiThua = 1;
	int sum = 0;
	for (int i = 1; i <= n; i++) {
		if (n == 0) {
			cout << "Ket qua = 1";
			return;
		}
		else
			giaiThua *= i;
		sum += giaiThua;
	}
	cout << "Ket qua: " << sum << endl;
}
*/

//bai4
/*
void uocSo(int n) {
	int sum = 0, a[1005], i1 = 0, count = 0;
	for (int i = 1; i <= n; ++i) {
		if (n % i == 0) {
			++count;
			a[i1] = i;
			sum += i;
			++i1;
		}
	}
	cout << "Cac uoc so cua n la: ";
	for (int i = 0; i < count; ++i) {
		cout << a[i] << " ";
	}
	cout << endl;
	cout << "So uoc so la: " << count << endl;
	cout << "Tong cac uoc so la: " << sum << endl;
}
*/

//bai5
/*
bool ngto(int n) {
	int count = 0;
	for (int i = 1; i <= n; ++i) {
		if (n % i == 0) ++count;
	}
	if (count == 2) return true;
	else return false;
}
*/

//bai6
/*
int euclid(int a, int b) {
	int temp;
	while (b != 0) {
		temp = a % b;
		a = b;
		b = temp;
	}
	return a;
}

void Extended_Euclid(int a, int b, int& x, int& y) {
	bool status = false;
	int temp;
	if (euclid(a, b) == a) {
		x = 1;
		y = 0;
		return;
	}
	if (euclid(a, b) == b) {
		x = 0;
		y = 1;
		return;
	}
	if (b > a) {
		temp = a;
		a = b;
		b = temp;
		status = true;
	}
	int tmp = a, ri = b, qi, yi, xi, xi_2 = 0, xi_1 = 1, yi_2 = 1, yi_1 = 0;
	while (tmp % ri != 0) {
		qi = tmp / ri;
		temp = tmp % ri;
		tmp = ri;
		ri = temp;
		xi = xi_2 - qi * xi_1;
		xi_2 = xi_1;
		xi_1 = xi;
		yi = yi_2 - qi * yi_1;
		yi_2 = yi_1;
		yi_1 = yi;
	}
	if (status == false) {
		int temp1 = xi;
		xi = yi;
		yi = temp1;
	}
	x = xi;
	y = yi;
}

int bsc(int a, int b) {
	bool status = false;
	int temp;
	if (a < b) {
		status = true;
		temp = a;
		a = b;
		b = temp;
	}
	for (int i = a; i <= a * b; ++i) {
		if (i % a == 0 and i % b == 0) {
			return i;
			break;
		}
	}
}
*/

//bai7
/* 
void nhiPhan(int n) {
	int a[105];
	int cnt = 0;
	for (int i = 1; i <= 4; ++i) {
		a[++cnt] = n % 2;
		n /= 2;
	}
	for (int i = cnt; i >= 1; --i) {
		cout << a[i];
	}
	cout << endl;
}
*/

//bai8
/*
void bangCuuchuong(int n){
	int tich;
	for (int i = 1; i <= 10; ++i) {
		tich = n * i;
		cout << n << " x " << i << " = " << tich << endl;
	}
}
*/

//bai9
/*
void tamGiaccan(int n) {
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n - i; ++j)
			cout << " ";
		for (int j = 1; j <= 2 * i - 1; ++j)
			cout << "*";
		for (int j = 1; j <= n - i; ++j)
			cout << " ";
		cout << endl;
	}
}
*/

//bai10
/*
void luongCalo(int n) {
	for (double i = 3.6; i <= n; i++) {
		if (n == 5) {
			cout << "So luong calo trong 5 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 10) {
			cout << "So luong calo trong 10 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 15) {
			cout << "So luong calo trong 15 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 20) {
			cout << "So luong calo trong 20 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 25) {
			cout << "So luong calo trong 25 phut = " << n * i << " calo" << endl;
			break;
		}
		else if (n == 30) {
			cout << "So luong calo trong 30 phut = " << n * i << " calo" << endl;
			break;
		}
		else
			cout << "So luong calo trong " << n << " phut = " << n * i << " calo" << endl;
		break;
	}
}
*/

//bai11
/*
void tienLuong(int n) {
	int sum = 0;
	int tien = 1;
	if (n <= 0) {
		cout << "Nhap sai. Moi nhap lai\n";
	}
	else {
		cout << "Tien ngay 1 = 1 dong" << endl;
		for (int i = 2; i <= n; ++i) {
			tien = tien * 2;
			sum += tien;
			cout << "Tien ngay " << i << " = " << tien << " dong" << endl;
		}
	}
	cout << "Tong luong nhan sau " << n << " ngay = " << sum << " dong" << endl;
}
*/

//bai12
/*
void process(int ga, int cho) {
	for (ga = 1; ga < 36; ga++) {
		for (cho = 1; cho < 36; cho++) {
			if ((ga + cho == 36) && ((ga * 2) + (cho * 4) == 100)) {
				cout << "Con ga = " << ga << endl;
				cout << "Con cho = " << cho << endl;
			}
		}
	}
}
*/

//bai13
/*
void danSo(int danA, int danB, int s1, int s2) {
	if (danA >= danB) {
		cout << "Du lieu sai";
	}
	if (s1 <= s2) {
		cout << "Du lieu sai";
	}
	for (int i = 1; danA <= danB; ++i) {
		danA = danA * (1 + (s1 / 100));
		danA = danB * (1 + (s2 / 100));
		if (danA > danB) {
			cout << "So nam de dan so thanh pho A vuot qua thanh pho B la: " << i;
			break;
		}
	}
}
*/

//bai14
/*
void fibo(int n) {
	int fibo1 = 1, fibo2 = 1, count;
	if (n < 0)
		cout << "n khong hop le" << endl;
	if (n == 0)
		cout << "Fibo(" << n << ") = 1" << endl;
	if (n == 1 or n == 2)
		cout << "Fibo(" << n << ") = 1" << endl;
	for (int i = 3; i <= n; ++i) {
		int tmp = fibo1 + fibo2;
		fibo1 = fibo2;
		fibo2 = tmp;
		count = i;
	}
	cout << "Fibo(" << count << ") = " << fibo2 << endl;
}
*/

//bai15
/*
void chieuCao(int a[1005]) {
	double a[1005], min, max;
	int count = 0;
	min = a[0];
	max = a[0];
	for (int i = 0; i < count - 1; ++i) {
		if (a[i] > max) max = a[i];
		if (a[i] < min) min = a[i];
	}
	cout << "Chieu cao cua hoc sinh dung dau danh sach: " << min << " m" << endl;
	cout << "Chieu cao cua hoc sinh dung cuoi danh sach: " << max << " m" << endl;
}
*/
//bai16
/*
void mayTinh(int n) {
	int  a, b;
	if (n == 1) {
		cout << "Moi nhap so thu nhat: ";
		cin >> a;
		cout << "Moi nhap so thu hai: ";
		cin >> b;
		cout << "Ket qua: " << a << " + " << b << " = " << a + b << endl;
		cout << "-------------------------\n";
	}
	else if (n == 2) {
		cout << "Moi nhap so thu nhat: ";
		cin >> a;
		cout << "Moi nhap so thu hai: ";
		cin >> b;
		cout << "Ket qua: " << a << " - " << b << " = " << a - b << endl;
		cout << "-------------------------\n";
	}
	else if (n == 3) {
		cout << "Moi nhap so thu nhat: ";
		cin >> a;
		cout << "Moi nhap so thu hai: ";
		cin >> b;
		cout << "Ket qua: " << a << " * " << b << " = " << a * b << endl;
		cout << "-------------------------\n";
	}
	else if (n == 4) {
		cout << "Moi nhap so thu nhat: ";
		cin >> a;
		cout << "Moi nhap so thu hai: ";
		cin >> b;
		if (b == 0) {
			cout << "Ket qua: Khong co gia tri hop le\n";
		}
		else
			cout << "Ket qua: " << a << " + " << b << " = " << a + b << endl;
		cout << "-------------------------\n";
	}
	else if (n == 0) {
		cout << "Dung chuong trinh\n";
	}
}
*/

//bai17

//bai18
/*
void process(int &count,int x ) {
	while (x > 1) {
		if (x % 2 != 0) {
			x = 3 * x + 1;
			cout << x << " ";
			count++;
		}
		else {
			x = x / 2;
			cout << x << " ";
			count++;
		}
	}
}
*/

//bai19
/*
void process(char a[]) {
	for (int i = 65; i <= 122; i++) {
		if ((i >= 65 && i <= 90) || (i >= 97 && i <= 122)) {
			cout << i << "\t" << (char)i << endl;
		}
	}
}
*/

//bai20
/*
void process(int& count1, int& count2, int so) {
	for (; so != 0; so = so / 10) {
		if (so % 2 != 0) {
			count1++;
		}
		else
			count2++;
		cout << so % 10;
	}
}
*/