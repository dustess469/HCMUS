#ifndef lab3
#define lab 3

#include<iostream>

using namespace std;

//bai1
//void tinhTong(int n);

//bai2
//void tinhTong(int n);

//bai3
//void tongGiaithua(int n);

//bai4
//void uocSo(int n);

//bai5
//bool ngto(int n);

//bai6
//int euclid(int a, int b);
//void Extended_Euclid(int a, int b, int& x, int& y);
//int bsc(int a, int b);

//bai7
//void nhiPhan(int n);

//bai8
//void bangCuuchuong(int n);

//bai9
//void tamGiaccan(int n);

//bai10
//void luongCalo(int n);

//bai11
//void tienLuong(int n);

//bai12
//void process(int ga, int cho);

//bai13
//void danSo(int danA, int danB, int s1, int s2);

//bai14
//void fibo(int n);

//bai15
//void chieuCao(int a[1005]);

//bai16
//void mayTinh(int n);

//bai17

//bai18
//void process(int &count,int x );

//bai19
//void process(char a[]);

//bai20
//void process(int& count1, int& count2, int so);

#endif // !lab3
