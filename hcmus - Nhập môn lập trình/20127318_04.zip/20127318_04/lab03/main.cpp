#include"Ham.h"

//bai1
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	tinhTong(n);
	return 0;
}
*/

//bai2
/*
int main() {
	double n;
	cout << "Nhap n: ";
	cin >> n;
	tinhTong(n);
	return 0;
}
*/

//bai3
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	tongGiaithua(n);
	return 0;
}
*/

//bai4
/*
int main() {
	int n;
	cout << "Nhap so nguyen duong: ";
	cin >> n;
	uocSo(n);
	return 0;
}
*/

//bai5
/*
int main() {
	int n;
	cout << "Nhap n (0 < n < 50): ";
	cin >> n;
	if (n == 1 or n == 2) {
		cout << "Khong ton tai so nguyen to nho hon n";
		return 0;
	}
	--n;
	while (ngto(n) != 1) {
		--n;
	}
	cout << "So nguyen to lon nhat nho hon n la: " << n;
	return 0;
}
*/

//bai6
/*
int main() {
	int x, y;
	int a, b;
	cout << "Nhap 2 so a,b: ";
	cin >> a >> b;
	cout << "UCLN la: " << euclid(a, b) << endl;;
	Extended_Euclid(a, b, x, y);
	cout << "x = " << x << endl;
	cout << "y = " << y << endl;
	cout << "Boi so chung nho nhat: " << bsc(a, b);
	return 0;
}
*/

//bai7
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	nhiPhan(n);
	return 0;
}
*/

//bai8
/*
int main() {
	int n;
	cout << "Bang cuu chuong: ";
	cin >> n;
	bangCuuchuong(n);
	return 0;
}
*/

//bai9
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	tamGiaccan(n);
	return 0;
}
*/

//bai10
/*
int main() {
	int n;
	cout << "Nhap so phut = ";
	cin >> n;
	luongCalo(n);
	return 0;
}
*/

//bai11
/*
int main() {
	int n;
	cout << "Nhap ngay: ";
	cin >> n;
	tienLuong(n);
	return 0;
}
*/

//bai12
/*
int main() {
	int ga = 1, cho = 1;
	process(ga, cho);
	return 0;
}
*/

//bai13
/*
int main() {
	int danA, danB;
	double s1, s2;
	cout << "Nhap dan so thanh pho A: ";
	cin >> danA;
	cout << "Nhap dan so thanh pho B: ";
	cin >> danB;
	cout << "Nhap muc do tang tang truong thanh pho A: ";
	cin >> s1;
	cout << "Nhap muc do tang tang truong thanh pho B: ";
	cin >> s2;
	danSo(danA, danB, s1, s2);
	return 0;
}
*/

//bai14
/*
int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	fibo(n);
	return 0;
}
*/

//bai15
/*
int main() {
	int i = 0;
	double a[1005];
	int count = 0;
	while (a[i - 1] != 0) {
		cout << "Nhap chieu cao: ";
		cin >> a[i];
		++i;
		++count;
	}
	chieuCao(a[1005]);
	return 0;
}
*/
	
//bai16
/*
int main() {
	while (true) {
		int n;
		cout << "MAY TINH DON GIAN\n";
		cout << "1. Cong\n";
		cout << "2. Tru\n";
		cout << "3. Nhan\n";
		cout << "4. Chia\n";
		cout << "0. Dung chuong trinh\n";
		cout << endl;
		cout << "Lua chon cua ban la: ";
		cin >> n;
		cout << endl;
		mayTinh(n);
	}
	return 0;
}
*/

//bai17

//bai18
/*
int main() {
	int x;
	int count = 0;
	cout << "x = ";
	cin >> x;
	process(count, x);
	cout << "k = " << count << endl;
	return 0;
}
*/

//bai19
/*
int main() {
	char a[300];
	process(a);
	return 0;
}
*/

//bai20
/*
int main() {
	int so;
	int count1 = 0;
	int count2 = 0;
	cout << "Nhap so nguyen duong: ";
	cin >> so;
	cout << "So nguoc lai la: ";
	process(count1, count2, so);
	cout << endl;
	cout << "So luong so le = " << count1 << endl;
	cout << "So luong so chan = " << count2 << endl;
	cout << endl;
	return 0;
}
*/