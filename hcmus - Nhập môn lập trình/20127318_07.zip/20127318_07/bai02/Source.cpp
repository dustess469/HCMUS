#include<iostream>
#include<string.h>

using namespace std;

// bai 1
void reverseCharArray(char* s) {
	int n = strlen(s);
	for (int i = 0; i < n / 2; i++) {
		int tmp = s[i];
		s[i] = s[n - 1 - i];
		s[n - 1 - i] = tmp;
	}
}

// bai 2
int checkSymmetricArray(char* s) {
	int n = strlen(s);
	for (int i = 0; i < n / 2; i++) {
		if (s[i] != s[n - 1 - i]) {
			return 0;
		}
	}
	return 1;
}

// bai 3
int countOccurrencesChar(char* s, char c) {
	int dem = 0;
	for (int i = 0; s[i] != '\0'; i++) {
		if (s[i] == c) {
			dem++;
		}
	}
	return dem;
}

//bai 4
void  findMostFrequentChar(char* s, char& chr, int& mostAppear) {
	mostAppear = countOccurrencesChar(s, s[0]);
	chr = s[0];
	for (int i = 0; i < strlen(s); ++i) {
		if (countOccurrencesChar(s, s[i]) > mostAppear) {
			mostAppear = countOccurrencesChar(s, s[i]);
			chr = s[i];
		}
	}
}

//bai 5 
void insertCharAtPosition(char* s, char chr, int pos) {
	int n = strlen(s);
	n++;
	for (int i = n - 1; i > pos; i--) {
		s[i] = s[i - 1];
	}
	s[pos] = chr;
	s[n] = '\0';
}

// bai 6
void formatNumberWithCommas(char* s) {
	reverseCharArray(s);
	if (strlen(s) > 6) {
		for (int i = strlen(s); i != 2; --i) {
			s[i + 1] = s[i];
		}
		s[3] = ',';
		for (int i = strlen(s); i != 5; --i) {
			s[i + 1] = s[i];
		}
		s[7] = ',';
	}
	else if (strlen(s) >= 4 and strlen(s) < 7) {
		for (int i = strlen(s); i != 2; --i) {
			s[i + 1] = s[i];
		}
		s[3] = ',';
	}
	reverseCharArray(s);
}


int main() {
	char s[100], chr, chr1;
	int mostAppear, pos;

	cout << "Nhap chuoi: ";
	cin.getline(s, 100);


	//bai 1
	cout << "\nChuoi theo thu tu nguoc: ";
	reverseCharArray(s);
	cout << s << endl;
	reverseCharArray(s);

	//bai 2
	cout << "\nKiem tra chuoi doi xung: " << checkSymmetricArray(s) << endl;

	//bai 3 
	cout << "\nSo lan xuat hien cua ki tu c: " << countOccurrencesChar(s, 'c') << endl;

	////bai 4
	findMostFrequentChar(s, chr, mostAppear);
	cout << "\nKi tu xuat hien nhieu nhat: " << chr << endl;
	cout << "So lan xuat hien: " << mostAppear << endl;

	//bai 5
	cout << "\nKi tu muon chen: ";
	cin >> chr1;
	cout << "Vi tri muon chen: ";
	cin >> pos;
	insertCharAtPosition(s, chr1, pos);
	cout << s << endl;

	//bai 6
	cout << "\nNhap chuoi so nguyen: ";
	cin.getline(s, 100);
	cin.getline(s, 100);
	formatNumberWithCommas(s);
	cout << s;

	return 0;
}