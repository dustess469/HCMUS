#UserData and or scripts should be stored here, but only for source code revision purposes cf templatess should refer to prod s3bucket allways
