import Navbar from './Components/navbar'
import Header from './Components/header'
import './App.css'
export default function App() {
    return (
        <>
            < Navbar />
            <Header/>
        </>
    )
}