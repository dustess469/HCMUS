export default function Navbar() {
    return (
        //Navbar
        <>
            <nar className="navbar navbar-expand-sm bg-dark navbar-dark">
                <a href="" className="navbar-brand"><span>E</span>asy Gym</a>
                <div>
                    <ul className="navbar-nav">
                        <li className="nav-item"><a href="" className="nav-link">Home</a></li>
                        <li className="nav-item"><a href="" className="nav-link">About</a></li>
                        <li className="nav-item"><a href="" className="nav-link">Service</a></li>
                        <li className="nav-item"><a href="" className="nav-link">Contanct</a></li>
                        <li className="nav-item"><a href="" className="nav-link">Gym</a></li>
                    </ul>
                </div>
            </nar>
        </>
    )
}