export default function Header() {
    return (
        //Header
        <>
            <h1>Header here</h1>
        </>
    )
}