#include "staff.h"

void NhanVien::input()
{

}

void NhanVien::output()
{
	cout << "Name: " << name << endl;
	cout << "Work day: " << days << endl;
	cout << "EmployeeID: " << calID() << endl;
	cout << "Title: " << calTitle(days) << endl;
	cout << "Salary: " << calSalary(title) << endl;
}

// getter & setter
string NhanVien::getName()
{
	return name;
}

void NhanVien::setName(string name)
{
	this->name = name;
}

int NhanVien::getDays()
{
	return days;
}

void NhanVien::setDay(int workDay)
{
	this->days = workDay;
}

string NhanVien::getTitle()
{
	return title;
}

void NhanVien::setTitle(string title)
{
	this->title = title;
}

string NhanVien::getID()
{
	return ID;
}

void NhanVien::setID(string EmployeeID)
{
	this->ID = EmployeeID;
}

double NhanVien::getSalary()
{
	return salary;
}

void NhanVien::setSalary(double coSalary)
{
	this->salary = coSalary;
}