#include "staff.h"

int main()
{
	NhanVien noone;

	cout << "Name: " << noone.getName() << endl;
	cout << "Work day: " << noone.getDays() << endl;
	cout << "EmployeeID: " << noone.getID() << endl;
	cout << "Title: " << noone.getTitle() << endl;
	cout << "Salary: " << noone.getSalary() << endl;

	cout << "-------------------------------\n";
	NhanVien nv1("Tai", 318, "", "Quan ly", 4);

	cout << "Name: " << nv1.getName() << endl;
	cout << "Work day: " << nv1.getDays() << endl;
	cout << "EmployeeID: " << nv1.getID() << endl;
	cout << "Title: " << nv1.getTitle() << endl;
	cout << "Salary: " << nv1.getSalary() << endl;

	cout << "-------------------------------\n";

	NhanVien nv2(nv1);
	nv2.setDay(999);
	nv2.output();

	cout << "-------------------------------\n";
	nv2.setName("Bao");
	nv2.setDay(18);
	nv2.output();

	cout << "-------------------------------\n";
	nv2.setName("Anh");
	nv2.setDay(3);
	nv2.setID("3Dang");
	nv2.setTitle("Nhan vien");

	nv2.setSalary(1.0);
	nv2.output();

	return 0;
}