#ifndef _STAFF_H_
#define _STAFF_H_

#include <iostream>
#include <string>
using namespace std;

class NhanVien
{
private:
	string name;
	int days;
	string title;
	string ID;
	double salary;
	string calID()
	{
		return to_string(days) + name;
	}
	double calSalary(string title)
	{
		if (title == "Nhan vien")
			return 1.0;
		else if (title == "Quan ly")
			return 1.5;
		else if (title == "Truong phong")
			return 2.25;
		else if (title == "Truong ban quan ly")
			return 4.0;
	}
	string calTitle(int days)
	{
		if (days >= 0 && days <= 365)
		{
			return "Nhan vien";
		}
		else if (days > 365 && days <= 730)
		{
			return "Quan ly";
		}
		else if (days > 730 && days <= 1460)
		{
			return "Truong phong";
		}
		else if (days > 1460)
		{
			return "Truong ban quan ly";
		}
		else 
			return "Ko hop le!!";
	}
public:
	NhanVien()
	{
		this->name = "No Name";
		this->title = "Nhan vien";
		this->days = 0;
		this->ID = "xxNoName";
		this->salary = calSalary(title);
	}
	NhanVien(string name, int days, string ID, string title, double salary)
	{
		this->name = name;
		this->days = days;
		this->ID = calID();
		this->title = title;
		this->salary = calSalary(title);
	}
	NhanVien(string name, int days)
	{
		this->name = name;
		this->days = days;
		this->ID = calID();

	}
	NhanVien(NhanVien& temp)
	{
		this->name = temp.getName();
		this->days = temp.getDays();
		this->ID = temp.getID();
		this->title = temp.getTitle();
		this->salary = temp.getSalary();
	}
	~NhanVien()
	{
		cout << "Da huy thanh cong\n";
	}

	// getter & setter
	string getName();
	void setName(string name);
	int getDays();
	void setDay(int days);
	string getTitle();
	void setTitle(string title);
	string getID();
	void setID(string ID);
	double getSalary();
	void setSalary(double salary);
	void input();
	void output();
};
#endif // _STAFF_H_