#include"student.h"

int main()
{

	bool a = 0;
	Student st;
	st.input();
	st.checkStudent(a);
	if (a == 1)
	{
		st.output();
	}
	else
		cout << "Xin moi nhap lai\n";
	
	return 0;
}