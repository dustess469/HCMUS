#include"student.h"

void Student::input()
{
	cout << "1. NHAP THONG TIN\n";
	cout << "Nhap ho va ten: ";
	getline(cin, name);
	cout << "Nhap so dien thoai: ";
	cin >> phoneNumber;
	cout << "Nhap diem trung binh: ";
	cin >> average;
}

bool Student::checkName()
{
	if (name.length() <= 20)
	{
		for (int i = 0; i < name.length(); i++)
		{
			if (!((name[i] >= 'a' && name[i] <= 'z') ||
				(name[i] >= 'A' && name[i] <= 'Z') || name[i] == ' '))
			{
				return false;
			}
		}
		return true;
	}
	else
		return false;
}

bool Student::checkNumber()
{
	bool flag = 1;

	if (phoneNumber.length() >= 9 && phoneNumber.length() <= 11)
	{
		for (int i = 0; i < phoneNumber.length(); i++)
		{
			if (phoneNumber[i] - 48 >= 0 && phoneNumber[i] - 48 <= 9)
			{
				flag = 1;
				continue;
			}

			else
			{
				flag = 0;
				break;
			}
		}

		if (flag == 1)
		{
			return true;
		}

		else
			return false;
	}
	else
		return false;
}


bool Student::checkAverage()
{
	if (average >= 0 && average <= 10)
	{
		return true;
	}
	else
		return false;
}


void Student::checkStudent(bool& a)
{
	a = 1;
	cout << "\n2. KIEM TRA HOC SINH\n";
	if (checkName() && checkNumber() && checkAverage())
	{
		cout << "Thong tin hop le\n";
	}
	if (!checkName())
	{
		a = 0;
		cout << "Ten ko hop le\n";
	}

	if (!checkNumber())
	{
		a = 0;
		cout << "Sdt ko hop le\n";
	}

	if (!checkAverage()) {
		a = 0;
		cout << "Diem ko hop le\n";
	}
}

void Student::output()
{
	cout << "\n3. XUAT THONG TIN\n";
	cout << "Ho va ten: " << name << endl;
	cout << "So dien thoai: " << phoneNumber << endl;
	cout << "Diem trung binh: " << average << endl;
}