#ifndef _STUDENT_H_
#define _STUDENT_H_

#include<iostream>
#include<string>

using namespace std;


class Student {
	string name;
	string phoneNumber;
	float average;

public:
	void input();
	bool checkName();
	bool checkNumber();
	bool checkAverage();
	void checkStudent(bool& a);
	void output();
};

#endif // !_STUDENT_H_
