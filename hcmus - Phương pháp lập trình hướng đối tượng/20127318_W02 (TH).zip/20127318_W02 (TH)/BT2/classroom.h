#ifndef _LOPHOC_H_
#define _LOPHOC_H_
#include "student.h"

class Classroom {
	vector <Student> hocSinh;

public:
	void input_file()
	{
		Student temp;
		temp.inputFile(hocSinh);
	}

	void output()
	{
		cout << "==========Danh sach hoc sinh==========\n";
		for (size_t i = 0; i < hocSinh.size(); i++)
		{
			cout << "Hoc sinh thu " << i + 1 << endl;
			hocSinh[i].output();
			cout << endl;
		}
	}

	void add()
	{
		Student temp;
		cout << "----Them hoc sinh moi----\n";

		temp.input();

		if (temp.check(temp.getName(), hocSinh))
		{
			hocSinh.push_back(temp);
			cout << "----Them thanh cong----\n";
		}
		else
		{
			cout << "----Hoc sinh da co trong ds----\n";
		}
	}

	void deleteStudent(string hoten)
	{
		Student temp;
		int pos = temp.deleteItem(hoten, hocSinh);

		if (pos == -1)
		{
			cout << "----Ko co hs trong lop----\n";
		}

		else
		{
			hocSinh.erase(hocSinh.begin() + pos);
			cout << "----Xoa thanh cong----\n";
		}
	}

	void sortList()
	{
		Student temp;
		temp.sort(hocSinh);
	}

};
#endif // !_LOPHOC_H_