#ifndef _STUDENT_H_
#define _STUDENT_H_

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

class Student
{
	string name;
	string phoneNumber;
	double average;

public:
	void input();
	void output();
	void inputFile(vector<Student>& hocSinh);
	string getName();
	bool check(string ten, vector<Student> hs);
	int deleteItem(string ten, vector<Student> hs);
	void sort(vector <Student>& hs);
};

#endif // !_STUDENT_H_