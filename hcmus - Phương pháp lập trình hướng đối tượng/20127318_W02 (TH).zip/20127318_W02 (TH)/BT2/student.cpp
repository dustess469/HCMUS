#include "student.h"

void Student::input()
{
	cout << "Nhap ten hoc sinh: ";
	getline(cin, name);
	cout << "Nhap sdt: ";
	getline(cin, phoneNumber);
	cout << "Nhap diem tb: ";
	cin >> average;
	cin.ignore();
}

void Student::output()
{
	cout << "Ho ten: " << name << endl;
	cout << "Sdt: " << phoneNumber << endl;
	cout << "Diem tb: " << average << endl;
}

void Student::inputFile(vector<Student>& hocSinh)
{
	fstream ifs;
	ifs.open("LopHoc.txt", ios::in);

	int n;
	ifs >> n;
	ifs.ignore();

	Student temp;
	while (n > 0)
	{
		getline(ifs, temp.name);
		getline(ifs, temp.phoneNumber);
		ifs >> temp.average;
		hocSinh.push_back(temp);
		n--;
		ifs.ignore();
	}
	ifs.close();
}

string Student::getName()
{
	return name;
}

bool Student::check(string ten, vector <Student> hs)
{
	for (size_t i = 0; i < hs.size(); i++)
	{
		if (ten == hs[i].name)
			return false;
		return true;
	}
}

int Student::deleteItem(string ten, vector<Student> hs)
{
	for (size_t i = 0; i < hs.size(); i++)
	{
		if (ten == hs[i].name)
			return i;
		return -1;
	}
}

void Student::sort(vector <Student>& hs)
{
	for (size_t i = 0; i < hs.size() - 1; i++)
		for (size_t j = i; j < hs.size(); j++)
			if (hs[i].average < hs[j].average)
				swap(hs[i], hs[j]);

}