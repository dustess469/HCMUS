#include "student.h"
#include "classroom.h"
using namespace std;

int main()
{
	Classroom danhSach;
	int choice;
	cout << "----------MENU----------\n";
	cout << "1. THEM HOC SINH MOI\n";
	cout << "2. XOA HOC SINH\n";
	cout << "3. XEM DANH SACH\n";
	cout << "4. SAP XEP THEO DIEM GIAM DAN\n";
	cout << "5. KET THUC LUA CHON\n";
	cout << "=============================\n";
	danhSach.input_file();

	while (true)
	{
		cout << "\nNhap lua chon: ";
		cin >> choice;

		if (choice == 1)
		{
			cin.ignore();
			danhSach.add();
			cout << "=============================\n";
		}
		if (choice == 2)
		{
			string ht;
			cout << "Nhap ten hs muon xoa: ";
			cin.ignore();
			getline(cin, ht);
			danhSach.deleteStudent(ht);
			cout << "=============================\n";
		}
		if (choice == 3)
		{
			danhSach.output();
			cout << "=============================\n";
		}
		if (choice == 4)
		{
			danhSach.sortList();
			cout << "=============================\n";
		}
		if (choice == 5)
		{
			cout << "Thoat chuong trinh!!\n";
			cout << "=============================\n";
			break;
		}
	}

	return 0;
}