#ifndef _FRACTION_
#define _FRACTION_

#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

class PhanSo
{
private:
    int* tuSo;
    int* mauSo;

public:
    PhanSo()
    {
        tuSo = new int;
        mauSo = new int;

        *tuSo = 0;
        *mauSo = 1;
    }
    
    PhanSo(int tuso)
    {
        tuSo = new int;
        mauSo = new int;

        *tuSo = tuso;
        *mauSo = 1;
    }
    
    PhanSo(int tuso, int mauso)
    {

        tuSo = new int;
        mauSo = new int;

        *tuSo = tuso;
        *mauSo = mauso;
    }
    
    ~PhanSo()
    {
        delete tuSo;
        delete mauSo;
    }
    
    PhanSo(const PhanSo& ps)
    {
        tuSo = new int;
        mauSo = new int;

        *tuSo = *ps.tuSo;
        *mauSo = *ps.mauSo;
    }

    // getter & setter
    int getTuSo()
    {
        return *tuSo;
    }

    void setTuSo(int tuso)
    {
        tuSo = new int;
        *tuSo = tuso;
    }

    int getMauSo()
    {
        return *mauSo;
    }

    void setMauSo(int mauso)
    {
        mauSo = new int;
        *mauSo = mauso;
    }
  

    void input()
    {
        cout << "***Nhap tu so: ";
        cin >> *tuSo;
        cout << "***Nhap mau so: ";
        cin >> *mauSo;
    }

    
    void output1()
    {
        cout << "***Dang phan so: " << *tuSo << "/" << *mauSo << endl;
    }

    void output2()
    {
        cout << "***Dang thap phan: " << (*tuSo * 1.0 / *mauSo) << endl;
    }
    
};

int ucln(int a, int b);
void reduction(int& tuSo, int& mauSo);
void additionPS(PhanSo ps1, PhanSo ps2);
void subtractionPS(PhanSo ps1, PhanSo ps2);
void multiplicationPS(PhanSo ps1, PhanSo ps2);
void divisionPS(PhanSo ps1, PhanSo ps2);

#endif // !_FRACTION_

