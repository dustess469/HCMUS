#include "Fraction.h"

int main()
{

	PhanSo f1;
	PhanSo f2;

	cout << "NHAP 2 PHAN SO\n";
	cout << "Nhap phan so 1:\n";
	f1.input();
	cout << "Nhap phan so 2:\n";
	f2.input();

	
	additionPS(f1, f2);
	subtractionPS(f1, f2);
	multiplicationPS(f1, f2);
	divisionPS(f1, f2);

	//Function to copy fraction 1 to fraction 3
	cout << "\nCOPY PHAN SO 1 SANG PHAN SO 3\n";
	PhanSo f3(f1);
	f3.output1();
	f3.output2();

	return 0;
}