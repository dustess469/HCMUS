#include "Fraction.h"

int ucln(int a, int b) {
    if (b == 0)
    {
        return a;
    }
    else
        return ucln(b, a % b);
}

void reduction(int& tuSo, int& mauSo)
{
    int rg = abs(ucln(tuSo, mauSo));
    tuSo = tuSo / rg;
    mauSo = mauSo / rg;
}

void additionPS(PhanSo ps1, PhanSo ps2)
{
    int* denominator = new int;
    int* numerator = new int;

    if (ps1.getMauSo() != 0 && ps2.getMauSo() != 0)
    {
        *denominator = (ps1.getMauSo()) * (ps2.getMauSo());
        *numerator = ps1.getTuSo() * ps2.getMauSo() + ps2.getTuSo() * ps1.getMauSo();

        reduction(*denominator, *numerator);

        cout << "\nTONG 2 PHAN SO\n";
        cout << "***Dang phan so: " << *numerator << "/" << *denominator << endl;
        cout << "***Dang thap phan: " << (*numerator * 1.0 / *denominator) << endl;
    }
    else
    {
        cout << "\nTONG 2 PHAN SO\n";
        cout << "***Error***\n";
    }
}

void subtractionPS(PhanSo ps1, PhanSo ps2)
{
    int* denominator = new int;
    int* numerator = new int;

    if (ps1.getMauSo() != 0 && ps2.getMauSo() != 0)
    {
        *denominator = (ps1.getMauSo()) * (ps2.getMauSo());
        *numerator = ps1.getTuSo() * ps2.getMauSo() - ps2.getTuSo() * ps1.getMauSo();

        reduction(*denominator, *numerator);

        cout << "\nHIEU 2 PHAN SO\n";
        cout << "***Dang phan so: " << *numerator << "/" << *denominator << endl;
        cout << "***Dang thap phan: " << (*numerator * 1.0 / *denominator) << endl;
    }
    else
    {
        cout << "\nHIEU 2 PHAN SO\n";
        cout << "***Error***\n";
    }
}

void multiplicationPS(PhanSo ps1, PhanSo ps2)
{
    int* denominator = new int;
    int* numerator = new int;

    if (ps1.getMauSo() != 0 && ps2.getMauSo() != 0)
    {
        *denominator = (ps1.getMauSo()) * (ps2.getMauSo());
        *numerator = ps1.getTuSo() * ps2.getTuSo();

        reduction(*denominator, *numerator);

        cout << "\nTICH 2 PHAN SO\n";
        cout << "***Dang phan so: " << *numerator << "/" << *denominator << endl;
        cout << "***Dang thap phan: " << (*numerator * 1.0 / *denominator) << endl;
    }
    else
    {
        cout << "\nTICH 2 PHAN SO\n";
        cout << "***Error***\n";
    }
}

void divisionPS(PhanSo ps1, PhanSo ps2)
{
    // swap ps2
    int tmp1, tmp2, tmp3;
    tmp1 = ps2.getTuSo();
    tmp2 = ps2.getMauSo();
    tmp3 = tmp1;
    tmp1 = tmp2;
    tmp2 = tmp3;

    int* denominator = new int;
    int* numerator = new int;

    if (ps1.getMauSo() != 0 && ps2.getMauSo() != 0)
    {
        *denominator = (ps1.getMauSo()) * tmp2;
        *numerator = ps1.getTuSo() * tmp1;

        reduction(*denominator, *numerator);

        cout << "\nTHUONG 2 PHAN SO\n";
        cout << "***Dang phan so: " << *numerator << "/" << *denominator << endl;
        cout << "***Dang thap phan: " << (*numerator * 1.0 / *denominator) << endl;
    }
    else
    {
        cout << "\nTHUONG 2 PHAN SO\n";
        cout << "***Error***\n";
    }
}
