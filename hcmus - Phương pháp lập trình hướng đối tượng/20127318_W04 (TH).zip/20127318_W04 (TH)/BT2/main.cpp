#include"game.h"

int main()
{
	Skill nameS, levelS;
	nameS.input();
	levelS.input();

	nameS.ouput();
	levelS.ouput();


	Hero nameH, healthH, manaH, levelH;
	nameH.input();
	healthH.input();
	manaH.input();
	levelH.input();

	nameH.output();
	healthH.output();
	manaH.output();
	levelH.output();
	return 0;
}