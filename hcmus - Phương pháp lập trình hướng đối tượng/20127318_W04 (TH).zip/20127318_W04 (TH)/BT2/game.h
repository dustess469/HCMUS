#ifndef _GAME_
#define _GAME_

#include<iostream>
#include<vector>
#include<string>

using namespace std;

class Skill
{
private:
	string skillName;
	unsigned int skillLevel;

public:
	void input()
	{
		cout << "Enter skill's name: ";
		getline(cin, skillName);
		cout << "\nEnter skill's level: ";
		cin >> skillLevel;
	}

	void ouput()
	{
		cout << "\nSkill's name is " << skillName;
		cout << "\nSkill's level is " << skillLevel;
	}
};

class Hero
{
private:
	string heroName;
	unsigned int heroHealth;
	unsigned int heroMana;
	unsigned int heroLevel;
	vector<Skill*> skillList;

public:
	void input()
	{
		cout << "\nEnter name of hero: ";
		getline(cin, heroName);
		cout << "\nEnter hero's health: ";
		cin >>heroHealth;
		cout << "\nEnter hero's mana: ";
		cin >> heroMana;
		cout << "\nEnter hero's level: ";
		cin >> heroLevel;
	}

	void output()
	{
		cout << "Name of hero is " << heroName;
		cout << "\nHero's health is " << heroHealth;
		cout << "\nHero's mana is " << heroMana;
		cout << "\nHero's level is " << heroLevel;
	}
};
#endif // !_GAME_
