#ifndef _BOOK_
#define _BOOK_

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Book
{
protected:
	string tenSach;
	string tacGia;
	string theLoai;
	bool tinhTrang;
	int namXuatBan;
public:

	void setTenSach(string sach)
	{
		tenSach = sach;
	}

	void setTacGia(string tacgia)
	{
		tacGia = tacgia;
	}

	void setTheLoai(string theloai)
	{
		theLoai = theloai;
	}

	void setTinhTrang(bool a)
	{
		tinhTrang = a;
	}

	void setNamXuatBan(int nam)
	{
		namXuatBan = nam;
	}

	Book()
	{
		tenSach = "Sach khong ten";
		tacGia = "Khong co";
		theLoai = "Khong co";
		tinhTrang = 0;
		namXuatBan = 2021;
	}

	Book(string tensach, string tacgia, string theloai, int namxb, bool tinhtrang)
	{
		tenSach = tensach;
		tacGia = tacgia;
		theLoai = theloai;
		namXuatBan = namxb;
		tinhTrang = tinhtrang;
	}

	void input()
	{
		cout << "==========Nhap thong tin sach==========\n";
		cout << "Nhap ten sach: ";
		getline(cin, tenSach);
		cout << "Nhap ten sach: ";
		getline(cin, tenSach);
		cout << "Nhap ten tac gia: ";
		getline(cin, tacGia);
		cout << "Nhap the loai: ";
		getline(cin, theLoai);
		cout << "Nhap nam xuat ban: ";
		cin >> namXuatBan;
		cout << "Nhap tinh trang sach (0/1): ";
		cin >> tinhTrang;
	}

};
#endif // !_BOOK_