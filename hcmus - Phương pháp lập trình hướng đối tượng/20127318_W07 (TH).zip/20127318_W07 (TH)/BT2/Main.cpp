#include "Square.h"
#include "Library.h"

int main()
{
	Rectangle hcn1;
	Square hv1;

	//RECTANGLE'S CODE
	cout << "----------HINH CHU NHAT----------\n";
	//(2,4), (3,4), (3,1), (2,1)
	cin >> hcn1;
	if (hcn1.check())
	{
		cout << "La hinh chu nhat\n\n";
		cout << hcn1 << endl;
		cout << "Chu vi HCN: " << hcn1.ChuVi() << endl;
		cout << "Dien tich HCN: " << hcn1.DienTich() << endl;

	}
	else
	{
		cout << "Khong phai la hinh chu nhat\n";
	}

	

	//SQUARE'S CODE
	cout << "\n\n----------HINH VUONG----------\n";
	//(2,5), (5,5), (5,2), (2,2)
	cin >> hv1;
	if (hv1.check())
	{
		cout << "La hinh vuong\n\n";
		cout << hv1 << endl;
		cout << "Chu vi HV: " << hv1.ChuVi() << endl;
		cout << "Dien tich HV: " << hv1.DienTich() << endl;
	}
	else
	{
		cout << "Khong phai la hinh vuong\n";
	}


	return 0;
}