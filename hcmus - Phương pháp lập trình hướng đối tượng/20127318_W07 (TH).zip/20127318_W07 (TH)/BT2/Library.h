#include "Book.h"
//Library inherit Book

class Library :public Book
{
private:
	vector <Book*> dsSach;
public:
	Library()
	{
		Book* sach1 = new Book();
		sach1->setTenSach("So do");
		sach1->setTacGia("Vu Trong Phung");
		sach1->setNamXuatBan(1993);
		sach1->setTinhTrang(1);
		sach1->setTheLoai("Tieu thuyet");
		Book* sach2 = new Book();
		sach2->setTenSach("Doraemon");
		sach2->setTacGia("Fujiko F.Fujio");
		sach2->setNamXuatBan(1969);
		sach2->setTinhTrang(1);
		sach2->setTheLoai("Truyen thieu nhi");

	}
	void ThemSach()
	{
		int n;
		cout << "Nhap so luong sach can them: ";
		cin >> n;
		for (size_t i = 0; i < n; i++)
		{
			Book* sach = new Book;
			sach->input();
			dsSach.push_back(sach);
		}
	}

	void checkStatus()//  available or not
	{

	}

	void SoSachDangLuuTru()
	{
		cout << "===============So sach dang co o thu vien===============\n";

	}
};