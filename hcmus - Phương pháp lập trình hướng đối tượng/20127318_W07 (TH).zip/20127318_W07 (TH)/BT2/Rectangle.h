#include "Shape.h"

double distance(Shape a, Shape b)
{
	double x = pow((a.getX() - b.getX()), 2);
	double y = pow((a.getY() - b.getY()), 2);

	return sqrt(x + y);
}


class Rectangle
{
protected:
	Shape diem[69];
public:
	void input()
	{
		cout << "Nhap toa do 4 diem cua HCN (theo thu tu A->B->C->D)\n\n";
		for (int i = 65; i <= 68; i++)
		{
			cout << "Nhap toa do diem" <<(char) i << endl;
			cout << "Nhap diem x[" <<(char) i << "] va y[" <<(char) i << "]:\n";
			diem[i].input();
		}
	}

	bool check()
	{
		// 4 canh hcn
		double disAB = distance(diem[65], diem[66]);
		double disBC = distance(diem[66], diem[67]);
		double disCD = distance(diem[67], diem[68]);
		double disDA = distance(diem[68], diem[65]);
		// 2 duong cheo
		double disAC = distance(diem[65], diem[67]);
		double disBD = distance(diem[66], diem[68]);

		cout << "\n***************\n";
		cout << "\nChieu dai cac canh HCN:\n";
		cout << "AB: " << disAB << endl;
		cout << "BC: " << disBC << endl;
		cout << "CD: " << disCD << endl;
		cout << "DA: " << disDA << endl;

		// kiem tra canh va 2 duong cheo bang cheo
		if ((disAB == disCD) && (disBC == disDA) && (disAC == disBD))
			return true;
		else return false;

	}
	void output()
	{
		cout << "***************\n\n";
		for (size_t i = 65; i <= 68; i++)
		{
			cout << "Toa do dinh[" <<(char) i << "]\n";
			cout << "x" <<(char) i << ": " << diem[i].getX() << endl;
			cout << "y" <<(char) i << ": " << diem[i].getY() << endl;
		}
	}

	double DienTich()
	{
		double disAB = distance(diem[65], diem[66]);
		double disBC = distance(diem[66], diem[67]);
		return disAB * disBC;
	}

	double ChuVi()
	{
		double disAB = distance(diem[65], diem[66]);
		double disBC = distance(diem[66], diem[67]);
		return 2 * (disAB + disBC);
	}

	friend istream& operator >> (istream& is, Rectangle& hcn)
	{
		hcn.input();

		return is;
	}

	friend ostream& operator << (ostream& os, Rectangle& hcn)
	{
		hcn.output();

		return os;
	}

};