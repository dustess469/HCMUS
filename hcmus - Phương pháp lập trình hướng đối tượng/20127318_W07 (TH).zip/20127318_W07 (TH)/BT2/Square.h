#include "Rectangle.h"

class Square : public Rectangle
{

public:
	void input()
	{
		cout << "Nhap toa do 4 diem cua HV (theo thu tu A->B->C->D):\n";
		for (int i = 65; i <= 68; i++)
		{
			cout << "Nhap toa do diem" <<(char) i << endl;
			cout << "Nhap diem x[" <<(char) i << "] va y[" <<(char) i << "]:\n";
			diem[i].input();
		}
	}

	bool check()
	{
		// 4 canh hcn
		double disAB = distance(diem[65], diem[66]);
		double disBC = distance(diem[66], diem[67]);
		double disCD = distance(diem[67], diem[68]);
		double disDA = distance(diem[68], diem[65]);
		// 2 duong cheo
		double disAC = distance(diem[65], diem[67]);
		double disBD = distance(diem[66], diem[68]);

		cout << "\n***************\n";
		cout << "\nChieu dai cac canh HV:\n";
		cout << "AB: " << disAB << endl;
		cout << "BC: " << disBC << endl;
		cout << "CD: " << disCD << endl;
		cout << "DA: " << disDA << endl;

		// kiem tra canh ke bang nhau va 2 duong cheo bang cheo
		if ((disAB == disBC) && (disAC == disBD))
			return true;
		else return false;

	}
	void output()
	{
		for (size_t i = 65; i <= 68; i++)
		{
			cout << "Toa do dinh[" <<(char) i << "]\n";
			cout << "x" <<(char) i << ": " << diem[i].getX() << endl;
			cout << "y" <<(char) i << ": " << diem[i].getY() << endl;
		}
	}

	double DienTich()
	{
		double disAB = distance(diem[65], diem[66]);
		return disAB * disAB;
	}

	double ChuVi()
	{
		double disAB = distance(diem[65], diem[66]);
		return 4 * disAB;
	}
};