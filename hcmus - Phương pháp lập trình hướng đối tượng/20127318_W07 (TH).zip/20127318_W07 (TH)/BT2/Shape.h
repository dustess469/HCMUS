#ifndef _SHAPE_
#define _SHAPE_

#include <iostream>
#include <cmath>
using namespace std;

class Shape {
private:
	double pX;
	double pY;
public:
	//constructor no parameter
	Shape()
	{
		pX = pY = 0;
	}

	// constructor have paremter
	Shape(double pX, double pY)
	{
		this->pX = pX;
		this->pY = pY;
	}
	void input()
	{
		cin >> pX >> pY;
	}
	void output()
	{
		cout << "Toa do x: " << pX << endl;
		cout << "Toa do y: " << pY << endl;
	}
	double getX()
	{
		return pX;
	}
	double getY()
	{
		return pY;
	}

};

#endif // !_SHAPE_