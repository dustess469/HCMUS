#ifndef _CINEMA_
#define _CINEMA_


#endif // !_CINEMA_
