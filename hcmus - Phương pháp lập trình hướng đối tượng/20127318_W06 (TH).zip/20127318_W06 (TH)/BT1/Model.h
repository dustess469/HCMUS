#ifndef _CAR_MODEL_
#define _CAR_MODEL_

#include <iostream>
#include <string>

using namespace std;

class Model
{
private:
	string version;
	string color;
	string categorize;
public:
	void setVersion(string ve);
	void setColor(string co);
	void setCategorize(string ca);
	string getVersion();
	string getColor();
	string getCategorize();
	Model();
	Model(string ve, string co, string ca);
	friend istream& operator >>(istream& is, Model& a);
	friend ostream& operator <<(ostream& os, Model& a);
	~Model() { };
};
#endif // !_CAR_MODEL_
