#include "CommercialVehicle.h"

Commerce::Commerce()
{
	car.setVersion("LuxSA");
	car.setColor("Den");
	car.setCategorize("Cao cap");
	this->piece = 50000000000;
	this->number = "16ZE88810";
}

Commerce::Commerce(string ve, string co, string ca, double pi, string nu)
{
	car.setVersion(ve);
	car.setColor(co);
	car.setCategorize(ca);
	this->piece = 50000000000;
	this->number = "16ZE88810";
}

Commerce::Commerce(Model temp, double pi)
{
	car.setVersion(temp.getVersion());
	car.setColor(temp.getColor());
	car.setCategorize(temp.getCategorize());
	this->piece = pi;
	this->number = "16ZE88810";
}

Commerce::Commerce(const Commerce& tmp)
{
	this->car = tmp.car;
	this->piece = tmp.piece;
	this->number = tmp.number;
}

Commerce& Commerce::operator=(Commerce& a)
{
	if (this->car.getVersion() == a.car.getVersion() &&
		this->car.getColor() == a.car.getColor())
	{
		this->car = a.car;
		this->piece = a.piece;
		this->number = a.number;
	}
	
	return *this;
}

void Commerce::signUp(string nu)
{
	this->number = nu;
}

istream& operator >>(istream& is, Commerce& a)
{
	string v, c, ca, n, p;
	cout << "Nhap phien ban xe: ";
	getline(is, v);
	a.car.setVersion(v);
	cout << "Nhap mau sac: ";
	getline(is, c);
	a.car.setVersion(c);
	cout << "Nhap loai xe: ";
	getline(is, ca);
	a.car.setVersion(ca);
	cout << "Nhap bien so xe: ";
	getline(is, n);
	cout << "Nhap gia xe: ";
	is >> p;
	cin.ignore();

	return is;
}
ostream& operator <<(ostream& os, Commerce& a)
{
	os << "Phien ban xe: ";
	os << a.car.getVersion() << endl;
	os << "Mau sac: ";
	os << a.car.getColor() << endl;
	os << "Loai xe: ";
	os << a.car.getCategorize() << endl;
	os << "Gia xe: " << a.piece << endl;
	os << "Bien so: " << a.number << endl;

	return os;
}