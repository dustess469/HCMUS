#include "Model.h"

void Model::setVersion(string ve)
{
	version = ve;
}

void Model::setColor(string co)
{
	color = co;
}

void Model::setCategorize(string ca)
{
	categorize = ca;
}

string Model::getVersion()
{
	return version;
}

string Model::getColor()
{
	return color;
}

string Model::getCategorize()
{
	return categorize;
}

Model::Model()
{
	this->version = "Fadi1";
	this->color = "Den";
	this->categorize = "Tieu chuan";
}

Model::Model(string ve, string co, string ca)
{
	version = ve;
	color = co;
	categorize = ca;
}

istream& operator >>(istream& is, Model& a)
{
	cout << "Nhap phien ban xe: ";
	getline(is, a.version);
	cout << "Nhap mau sac: ";
	getline(is, a.color);
	cout << "Nhap loai xe: ";
	getline(is, a.categorize);

	return is;
}

ostream& operator <<(ostream& os, Model& a)
{
	os << "Phien ban xe: ";
	os << a.version << endl;
	os << "Mau sac: ";
	os << a.color << endl;
	os << "Loai xe: ";
	os << a.categorize << endl;

	return os;
}