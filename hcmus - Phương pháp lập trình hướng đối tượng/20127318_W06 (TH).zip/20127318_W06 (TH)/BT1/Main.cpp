#include "Model.h"
#include "CommercialVehicle.h"

int main()
{
	Model a;

	cout << "+++Nhap mau xe+++\n";
	cin >> a;
	cout << "\n+++Mau xe da chon+++\n";
	cout << a;

	cout << "\n\n---------------------";
	cout << "\n+++Nhap xe thuong mai+++\n";
	Commerce b;
	cin >> b;
	cout << "\n+++Mau xe thuong mai da chon+++\n";
	cout << b;

	cout << "\n\n---------------------";
	cout << "\n+++Mau xe thuong mai mac dinh+++\n";
	Commerce c;
	c = b;
	cout << c;

	return 0;
}