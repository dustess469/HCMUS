#ifndef _COMMERCIAL_VEHICLE_
#define _COMMERCIAL_VEHICLE_

#include "Model.h"

class Commerce {
private:
	Model car;
	double piece;
	string number;
public:
	Commerce();
	Commerce(string ve, string co, string ca, double pi, string nu);
	Commerce(Model temp, double pi);
	Commerce(const Commerce& temp);
	Commerce& operator=(Commerce& a);
	friend istream& operator >>(istream& is, Commerce& a);
	friend ostream& operator <<(ostream& os, Commerce& a);
	~Commerce() {};
	void signUp(string nu);

};
#endif // !_COMMERCIAL_VEHICLE_