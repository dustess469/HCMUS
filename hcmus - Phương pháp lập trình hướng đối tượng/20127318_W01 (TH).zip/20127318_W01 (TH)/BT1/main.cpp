﻿#include"mfunction.h"


int main()
{
	phanSo a, b, c;
	
	cout << "1. NHAP 2 PHAN SO\n";
	cout << "--Phan so thu 1--\n";
	a.input();
	cout << "--Phan so thu 2--\n";
	b.input();


	cout << "\n2. XUAT 2 PHAN SO\n";
	cout << "Ket qua cong 2 phan so = ";
	c = a;
	c.addition(b);
	c.output1();
	c.output2();

	cout << "\nKet qua tru 2 phan so = ";
	c = a;
	c.subtraction(b);
	c.output1();
	c.output2();

	cout << "\nKet qua nhan 2 phan so = ";
	c = a;
	c.multiplication(b);
	c.output1();
	c.output2();

	cout << "\nKet qua chia 2 phan so = ";
	c = a;
	c.division(b);
	c.output1();
	c.output2();
	cout << endl;


	return 0;
}