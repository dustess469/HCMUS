﻿#ifndef _FUNCTION_
#define _FUNCTION_

#include<iostream>
#include<cmath>

using namespace std;

class phanSo
{
	int tu, mau;

public:
	//hàm để nhập phân số
	void input()
	{
		cout << "Nhap tu so: ";
		cin >> tu;
		cout << "Nhap mau so: ";
		cin >> mau;
	}

	//hàm check phân số có mẫu khác 0
	bool checkPS()
	{
		if (mau == 0)
		{
			return false;
		}

		return true;
	}

	//hàm UCLN
	int ucln(int a, int b) {
		if (b == 0)
		{
			return a;
		}
		else
			return ucln(b, a % b);
	}

	//hàm rút gọn
	void reduction(int& tu, int& mau)
	{
		int rg = abs(ucln(tu, mau));
		tu = tu / rg;
		mau = mau / rg;
	}

	//hàm cộng 2 phân số
	void addition(phanSo x)
	{
		if (checkPS())
		{
			tu = tu * x.mau + mau * x.tu;
			mau = mau * x.mau;

			reduction(tu, mau);
		}

		else
			cout << "Error\n";
	}

	//hàm trừ 2 phân số
	void subtraction(phanSo x)
	{
		if (checkPS())
		{
			tu = tu * x.mau - mau * x.tu;
			mau = mau * x.mau;

			reduction(tu, mau);
		}

		else
			cout << "Error\n";
	}

	//hàm nhân 2 phân số
	void multiplication(phanSo x)
	{
		if (checkPS())
		{
			tu = tu * x.tu;
			mau = mau * x.mau;

			reduction(tu, mau);
		}
		else
			cout << "Error\n";
	}

	//hàm chia 2 phân số
	void division(phanSo x)
	{
		if (checkPS())
		{
			tu = tu * x.mau;
			mau = mau * x.tu;

			reduction(tu, mau);
		}
		else
			cout << "Error\n";


	}

	//hàm xuất phân số
	void output1()
	{
		cout << tu << "/" << mau << " = ";
	}

	//hàm xuất số thập phân
	void output2()
	{
		cout << (1.0 * tu) / mau;
	}

};

#endif // !_FUNCTION_
