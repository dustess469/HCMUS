#include"mfunction.h"


int main()
{
	khongGian a, b;

	cout << "1. NHAP TOA DO KHONG GIAN Oxy";
	cout << "\n--Diem thu nhat--\n";
	a.input();
	cout << "--Diem thu hai--\n";
	b.input();

	cout << "\n2. XUAT TOA DO KHONG GIAN Oxy";
	cout << "\n--Diem thu nhat--\n";
	a.output();
	cout << "\n--Diem thu hai--\n";
	b.output();


	cout << "\n\n3. TINH KHOANG CACH GIUA 2 KHONG GIAN Oxy = " << distance(a, b) << endl;


	return 0;
}