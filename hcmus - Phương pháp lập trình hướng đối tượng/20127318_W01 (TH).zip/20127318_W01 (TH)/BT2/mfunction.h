#ifndef _FUNCTION_
#define _FUNCTION_

#include<iostream>
#include<cmath>

using namespace std;

class khongGian {
	double x, y;

public:
	void input()
	{
		cout << "Nhap toa do x = ";
		cin >> x;
		cout << "Nhap toa do y = ";
		cin >> y;
	}

	void output()
	{
		cout << "Toa do x = " << x;
		cout << endl;
		cout << "Toa do y = " << y;
	}

	double getX()
	{
		return x;
	}

	double getY()
	{
		return y;
	}
};

double distance(khongGian d1, khongGian d2)
{
	double a = pow((d1.getX() - d2.getX()), 2);
	double b = pow((d1.getY() - d2.getY()), 2);

	return sqrt(a + b);
}

#endif // !_FUNCTION_
