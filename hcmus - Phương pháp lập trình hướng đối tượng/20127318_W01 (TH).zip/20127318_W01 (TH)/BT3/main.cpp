#include"mfunction.h"
#include"rectangle.h"


int main()
{
	rectangle hcn;

	hcn.input();
	cout << endl;
	hcn.output();
	cout << endl;

	if (hcn.check())
	{
		cout << "\n4. KIEM TRA HINH CHU NHAT CO HOP LE KHONG?\n";
		cout << "Toa do hinh chu nhat hop le!\n";
		cout << "\n5. CHU VI HCN: " << hcn.perimeter() << endl;
		cout << "\n6. DIEN TICH HCN: " << hcn.area() << endl;
	}

	else
	{
		cout << "\n4. KIEM TRA HINH CHU NHAT CO HOP LE KHONG?\n";
		cout << "Toa do hcn khong hop le!\n";
	}

}