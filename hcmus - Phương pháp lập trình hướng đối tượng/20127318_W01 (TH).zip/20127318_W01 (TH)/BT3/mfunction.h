﻿#ifndef _FUNCTION_
#define _FUNCTION_

#include<iostream>
#include<cmath>

using namespace std;

class khongGian {
	double x, y;

public:
	//Nhập tọa độ đỉnh
	void input()
	{
		cout << "Nhap toa do x = ";
		cin >> x;
		cout << "Nhap toa do y = ";
		cin >> y;
	}

	//Xuất tọa độ đỉnh
	void output()
	{
		cout << "Toa do x = " << x;
		cout << endl;
		cout << "Toa do y = " << y;
	}

	double getX()
	{
		return x;
	}

	double getY()
	{
		return y;
	}
};

#endif // !_FUNCTION_
