﻿#ifndef _FUNCTION_RECTANGLE_
#define _FUNCTION_RECTANGLE_

#include"mfunction.h"


class rectangle {
	khongGian dinh[5];

public:
	bool a = true;

	//hàm nhập đỉnh của một hình chữ nhật
	void input()
	{
		cout << "1. NHAP 4 DINH CUA HINH CHU NHAT THEO CHIEU KIM DONG HO\n";

		for (int i = 1; i <= 4; i++)
		{
			cout << "Nhap toa do dinh " << i << ":" << endl;
			dinh[i].input();
		}
	}

	//hàm tính khoảng cách
	double distance(khongGian d1, khongGian d2)
	{
		double a = pow((d1.getX() - d2.getX()), 2);
		double b = pow((d1.getY() - d2.getY()), 2);

		return sqrt(a + b);
	}

	
	//hàm xuất đỉnh của hình chữ nhật
	void output()
	{
		cout << "2. XUAT 4 DNH CUA HINH CHU NHAT\n";

		for (int i = 1; i <= 4; i++)
		{
			cout << "Toa do dinh " << i << endl;
			cout << "x" << i << ": " << dinh[i].getX() << endl;
			cout << "y" << i << ": " << dinh[i].getY() << endl;
		}
	}


	//hàm kiểm tra hình chữ nhật
	bool check()
	{
		double AB = distance(dinh[1], dinh[2]);
		double BC = distance(dinh[2], dinh[3]);
		double CD = distance(dinh[3], dinh[4]);
		double DA = distance(dinh[4], dinh[1]);
		double AC = distance(dinh[1], dinh[3]);
		double BD = distance(dinh[2], dinh[4]);

		cout << "3. KHOANG CACH CAC CANH\n";
		cout << "AB: " << AB << endl;
		cout << "BC: " << BC << endl;
		cout << "CD: " << CD << endl;
		cout << "DA: " << DA << endl;
		cout << "AC: " << AC << endl;
		cout << "BD: " << BD << endl;

		if ((AB == CD) && (BC == DA) && (AB != BC) && (AC == BD))
		{
			return true;
		}
		else
			return false;

	}


	//hàm tính chu vi hcn
	double perimeter()
	{
		double AB = distance(dinh[1], dinh[2]);
		double BC = distance(dinh[2], dinh[3]);

		return 2 * (AB + BC);
	}


	//hàm tính diện tích hcn
	double area()
	{
		double AB = distance(dinh[1], dinh[2]);
		double BC = distance(dinh[2], dinh[3]);

		return AB * BC;
	}

};
#endif // !_FUNCTION_RECTANGLE_
