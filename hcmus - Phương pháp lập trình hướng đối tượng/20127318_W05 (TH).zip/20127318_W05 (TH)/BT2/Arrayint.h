#ifndef _ARRAYINT_
#define _ARRAYINT_

#include <iostream>

using namespace std;

class MangSoNguyen {
private:
	int* dulieu;
	int kichthuoc;
public:
	MangSoNguyen();
	MangSoNguyen(int size, int* a);
	MangSoNguyen(const MangSoNguyen& a);
	~MangSoNguyen();

	//=,+
	MangSoNguyen& operator=(const MangSoNguyen&);
	MangSoNguyen operator+(const MangSoNguyen&);
	//++
	MangSoNguyen operator++(int x);
	MangSoNguyen& operator++();
	//<<,>>
	friend istream& operator>>(istream&, MangSoNguyen&);
	friend ostream& operator<<(ostream&, const MangSoNguyen);
};

#endif // !_ARRAYINT_