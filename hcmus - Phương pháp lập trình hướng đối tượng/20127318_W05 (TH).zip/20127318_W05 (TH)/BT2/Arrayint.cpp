#include "Arrayint.h"

MangSoNguyen::MangSoNguyen() {
	this->kichthuoc = 0;
	this->dulieu = new int[this->kichthuoc];

}

MangSoNguyen::MangSoNguyen(int size, int* a) {
	this->kichthuoc = size;
	this->dulieu = new int[this->kichthuoc];
	for (int i = 0; i < this->kichthuoc; i++) this->dulieu[i] = a[i];

}

MangSoNguyen::MangSoNguyen(const MangSoNguyen& a) {
	this->kichthuoc = a.kichthuoc;
	this->dulieu = new int[this->kichthuoc];
	for (int i = 0; i < this->kichthuoc; i++) this->dulieu[i] = a.dulieu[i];
}

MangSoNguyen::~MangSoNguyen() {
	delete[] this->dulieu;
}


istream& operator>>(istream& is, MangSoNguyen& temp) {
	cout << "Enter integer array size: ";
	is >> temp.kichthuoc;
	temp.dulieu = new int[temp.kichthuoc];
	cout << "Enter the element value of the integer array: ";
	for (int i = 0; i < temp.kichthuoc; i++) {
		is >> temp.dulieu[i];
	}
	return is;
}

ostream& operator << (ostream& os, const MangSoNguyen temp) {
	for (int i = 0; i < temp.kichthuoc; i++) {
		os << temp.dulieu[i] << " ";
	}
	return os;
}


MangSoNguyen& MangSoNguyen::operator=(const MangSoNguyen& a) {
	if (this == &a) {
		return *this;
	}
	delete[] dulieu;
	this->kichthuoc = a.kichthuoc;
	this->dulieu = new int[kichthuoc];
	for (int i = 0; i < this->kichthuoc; i++) this->dulieu[i] = a.dulieu[i];
	return *this;
}

MangSoNguyen MangSoNguyen::operator+(const MangSoNguyen& a) {
	int n = max(this->kichthuoc, a.kichthuoc);
	int m = min(this->kichthuoc, a.kichthuoc);
	int* arr = new int[n];
	for (int i = 0; i < m; i++) arr[i] = this->dulieu[i] + a.dulieu[i];
	for (int i = m; i < this->kichthuoc; i++) arr[i] = this->dulieu[i];
	for (int i = m; i < a.kichthuoc; i++) arr[i] = a.dulieu[i];
	return MangSoNguyen(n, arr);
}

MangSoNguyen MangSoNguyen::operator++(int x) {
	int* temp = new int[this->kichthuoc];
	for (int i = 0; i < this->kichthuoc; i++) temp[i] = this->dulieu[i];
	for (int i = 0; i < this->kichthuoc; i++) this->dulieu[i]++;
	return MangSoNguyen(this->kichthuoc, temp);
}
MangSoNguyen& MangSoNguyen::operator++() {
	for (int i = 0; i < this->kichthuoc; i++) this->dulieu[i]++;
	return *this;
}