#include "Arrayint.h"


int main() {
	MangSoNguyen a, b;

	cout << "Enter integer array A\n";
	cin >> a;
	cout << ">>Value integer array A: " << a << endl << endl;


	cout << "Enter integer array B\n";
	cin >> b;
	cout << ">>Value integer array B: " << b << endl << endl;
	 

	cout << ">>Addition integer array a and b: " << a + b << endl << endl;


	MangSoNguyen d;
	d = a;
	cout << ">>Value D after copy A: " << d << endl << endl;

	cout << ">>D++: " << d++ << endl << endl;

	cout << ">>++D: " << ++d << endl << endl;

	return 0;
}