#include "Fraction.h"

// default constructor 
PhanSo::PhanSo()
{
    tuSo = new int;
    mauSo = new int;

    *tuSo = 0;
    *mauSo = 1;
}
// constructor 1 parameter
PhanSo::PhanSo(int tuso)
{
    tuSo = new int;
    mauSo = new int;

    *tuSo = tuso;
    *mauSo = 1;
}
// constructor 2 parameters
PhanSo::PhanSo(int tuso, int mauso)
{
    tuSo = new int;
    mauSo = new int;

    *tuSo = tuso;
    *mauSo = mauso;
}
// destructor
PhanSo::~PhanSo()
{
    delete tuSo;
    delete mauSo;
}
// copy constructor
PhanSo::PhanSo(const PhanSo& ps)
{
    tuSo = new int;
    mauSo = new int;

    *tuSo = *ps.tuSo;
    *mauSo = *ps.mauSo;
}

// getter & setter
int PhanSo::getTuSo()
{
    return *tuSo;
}

void PhanSo::setTuSo(int tuso)
{
    tuSo = new int;
    *tuSo = tuso;
}

int PhanSo::getMauSo()
{
    return *mauSo;
}

void PhanSo::setMauSo(int mauso)
{
    mauSo = new int;
    *mauSo = mauso;
}

int PhanSo::GCD(int a, int b)
{
    if (b == 0) return a;
    return GCD(b, a % b);
}

void PhanSo::rutGon()
{
    int k = GCD(*tuSo, *mauSo);
    *tuSo = *tuSo / k;
    *mauSo = *mauSo / k;
}
//=========================OPERATOR OVERLOADING=========================

PhanSo& PhanSo::operator=(const PhanSo& ps)
{
    if (this == &ps)// ps = ps
        return *this;
    delete tuSo;
    delete mauSo;
    tuSo = new int; // cap phat vung nho
    mauSo = new int;

    *this->tuSo = *ps.tuSo;
    *this->mauSo = *ps.mauSo;

    return *this;
}

PhanSo PhanSo::operator+(const PhanSo& ps)
{
    PhanSo tmp;
    *tmp.tuSo = *this->tuSo * *ps.mauSo + *this->mauSo * *ps.tuSo;
    *tmp.mauSo = *this->mauSo * (*ps.mauSo);
    tmp.rutGon();

    return tmp;
}

PhanSo PhanSo::operator-(const PhanSo& ps)
{
    PhanSo tmp;
    *tmp.tuSo = *this->tuSo * *ps.mauSo - *this->mauSo * *ps.tuSo;
    *tmp.mauSo = *this->mauSo * (*ps.mauSo);
    tmp.rutGon();

    return tmp;
}

PhanSo PhanSo::operator* (const PhanSo& ps)
{
    PhanSo tmp;
    *tmp.tuSo = *this->tuSo * (*ps.tuSo);
    *tmp.mauSo = *this->mauSo * (*ps.mauSo);
    tmp.rutGon();

    return tmp;
}

PhanSo PhanSo::operator/ (const PhanSo& ps)
{
    PhanSo tmp;
    if (*ps.mauSo != 0)
    {
        int* t = new int;
        *t = *ps.tuSo;
        *ps.tuSo = *ps.mauSo;
        *ps.mauSo = *t;

        *tmp.tuSo = *this->tuSo * (*ps.tuSo);
        *tmp.mauSo = *this->mauSo * (*t);

        tmp.rutGon();
        delete t;
    }
    else
    {
        cout << "Phan so ko hop le! Khong thuc hien duoc phep chia" << endl;
        return -1;
    }
    return tmp;
}

PhanSo& PhanSo::operator+=(const PhanSo& ps)
{
    *this->tuSo = (*this->tuSo) * (*ps.mauSo) + (*this->mauSo) * (*ps.tuSo);
    *this->mauSo = (*this->mauSo) * (*ps.mauSo);
    rutGon();

    return *this;
}

PhanSo& PhanSo::operator-=(const PhanSo& ps)
{
    *this->tuSo = (*this->tuSo) * (*ps.mauSo) - (*this->mauSo) * (*ps.tuSo);
    *this->mauSo = (*this->mauSo) * (*ps.mauSo);
    //rutGon();

    return *this;
}

PhanSo& PhanSo::operator*=(const PhanSo& ps)
{
    *this->tuSo = (*this->tuSo) * (*ps.tuSo);
    *this->mauSo = (*this->mauSo) * (*ps.mauSo);
    //rutGon();

    return *this;
}

PhanSo& PhanSo::operator/=(const PhanSo& ps)
{
    if (*ps.mauSo != 0)
    {
        int* t = new int;
        *t = *ps.tuSo;
        *ps.tuSo = *ps.mauSo;
        *ps.mauSo = *t;

        *this->tuSo = *this->tuSo * (*ps.tuSo);
        *this->mauSo = *this->mauSo * (*t);

        //rutGon();
        delete t;

        return *this;
    }
}

bool PhanSo::operator ==(const PhanSo& ps)
{
    int result = (*this->tuSo) * (*ps.mauSo) - (*this->mauSo) * (*ps.tuSo);
    if (result == 0)
        return true;
    else return false;
}

bool PhanSo::operator <(const PhanSo& ps)
{
    int tmp1 = (*this->tuSo) * (*ps.mauSo) - (*this->mauSo) * (*ps.tuSo);
    int tmp2 = *this->mauSo * *ps.mauSo;
    if (tmp1 * tmp2 < 0)
        return true;
    return false;
}

bool PhanSo::operator >(const PhanSo& ps)
{
    int tmp1 = (*this->tuSo) * (*ps.mauSo) - (*this->mauSo) * (*ps.tuSo);
    int tmp2 = (*this->mauSo) * (*ps.mauSo);
    if (tmp1 * tmp2 > 0)
        return true;
    return false;
}

bool PhanSo::operator <=(const PhanSo& ps)
{
    return !(PhanSo::operator>(ps));
}

bool PhanSo::operator >=(const PhanSo& ps)
{
    return !(PhanSo::operator<(ps));
}

bool PhanSo::operator !=(const PhanSo& ps)
{
    int result = (*this->tuSo) * (*ps.mauSo) - (*this->mauSo) * (*ps.tuSo);
    if (result != 0)
        return true;
    else return false;
}

PhanSo PhanSo:: operator++(int x)
{
    PhanSo result(*this);
    *this->tuSo = *this->tuSo + *this->mauSo;

    return result;
}

PhanSo& PhanSo:: operator++()
{
    *this->tuSo = *this->tuSo + *this->mauSo;

    return *this;
}

istream& operator>>(istream& is, PhanSo& ps)
{
    cout << "Nhap tu so: ";
    is >> *ps.tuSo;
    cout << "Nhap mau so: ";
    is >> *ps.mauSo;
    cout << endl;

    return is;
}

ostream& operator<<(ostream& os, PhanSo& ps)
{
    os << *ps.tuSo << "/" << *ps.mauSo << endl;

    return os;
}