#include "Fraction.h"

int main()
{
	PhanSo f1;
	PhanSo f2;
	
	//+ - * / (fraction 1, 2)
	cout << "Enter fraction 1\n";
	cin >> f1;
	cout << "Enter fraction 2\n";
	cin >> f2;

	cout << "CACULATE FRACTION 1, 2\n";
	PhanSo tmp1;
	tmp1 = f2 + f1;
	cout << "f1 + f2 = " << tmp1 << endl;

	tmp1 = f1 - f2;
	cout << "f1 - f2 = " << tmp1 << endl;

	tmp1 = f1 * f2;
	cout << "f1 * f2 = " << tmp1 << endl;

	tmp1 = f1 / f2;
	cout << "f1 / f2 = " << tmp1 << endl;



	//+= -= *= /= ++ -- (fraction 1,3)
	PhanSo f3;
	cout << "Enter fraction 3\n";
	cin >> f3;

	cout << "CACULATE FRACTION 1, 3\n";
	PhanSo tmp2;
	tmp2 = f3;
	tmp2 += f1;
	tmp2.rutGon();
	cout << "f3 += f1: " << tmp2 << endl;

	tmp2 = f3;
	tmp2 -= f1;
	tmp2.rutGon();
	cout << "f3 -= f1: " << tmp2 << endl;

	tmp2 = f3;
	tmp2 *= f1;
	tmp2.rutGon();
	cout << "f3 *= f1: " << tmp2 << endl;

	tmp2 = f3;
	tmp2 /= f1;
	tmp2.rutGon();
	cout << "f3 /= f1: " << tmp2 << endl;

	tmp2 = f3;
	tmp2++;
	tmp2.rutGon();
	cout << "f3++: " << tmp2 << endl;

	tmp2 = f3;
	++tmp2;
	tmp2.rutGon();
	cout << "++f3: " << tmp2 << endl;


	//== < > <= >= != (fraction 1, 2, 3)
	cout << "COMPARE FRACTION 1, 2 ,3\n";
	if (f1 < f2)
	{
		cout << "f1 < f2\n";
	}

	if (f1 <= f2)
	{
		cout << "f1 <= f2\n";
	}

	if (f1 > f2)
	{
		cout << "f1 > f2\n";
	}

	if (f1 >= f2)
	{
		cout << "f1 >= f2\n";
	}

	if (f1 == f2)
	{
		cout << "f1 = f2\n";
	}

	cout << endl;
	return 0;
}