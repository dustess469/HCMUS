#ifndef _FRACTION_
#define _FRACTION_

#include <iostream>

using namespace std;

class PhanSo
{
private:
    int* tuSo;
    int* mauSo;
public:
    // default constructor 
    PhanSo();
    // constructor 1 parameter
    PhanSo(int tuso);
    // constructor 2 parameters
    PhanSo(int tuso, int mauso);
    // destructor
    ~PhanSo();
    // copy constructor
    PhanSo(const PhanSo& ps);
    // getter & setter
    int getTuSo();
    void setTuSo(int tuso);
    int getMauSo();
    void setMauSo(int mauso);
    int GCD(int a, int b);
    void rutGon();

    friend istream& operator>>(istream& is, PhanSo& ps);
    friend ostream& operator<<(ostream& is, PhanSo& ps);
    PhanSo& operator=(const PhanSo& ps);
    PhanSo operator+(const PhanSo& ps);
    PhanSo operator-(const PhanSo& ps);
    PhanSo operator*(const PhanSo& ps);
    PhanSo operator/(const PhanSo& ps);
    PhanSo& operator+=(const PhanSo& ps);
    PhanSo& operator-=(const PhanSo& ps);
    PhanSo& operator*=(const PhanSo& ps);
    PhanSo& operator/=(const PhanSo& ps);
    PhanSo operator++(int x);
    PhanSo& operator++();
    bool operator ==(const PhanSo& ps);
    bool operator <(const PhanSo& ps);
    bool operator >(const PhanSo& ps);
    bool operator <=(const PhanSo& ps);
    bool operator >=(const PhanSo& ps);
    bool operator !=(const PhanSo& ps);
};

#endif // !_FRACTION_