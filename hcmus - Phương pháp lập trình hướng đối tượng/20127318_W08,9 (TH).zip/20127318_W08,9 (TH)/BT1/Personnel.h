#ifndef _PERSONNEL_
#define _PERSONNEL_

#include<iostream>
#include<vector>
#include<string>
#include<fstream>

using namespace std;

class Personnel 
{
protected:
	string name;
	string birth;
	string code;
public:
	Personnel() 
	{
		name = "";
		birth = "";
		code = "";
	};
	Personnel(string ten, string date, string ms) 
	{
		name = ten;
		birth = date;
		code = ms;
	}

	~Personnel() {};
	string getName();
	string getDate();
	string getCode();

	virtual string position() = 0;
	virtual float getWage() = 0;
	virtual void input(istream& is) = 0;
	virtual void output() = 0;

};

#endif // !_PERSONNEL_
