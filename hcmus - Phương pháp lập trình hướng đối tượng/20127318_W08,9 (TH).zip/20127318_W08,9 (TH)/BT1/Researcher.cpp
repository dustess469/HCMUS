#include"Researcher.h"

string Researcher::position() {
	return "Researcher";
}

int Researcher::getExYear() {
	return exYear;
}

float Researcher::getWage() {
	int d = 0;
	for (int i = 0; i < listProject.size(); i++) {
		if (listProject[i][0] == 'D')
			d++;
	}
	return (getExYear() * 2 + d) * 20000;

}

void Researcher::input(istream& is) {
	cout << "Nhap nghien cuu sinh: \n";
	is.ignore();

	cout << "Nhap ten: "; 
	getline(is, name);
	cout << "Nhap ngay sinh: "; 
	getline(is, birth);
	cout << "Nhap ID: "; 
	getline(is, code);

	int n;
	cout << "Nhap so luong do an: "; 
	is >> n;
	listProject.resize(n);
	is.ignore();
	for (int i = 0; i < n; i++) 
	{
		cout << "Nhap ten do an " << i + 1 << ": "; 
		getline(is, listProject[i]);

	}
	cout << "Nhap so nam kinh nghiem: "; 
	is >> exYear;
}

void Researcher::output() {
	cout << "Vi tri: " << position() << endl;
	cout << "Ten: " << getName() << endl;
	cout << "Ngay sinh: " << getDate() << endl;
	cout << "ID: " << getCode() << endl;
	cout << "So nam kinh nghiem: " << exYear << endl;
	cout << "Danh sach do an cua nghien cuu sinh \n";
	for (int i = 0; i < listProject.size(); i++) {
		cout << listProject[i] << endl;
	}
	cout << "Luong: " << getWage() << endl;
}