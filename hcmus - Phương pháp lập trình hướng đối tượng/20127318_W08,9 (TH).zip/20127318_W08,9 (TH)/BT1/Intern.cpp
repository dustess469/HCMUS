#include "Intern.h"

string Intern::position() 
{
	return "Intern";
}

float Intern::getWage() {
	int t = 0;
	for (int i = 0; i < listProject.size(); i++) 
	{
		if (listProject[i][0] == 'R')
			t++;
	}
	return t * 1000;
}
void Intern::input(istream& is)
{
	cout << "Nhap thuc tap sinh: \n";
	is.ignore();

	cout << "Nhap ten: ";
	getline(is, name);
	cout << "Nhap ngay sinh: "; 
	getline(is, birth);
	cout << "Nhap ID: "; 
	getline(is, code);

	int n;
	cout << "Nhap so luong do an: ";
	cin >> n;
	listProject.clear();
	listProject.resize(n);

	is.ignore();
	string project;
	for (int i = 0; i < listProject.size(); i++)
	{
		cout << "Nhap ten do an " << i + 1 << ": "; 
		getline(is, listProject[i]);
	}
}
void Intern::output() {
	cout << "Vi tri: " << position() << endl;
	cout << "Ten: " << getName() << endl;
	cout << "Ngay sinh: " << getDate() << endl;
	cout << "ID: " << getCode() << endl;
	cout << "Danh sach do an: " << endl;
	for (int i = 0; i < listProject.size(); i++) 
	{
		cout << listProject[i] << endl;
	}
	cout << "Luong: " << getWage() << endl;
}