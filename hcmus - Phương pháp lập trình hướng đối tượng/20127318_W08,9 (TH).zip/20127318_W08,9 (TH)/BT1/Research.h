#ifndef _RESEARCH_
#define _RESEARCH_

#include"Personnel.h"

class Research : public Personnel
{
protected:
	int exYear;
	vector<string> listProject;
public:
	Research(string ten = "", string date = "", string code = "", int ex = 0)
		: Personnel(ten, date, code) 
	{
		exYear = ex;
		for (auto& i : listProject)
			i = "";
	};
	~Research() {
		listProject.clear();
	};

	virtual string position() = 0;
	virtual float getWage() = 0;
	virtual void input(istream& is) = 0;
	virtual void output() = 0;
};

#endif // !_RESEARCH_