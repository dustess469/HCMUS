#ifndef _INTERN_
#define _INTERN_

#include"Research.h"

class Intern : public Research
{
public:
	Intern() : Research() {};
	~Intern() {};

	string position();
	float getWage();
	void input(istream& is);
	void output();
};

#endif // !_INTERN_
