#ifndef _PROJECT_
#define _PROJECT_

#include"Research.h"

class Expert : public Research
{
public:
	Expert(int ex = 0) :Research()
	{
		exYear = ex;
	};

	~Expert() {};
	int getExYear();
	string position();
	float getWage();
	void input(istream& is);
	void output();
};
#endif // !_PROJECT_
