#ifndef _TUTOR_
#define _TUTOR_

#include"Personnel.h"

class Tutor :public Personnel
{
private:
	int subject;
public:
	Tutor(string ten = "", string date = "", string code = "", int sub = 0)
		:Personnel(ten, date, code)
	{
		subject = sub;
	};
	~Tutor() {};

	string position();
	int getSubject();
	float getWage();
	void input(istream& is);
	void output();
};

#endif // !_TUTOR_
