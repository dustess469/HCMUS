#include"Lecter.h"
string Lecter::position() 
{
	return "Lecter";
}


string Lecter::getDegree() 
{
	return degree;
}

int Lecter::getExYear()
{
	return experienceYear;
}


float Lecter::getWage() 
{
	return listSubject.size() * experienceYear * 0.12 * 20000;
}

void Lecter::input(istream& is) {

	cout << "Nhap giang vien: \n";
	is.ignore();

	cout << "Nhap ten: "; 
	getline(is, name);
	cout << "Nhap ngay sinh: "; 
	getline(is, birth);
	cout << "Nhap ID: "; 
	getline(is, code);


	cout << "Nhap cap bac: "; 
	getline(is, degree);
	cout << "Nhap so nam kinh nghiem ";
	is >> experienceYear;
	cout << "Nhap danh sach do an: \n";


	int n;
	cout << "Nhap so luong do an: "; 
	cin >> n;
	cin.ignore(1);
	for (int i = 0; i < n; i++)
	{
		string subject;
		cout << "Nhap ten do an " << i + 1 << ": "; getline(is, subject);
		listSubject.push_back(subject);
	}
}

void Lecter::output() {
	cout << "Vi tri: " << position() << endl;
	cout << "Ten: " << getName() << endl;
	cout << "Ngay sinh: " << getDate() << endl;
	cout << "ID: " << getCode() << endl;
	cout << "Cap bac: " << degree << endl;
	cout << "So nam kinh nghiem: " << experienceYear << endl;
	cout << "Danh sach do an cua giang vien: " << endl;
	for (int i = 0; i < listSubject.size(); i++) {
		cout << listSubject[i] << endl;
	}
	cout << "Luong: " << getWage() << endl;
}
