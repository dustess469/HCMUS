#include"Tutor.h"

string Tutor::position()
{
	return "Tutor";
}


int Tutor::getSubject()
{
	return subject;
}


float Tutor::getWage()
{
	return subject * 0.3 * 18000;
}


void Tutor::input(istream& is)
{
	cout << "Nhap tro giang: \n";
	is.ignore();

	cout << "Nhap ten: "; 
	getline(is, name);
	cout << "Nhap ngay sinh: "; 
	getline(is, birth);
	cout << "Nhap ID: "; 
	getline(is, code);

	cout << "Nhap so luong do an: \n";
	is >> subject;
}

void Tutor::output() {
	cout << "Vi tri: " << position() << endl;
	cout << "Ten: " << getName() << endl;
	cout << "Ngay sinh: " << getDate() << endl;
	cout << "ID: " << getCode() << endl;
	cout << "So luong do an: " << getSubject() << endl;
	cout << "Luong: " << getWage() << endl;
}