#ifndef _RESEARCHER_
#define _RESEARCHER_

#include"Research.h"

class Researcher :public Research 
{
public:
	Researcher(int ex = 0) : Research() 
	{
		exYear = ex;
	};
	~Researcher() {};

	int getExYear();
	string position();
	float getWage();
	void output();
	void input(istream& is);
};
#endif // !_RESEARCHER_
