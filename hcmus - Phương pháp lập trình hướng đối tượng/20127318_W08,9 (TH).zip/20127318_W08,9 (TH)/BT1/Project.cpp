#include"Project.h"
string Expert::position() {
	return "Expert";
}


int Expert::getExYear() {
	return experienceYear;
}

float Expert::getWage() {
	int t = 0;
	for (int i = 0; i < listProject.size(); i++) {
		if (listProject[i][0] == 'T')
			t++;
	}
	return (getExYear() * 2 + t) * 18000;
}

void Expert::input(istream& is) {
	cout << "Input expert: \n";
	is.ignore();

	cout << "Enter name: "; getline(is, name);
	cout << "Enter date of birth: "; getline(is, dateOfBirth);
	cout << "Enter code: "; getline(is, code);

	int n;
	cout << "Enter number of project: "; cin >> n;
	listProject.clear();
	listProject.resize(n);

	is.ignore();
	string project;
	for (int i = 0; i < listProject.size(); i++) {
		cout << "enter project" << i + 1 << ": "; getline(is, listProject[i]);
	}
	cout << "Enter experience year: "; is >> experienceYear;
}

void Expert::output() {
	cout << "Position: " << position() << endl;
	cout << "Name: " << getName() << endl;
	cout << "Date of birth: " << getDate() << endl;
	cout << "ID: " << getCode() << endl;
	cout << "Experience Year: " << experienceYear << endl;
	cout << "List of project are finished of expert: " << endl;
	for (int i = 0; i < listProject.size(); i++) {
		cout << listProject[i] << endl;
	}
	cout << "salary: " << getWage() << endl;
}