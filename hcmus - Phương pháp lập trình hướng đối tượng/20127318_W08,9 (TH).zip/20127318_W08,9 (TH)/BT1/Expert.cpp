#include"Project.h"

string Expert::position() {
	return "Expert";
}


int Expert::getExYear() {
	return exYear;
}

float Expert::getWage() {
	int t = 0;
	for (int i = 0; i < listProject.size(); i++) {
		if (listProject[i][0] == 'T')
			t++;
	}
	return (getExYear() * 2 + t) * 18000;
}

void Expert::input(istream& is) {
	cout << "Nhap chuyen vien\n";
	is.ignore();

	cout << "Nhap ten: "; 
	getline(is, name);
	cout << "Nhap ngay sinh "; 
	getline(is, birth);
	cout << "Nhap ID: "; 
	getline(is, code);

	int n;
	cout << "Nhap so luong do an: "; 
	cin >> n;
	listProject.clear();
	listProject.resize(n);

	is.ignore();
	string project;
	for (int i = 0; i < listProject.size(); i++) {
		cout << "Nhap ten do an " << i + 1 << ": "; 
		getline(is, listProject[i]);
	}
	cout << "Nhap so nam kinh nghiem: "; 
	is >> exYear;
}

void Expert::output() {
	cout << "Vi tri: " << position() << endl;
	cout << "Ten: " << getName() << endl;
	cout << "Ngay sinh: " << getDate() << endl;
	cout << "ID: " << getCode() << endl;
	cout << "So nam kinh nghiem: " << exYear << endl;
	cout << "Danh sach do an ket thuc cua chuyen vien: " << endl;
	for (int i = 0; i < listProject.size(); i++) {
		cout << listProject[i] << endl;
	}
	cout << "Luong: " << getWage() << endl;
}