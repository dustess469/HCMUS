#ifndef _LECTER_
#define _LECTER_

#include"Personnel.h"

class Lecter : public Personnel
{
private:
	string degree;
	int experienceYear;
	vector<string> listSubject;
public:
	Lecter(string ten = "", string date = "", string code = "", string deg = "", 
		int ex = 0) :Personnel(ten, date, code) 
	{
		degree = deg;
		experienceYear = ex;
		for (auto& i : listSubject)
			i = "";
	}

	~Lecter() {};
	string position();
	string getDegree();
	int getExYear();
	float getWage();
	void input(istream& is);
	void output();
};

#endif // !_LECTER_
