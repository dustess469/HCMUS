#include"Personnel.h"

string Personnel::getName() {
	return name;
}
string Personnel::getDate() {
	return birth;
}
string Personnel::getCode() {
	return code;
}