#include"Lecter.h"
#include"Researcher.h"
#include"Expert.h"
#include"Intern.h"
#include"Tutor.h"

void main() {
	vector<Personnel*> university;

	int n;
	do {
		cout << "Nhap so luong nhan su: "; 
		cin >> n;
		if (n < 0)
			cout << "Loi!\n";
	} while (n < 0);
	cin.ignore();

	university.resize(n);

	int choice;
	float totalOfWage = 0;

	for (int i = 0; i < n; i++) 
	{
		cout << "\nNhan su thu " << i + 1 << ": \n";
		bool flag = 0;
		do {
			cout << "1.Giang vien\n"; 
			cout << "2.Tro giang\n";
			cout << "3.Nghien cuu sinh\n";
			cout << "4.Chuyen vien\n";
			cout << "5.Thuc tap sinh\n";
			cout << "Nhap lua chon: ";
			cin >> choice;
		} while ((choice < 1 || choice>5) && cout << "Moi nhap lai\n");

		if (choice == 1)
			university[i] = new Lecter();
		else if (choice == 2)
			university[i] = new Tutor();
		else if (choice == 3)
			university[i] = new Researcher();
		else if (choice == 4)
			university[i] = new Expert();
		else
			university[i] = new Intern();
		university[i]->input(cin);
		totalOfWage += university[i]->getWage();
	}

	cout << "\n--------------------------------------\n";
	cout << "***DANH SACH NHAN SU*** \n";
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhan su thu " << i + 1 << ": \n";
		university[i]->output();
	}
	cout << "\nTong luong phai tra: " << totalOfWage << endl;
	for (int i = 0; i < n; i++)
		delete university[i];
	university.resize(0);

}