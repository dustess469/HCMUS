This project was a proof of concept, not recommended to use it in production environments since it not cover all security checks that SAML demand.

We can suggest some alternatives:
- [ComponentSpace](http://www.componentspace.com/) (commercial)
- [OIOSAML](https://digitaliser.dk/resource/2972745) (open source)
- [ITfoxtec](http://itfoxtec.com/identitysaml2) (open source)
- [Sustainsys](https://github.com/Sustainsys/Saml2) (formerly Kentor) (open source)
- [Owin.Security.Saml](https://github.com/elerch/SAML2) (open source)
